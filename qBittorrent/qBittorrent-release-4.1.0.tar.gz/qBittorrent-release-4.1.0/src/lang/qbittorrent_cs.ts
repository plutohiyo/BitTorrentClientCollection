<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>O aplikaci qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="52"/>
        <source>About</source>
        <translation>O aplikaci</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="81"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="113"/>
        <location filename="../gui/about.ui" line="204"/>
        <source>Nationality:</source>
        <translation>Národnost:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="127"/>
        <location filename="../gui/about.ui" line="190"/>
        <source>Name:</source>
        <translation>Jméno:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="120"/>
        <location filename="../gui/about.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="93"/>
        <source>Greece</source>
        <translation>Řecko</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>Současný správce</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="157"/>
        <source>Original author</source>
        <translation>Původní autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>Speciální poděkování</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="267"/>
        <source>Translators</source>
        <translation>Překladatelé</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="319"/>
        <source>Libraries</source>
        <translation>Knihovny</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="325"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent využívá těchto knihoven:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="163"/>
        <source>France</source>
        <translation>Francie</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="293"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Uložit jako</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Set as default save path</source>
        <translation>Nastavit jako výchozí cestu pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>Už nikdy nezobrazovat</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Nastavení torrentu</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>Nastavit jako výchozí kategorii</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>Kategorie:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Spustit torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="190"/>
        <source>Torrent information</source>
        <translation>Info o torrentu</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>Přeskočit kontrolu hashe</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="243"/>
        <source>Size:</source>
        <translation>Velikost:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="209"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Comment:</source>
        <translation>Komentář:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="236"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Režim správy torrentu:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatický mód znamená, že různé vlastnosti torrentu (např. cesta uložení) budou přiřazeny podle příslušné kategorie</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manuální</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automatický</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Pokud je zaškrtnuto, torrent soubor nebude smazán, navzdory nastavení v sekci &quot;stahování&quot; a dialogovém okně možnosti</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>Nemazat soubor .torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>Vytvořit podsložku</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="362"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="367"/>
        <source>High</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="372"/>
        <source>Maximum</source>
        <translation>Maximální</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="377"/>
        <source>Do not download</source>
        <translation>Nestahovat</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="277"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="706"/>
        <source>I/O Error</source>
        <translation>Chyba I/O</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="291"/>
        <source>Invalid torrent</source>
        <translation>Neplatný torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="497"/>
        <source>Renaming</source>
        <translation>Přejmenování</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="502"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="527"/>
        <source>Rename error</source>
        <translation>Chyba přejmenování</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="503"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>Název je prázdný, nebo obsahuje nepodporované znaky. Prosím, zvolte jiný.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="732"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Není k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="733"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Není k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="741"/>
        <source>Not available</source>
        <translation>Není k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="327"/>
        <source>Invalid magnet link</source>
        <translation>Neplatný magnet link</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="277"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>Torrent &apos;%1&apos; neexistuje</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>Torrent &apos;%1&apos; nemůže být přečten z disku. Pravděpodobně na to nemáte dostatečná práva.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="291"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Nepodařilo se načíst torrent: %1.
Error: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="304"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="338"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Already in the download list</source>
        <translation>Již existuje v seznamu pro stažení</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="304"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="338"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers weren&apos;t merged because it is a private torrent.</source>
        <translation>Torrent &apos;%1&apos; již existuje v seznamu pro stažení. Trackery nebyly sloučeny, protože je torrent soukromý.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>Torrent &apos;%1&apos; již existuje v seznamu pro stažení. Trackery byly sloučeny.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="313"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="347"/>
        <source>Cannot add torrent</source>
        <translation>Nelze přidat torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="313"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>Nelze přidat tento torrent. Zřejmě se již jednou přidává.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="327"/>
        <source>This magnet link was not recognized</source>
        <translation>Tento magnet link nebyl rozpoznán </translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Magnet link &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>Magnet link &apos;%1&apos; již existuje v seznamu pro stažení. Trackery byly sloučeny.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="347"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>Nelze přidat tento torrent. Zřejmě se již jednou přidává.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="356"/>
        <source>Magnet link</source>
        <translation>Magnet link</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="362"/>
        <source>Retrieving metadata...</source>
        <translation>Získávám metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="447"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Není k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="449"/>
        <source>Free space on disk: %1</source>
        <translation>Volné místo na disku: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="102"/>
        <source>Choose save path</source>
        <translation>Vyberte cestu pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="497"/>
        <source>New name:</source>
        <translation>Nový název:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="528"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="566"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Tento název je již v tomto adresáři použit. Vyberte prosím jiný název.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="565"/>
        <source>The folder could not be renamed</source>
        <translation>Složka nelze přejmenovat</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="610"/>
        <source>Rename...</source>
        <translation>Přejmenovat...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="614"/>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="707"/>
        <source>Invalid metadata</source>
        <translation>Neplatná metadata</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="714"/>
        <source>Parsing metadata...</source>
        <translation>Parsování metadat...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="718"/>
        <source>Metadata retrieval complete</source>
        <translation>Načítání metadat dokončeno</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="772"/>
        <source>Download Error</source>
        <translation>Chyba stahování</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="239"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="356"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Odchozí porty (Min) [0: Vypnuto]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="361"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Odchozí porty (Max) [0: Vypnuto]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="371"/>
        <source>Recheck torrents on completion</source>
        <translation>Při dokončení překontrolovat torrenty</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="377"/>
        <source>Transfer list refresh interval</source>
        <translation>Interval obnovování seznamu přenosů</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="376"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="118"/>
        <source>Setting</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="118"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="235"/>
        <source> (disabled)</source>
        <translation>(vypnuto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="237"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="250"/>
        <source>All addresses</source>
        <translation>Všechny adresy</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="287"/>
        <source>qBittorrent Section</source>
        <translation>Sekce qBittorrentu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="290"/>
        <location filename="../gui/advancedsettings.cpp" line="295"/>
        <source>Open documentation</source>
        <translation>Otevřít dokumentaci</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="293"/>
        <source>libtorrent Section</source>
        <translation>Sekce libtorrentu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="309"/>
        <source>Disk cache</source>
        <translation>Disková cache</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="314"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="315"/>
        <source>Disk cache expiry interval</source>
        <translation>Interval vypršení diskové cache </translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="318"/>
        <source>Enable OS cache</source>
        <translation>Zapnout vyrovnávací paměť systému</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="321"/>
        <source>Guided read cache</source>
        <translation>Řízená cache pro čtení</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="325"/>
        <source>Coalesce reads &amp; writes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="329"/>
        <source>Send upload piece suggestions</source>
        <translation>Doporučení pro odeslání částí uploadu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="333"/>
        <location filename="../gui/advancedsettings.cpp" line="338"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="335"/>
        <source>Send buffer watermark</source>
        <translation>Odeslat watermark bufferu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="340"/>
        <source>Send buffer low watermark</source>
        <translation>Odeslat buffer-low watermark</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="345"/>
        <source>Send buffer watermark factor</source>
        <translation>Odeslat buffer watermark faktor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="368"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Povolit více spojení ze stejné IP adresy</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Zjišťovat zemi původu protějšků (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="383"/>
        <source>Resolve peer host names</source>
        <translation>Zjišťovat síťové názvy protějšků</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="391"/>
        <source>Strict super seeding</source>
        <translation>Striktní super seeding</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="416"/>
        <source>Network Interface (requires restart)</source>
        <translation>Síťové rozhraní (vyžaduje restart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="419"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Volitelná přidružená  IP adresa (vyžaduje restart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Naslouchat na adrese IPv6 (vyžaduje restart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="430"/>
        <source>Display notifications</source>
        <translation>Zobrazit notifikace</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="433"/>
        <source>Display notifications for added torrents</source>
        <translation>Zobrazit oznámení o přidaných torrentech</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="436"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Stáhnout logo trackeru</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="440"/>
        <source>Save path history length</source>
        <translation>Uložit délku historie cesty</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="452"/>
        <source>Upload slots behavior</source>
        <translation>Chování upload slotů</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="456"/>
        <source>Upload choking algorithm</source>
        <translation>Škrtící algoritmus pro upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="468"/>
        <source>Confirm torrent recheck</source>
        <translation>Potvrdit překontrolování torrentu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="472"/>
        <source>Confirm removal of all tags</source>
        <translation>Potvrdit odebrání všech štítků</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="476"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Vždy oznamovat všem trackerům ve třídě</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="480"/>
        <source>Always announce to all tiers</source>
        <translation>Vždy oznamovat všem třídám</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="393"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Jakékoli rozhraní</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="351"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Interval uložení dat obnovení</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="365"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>%1-TCP mixed mode algoritmus</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="388"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Maximální počet napůl otevřených spojení [0: Neomezeno]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="425"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP adresa hlášená trackerům (vyžaduje restart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="443"/>
        <source>Enable embedded tracker</source>
        <translation>Povolit vestavěný tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="448"/>
        <source>Embedded tracker port</source>
        <translation>Port vestavěného trackeru</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="460"/>
        <source>Check for software updates</source>
        <translation>Zkontrolovat aktualizace</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="464"/>
        <source>Use system icon theme</source>
        <translation>Použít systémový motiv ikon</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="163"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 byl spuštěn</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="302"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, spuštěn externí program, příkaz: %2 </translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="329"/>
        <source>Torrent name: %1</source>
        <translation>Název torrentu: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="330"/>
        <source>Torrent size: %1</source>
        <translation>Velikost torrentu: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="331"/>
        <source>Save path: %1</source>
        <translation>Cesta pro uložení: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="332"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent byl stažen do %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="334"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Děkujeme, že používáte qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="341"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; dokončil stahování</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="355"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, odeslání emailového oznámení</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="516"/>
        <source>Information</source>
        <translation>Informace</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="517"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="519"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Uživatelské jméno administrátora webového rozhraní je: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="523"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Heslo správce webového rozhraní uživatele je stále výchozí: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="524"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Toto je bezpečnostní riziko, zvažte prosím změnu hesla v nastavení programu.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="687"/>
        <source>Saving torrent progress...</source>
        <translation>Průběh ukládání torrentu...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="744"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation>Přenosný mód a volba výslovného určení adresáře profilu se vzájemně vylučují</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="747"/>
        <source>Portable mode implies relative fastresume</source>
        <translation>Přenosný mód předpokládá relativní fastresume</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="50"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="240"/>
        <source>Save to:</source>
        <translation>Uložit do:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Stahování RSS </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Autostahování RSS torrentů je nyní vypnuté! Můžete ho zapnout v nastavení aplikace.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Pravidla stahování</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Definice pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Používat regulární výrazy</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="112"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.01.01 and 01.01.2017 (Date formats also support - as a separator)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="116"/>
        <source>Use Smart Episode Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="125"/>
        <source>Must Contain:</source>
        <translation>Musí obsahovat:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="132"/>
        <source>Must Not Contain:</source>
        <translation>Nesmí obsahovat:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="139"/>
        <source>Episode Filter:</source>
        <translation>Filtr epizod:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Assign Category:</source>
        <translation>Přiřadit kategorii:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="228"/>
        <source>Save to a Different Directory</source>
        <translation>Uložit do jiného adresáře</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="268"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorovat následné shody po dobu (0 pro vypnutí)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="278"/>
        <source>Disabled</source>
        <translation>Vypnuto</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="281"/>
        <source> days</source>
        <translation>dnů</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="314"/>
        <source>Add Paused:</source>
        <translation>Přidat pozastaveně:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="322"/>
        <source>Use global settings</source>
        <translation>Použít globální nastavení</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="327"/>
        <source>Always</source>
        <translation>Vždy</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="332"/>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="353"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Použít pravidlo na kanály:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="375"/>
        <source>Matching RSS Articles</source>
        <translation>Odpovídající RSS články</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="403"/>
        <source>&amp;Import...</source>
        <translation>&amp;Import...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="413"/>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Články odpovídající filtru epizod.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source>Example: </source>
        <translation>Příklad:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>odpovídá 2, 5, 8 až 15, 30 a dalším epizodám první sezóny</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Episode filter rules: </source>
        <translation>Pravidla filtru epizod:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Číslo sezóny je povinná nenulová hodnota</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Filter must end with semicolon</source>
        <translation>Filtr musí být ukončen středníkem</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Jsou podporovány tři typy rozsahu pro epizody:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Jedno číslo: &lt;b&gt;1x25;&lt;/b&gt; odpovídá epizodě 25 první sezóny</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Rozsah: &lt;b&gt;1x25-40;&lt;/b&gt; odpovídá epizodám 25 až 40 první sezóny</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>Číslo epizody je povinná kladná hodnota</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules</source>
        <translation>Pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="64"/>
        <source>Rules (legacy)</source>
        <translation>Pravidla (původní)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Neukončený rozsah: &lt;b&gt;1x25-;&lt;/b&gt; zahrnuje epizody 25 a výše z první sezóny a všechny epizody pozdějších sérií</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="275"/>
        <source>Last Match: %1 days ago</source>
        <translation>Poslední shoda: %1 dny nazpět</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="277"/>
        <source>Last Match: Unknown</source>
        <translation>Poslední shoda: Neznámá</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="360"/>
        <source>New rule name</source>
        <translation>Nový název pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="360"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Napište název nového pravidla stahování.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="365"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="517"/>
        <source>Rule name conflict</source>
        <translation>Název pravidla koliduje</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="366"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Pravidlo s tímto názvem již existuje, vyberte jiný název, prosím.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Opravdu chcete odstranit pravidlo s názvem &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="382"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Opravdu chcete odstranit označená pravidla?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Rule deletion confirmation</source>
        <translation>Potvrdit smazání pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="392"/>
        <source>Destination directory</source>
        <translation>Cílový adresář</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="400"/>
        <source>Invalid action</source>
        <translation>Neplatná akce</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Seznam je prázdný, nic není k exportu.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="407"/>
        <source>Export RSS rules</source>
        <translation>Export RSS pravidel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="430"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="447"/>
        <source>I/O Error</source>
        <translation>Chyba I/O </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Nepodařilo se vytvořit cílový soubor. Důvod: % 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="439"/>
        <source>Import RSS rules</source>
        <translation>Import RSS pravidel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Soubor se nepodařilo otevřít. Důvod: % 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="463"/>
        <source>Import Error</source>
        <translation>Chyba importu</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="464"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Nepodařilo se importovat vybraný soubor pravidel. Důvod: % 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="471"/>
        <source>Add new rule...</source>
        <translation>Přidat nové pravidlo...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Delete rule</source>
        <translation>Smazat pravidlo</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="481"/>
        <source>Rename rule...</source>
        <translation>Přejmenovat pravidlo...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="484"/>
        <source>Delete selected rules</source>
        <translation>Smazat označená pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="487"/>
        <source>Clear downloaded episodes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="511"/>
        <source>Rule renaming</source>
        <translation>Přejmenování pravidla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="511"/>
        <source>Please type the new rule name</source>
        <translation>Napište název nového pravidla, prosím</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="537"/>
        <source>Clear downloaded episodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="538"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="642"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex mód: použijte regulární výraz komatibilní s Perlem</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="684"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="722"/>
        <source>Position %1: %2</source>
        <translation>Pozice %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="645"/>
        <source>Wildcard mode: you can use</source>
        <translation>Mód zástupných znaků: můžete použít</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="646"/>
        <source>? to match any single character</source>
        <translation>? pro shodu s libovolným jediným znakem</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="647"/>
        <source>* to match zero or more of any characters</source>
        <translation>* pro shodu se žádným nebo více jakýmikoliv znaky</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="648"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Mezera slouží jako operátor AND (všechna slova v jakémkoliv pořadí)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="649"/>
        <source>| is used as OR operator</source>
        <translation>| slouží jako operátor OR</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="650"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Je-li důležité pořadí slov, použijte * místo mezery.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="657"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Výraz s prázdným %1 obsahem (např. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="661"/>
        <source> will match all articles.</source>
        <translation>zahrne všechny položky.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="662"/>
        <source> will exclude all articles.</source>
        <translation>vyloučí všechny položky.</translation>
    </message>
</context>
<context>
    <name>BanListOptions</name>
    <message>
        <location filename="../gui/banlistoptions.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Seznam zakázaných IP adres</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="77"/>
        <source>Ban IP</source>
        <translation>Zakázat IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="84"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="87"/>
        <location filename="../gui/banlistoptions.cpp" line="97"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="87"/>
        <source>The entered IP address is invalid.</source>
        <translation>Vložená IP adresa je neplatná.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="97"/>
        <source>The entered IP is already banned.</source>
        <translation>Vložená IP adresa je již zakázaná.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="588"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Kvůli přepnutí podpory PEX je nutný restart</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1237"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>Nebylo možné získat GUID nastaveného síťového rozhraní. Přiřazeno k IP %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1742"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Vestavěný tracker [ZAP]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1744"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Start vestavěného trackeru selhal!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1747"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Vestavěný tracker [VYP]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2404"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Systémový stav sítě změněn na %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2404"/>
        <source>ONLINE</source>
        <translation>ONLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2404"/>
        <source>OFFLINE</source>
        <translation>OFFLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2426"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>Nastavení sítě %1 bylo změněno, obnovuji spojení</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2443"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>Adresa síťového rozhraní %1 není platná</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="2782"/>
        <source>Encryption support [%1]</source>
        <translation>Podpora šífrování [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="2783"/>
        <source>FORCED</source>
        <translation>VYNUCENO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2907"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 je neplatná IP adresa a vložení do seznamu zakázaných adres bylo zamítnuto.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="477"/>
        <location filename="../base/bittorrent/session.cpp" line="3144"/>
        <source>Anonymous mode [%1]</source>
        <translation>Anonymní režim [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3612"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Nelze dekódovat soubor torrentu &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3749"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Rekurzivní stahování souboru &apos;%1&apos; vloženého v torrentu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3848"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>Pozice fronty byly opraveny v %1 souborech pro obnovení</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4074"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Nelze uložit &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4124"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; byl odstraněn ze seznamu přenosů.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4137"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; byl odstraněn ze seznamu přenosů a smazán z disku.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4149"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; byl odstraněn ze seznamu přenosů, ale soubory nemohly být smazány. Chyba: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4209"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>protože %1 je vypnuto.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4212"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>protože %1 je vypnuto.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4230"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Vyhledání URL sdílení selhalo pro URL: &apos;%1&apos;, zpráva: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4278"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>qBitorrent sell v naslouchání na rozhraní %1 port: %2/%3. Důvod: %4.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2075"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Stahuji  &apos;%1&apos;, prosím čekejte...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1201"/>
        <location filename="../base/bittorrent/session.cpp" line="2520"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent se pokouší naslouchat na jakémkoli rozhraní, portu: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2462"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Vybrané síťové rozhraní je neplatné: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1214"/>
        <location filename="../base/bittorrent/session.cpp" line="2531"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent se pokouší naslouchat na rozhraní %1, portu: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="472"/>
        <source>Peer ID: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="473"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="474"/>
        <location filename="../base/bittorrent/session.cpp" line="559"/>
        <source>DHT support [%1]</source>
        <translation>Podpora DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="474"/>
        <location filename="../base/bittorrent/session.cpp" line="475"/>
        <location filename="../base/bittorrent/session.cpp" line="476"/>
        <location filename="../base/bittorrent/session.cpp" line="477"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="559"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <location filename="../base/bittorrent/session.cpp" line="2783"/>
        <location filename="../base/bittorrent/session.cpp" line="3144"/>
        <source>ON</source>
        <translation>ZAPNUTO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="474"/>
        <location filename="../base/bittorrent/session.cpp" line="475"/>
        <location filename="../base/bittorrent/session.cpp" line="476"/>
        <location filename="../base/bittorrent/session.cpp" line="477"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="559"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <location filename="../base/bittorrent/session.cpp" line="2783"/>
        <location filename="../base/bittorrent/session.cpp" line="3144"/>
        <source>OFF</source>
        <translation>VYPNUTO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="475"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Podpora hledání místních protějšků [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="476"/>
        <source>PeX support [%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1792"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; dosáhl nastaveného maximálního ratia. Odebrán.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1797"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; dosáhl nastaveného maximálního ratia. Pozastaven.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1817"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; dosáhl nastavené maximální doby seedu. Odebrán.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1822"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; dosáhl nastavené maximální doby seedu. Pozastaven.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2496"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent nenalezl místní adresu %1 na které by měl naslouchat</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2524"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent selhal naslouchat na rozhraní %1. Důvod: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3523"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; byl přidán do torrentu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3533"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; byl odebrán z torrentu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3548"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>URL zdroj &apos;%1&apos; byl přidán do torrentu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3554"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>URL zdroj &apos;%1&apos; byl odebrán z torrentu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3797"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Nelze obnovit torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3882"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>IP filter byl úspěšně zpracován: bylo aplikováno %1 pravidel.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3892"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Chyba: Nepovedlo se zpracovat poskytnutý IP filtr.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4108"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Nelze přidat torrent. Důvod: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4057"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; obnoven. (rychlé obnovení)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4084"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; přidán do seznamu stahování.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4173"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Došlo k chybě I/O, &apos;%1&apos; je pozastaven. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4181"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Namapování portů selhalo, zpráva: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4187"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Namapování portů bylo úspěšné, zpráva: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4197"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>kvůli IP filtru.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4200"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>kvůli port filtru.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4203"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>kvůli omezením i2p mixed módu. </translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4206"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>kvůli nízkému portu.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4251"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent naslouchá na rozhraní %1, portu: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4288"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>Externí IP: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="191"/>
        <source>create new torrent file failed</source>
        <translation>vytvoření nového torrentu selhalo</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="92"/>
        <source>File size exceeds max limit %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="99"/>
        <source>Torrent file read error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="242"/>
        <source>Categories</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="396"/>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="403"/>
        <source>Uncategorized</source>
        <translation>Nezařazeno</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="116"/>
        <source>Add category...</source>
        <translation>Přidat kategorii...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="124"/>
        <source>Add subcategory...</source>
        <translation>Přidat podkategorii</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="130"/>
        <source>Edit category...</source>
        <translation>Upravit kategorie...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="135"/>
        <source>Remove category</source>
        <translation>Odstranit kategorii</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="141"/>
        <source>Remove unused categories</source>
        <translation>Odstranit nevyužité kategorie</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="148"/>
        <source>Resume torrents</source>
        <translation>Obnovit torrenty</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="153"/>
        <source>Pause torrents</source>
        <translation>Pozastavit torrenty</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="158"/>
        <source>Delete torrents</source>
        <translation>Smazat torrenty</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Spravovat cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Doména</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Expirace</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="51"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Opravdu chcete smazat &apos;%1&apos; ze seznamu přenosů?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="53"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Opravdu chcete smazat %1 torrenty ze seznamu přenosů?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>Bílé: Chybějící díly</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>Zelené: Částečné díly</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>Modré: Celé díly</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="39"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation>Blokované IP</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="109"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; byl zablokován %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="111"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; byl zakázán (ban)</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="49"/>
        <source>RSS feeds</source>
        <translation>RSS kanály</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="61"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="115"/>
        <source>Unread  (%1)</source>
        <translation>Nezobrazeno (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="168"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="102"/>
        <source>Any file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="276"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="438"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Chyba I/O: Nelze otevřít IP filtr v režimu pro čtení.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="344"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>Řádka %1 IP filtru je chybná.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="222"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="362"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>Řádka %1 IP filtru je chybná. Počáteční IP z rozsahu je chybná.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="231"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="371"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>Řádka %1 IP filtru je chybná. Koncová IP z rozsahu je chybná.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="239"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="379"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>Řádka %1 IP filtru je chybná. Jenda IP adresa je IPv4 a další je IPv6!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="253"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="392"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>Nastala výjimka IP filtru pro linku %1. Výjimka je: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="263"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="402"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>Došlo k chybě při analýze IP filtru% 1.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="449"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="482"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="491"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="511"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="531"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Chyba parsování: soubor s filtrem není validní PeerGuardian P2B soubor.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="97"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="127"/>
        <source>Unsupported database file size.</source>
        <translation>Nepodporovaná velikost databázového souboru.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="226"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Chyba metadat: &apos;%1&apos; nenalezeno.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="227"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Chyba metadat: &apos;%1&apos; je neplatný.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Nepodporovaná verze databáze: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="243"/>
        <source>Unsupported IP version: %1</source>
        <translation>Nepodporovaná verze IP: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="250"/>
        <source>Unsupported record size: %1</source>
        <translation>Nepodporovaná velikost záznamu: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="263"/>
        <source>Invalid database type: %1</source>
        <translation>Neplatný typ databáze: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="284"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Databáze poškozena: data nenalezena.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="72"/>
        <source>Http request size exceeds limiation, closing socket. Limit: %ld, IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="85"/>
        <source>Bad Http request, closing socket. IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Exit qBittorrent</source>
        <translation>Ukončit qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Only one link per line</source>
        <translation>Pouze jeden odkaz na řádek</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Globální limit odesílání musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Globální limit stahování musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativní limit odesílání musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativní limit stahování musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Maximum aktivních stahování musí být větší než -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Maximum aktivních odesílání musí být větší než -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Maximum aktivních torrentů musí být větší než -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximální počet spojení musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximální počet spojení na torrent musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit maximálního počtu slotů na torrent musí být větší než 0 nebo vypnut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nelze uložit nastavení programu, qBittorrent klient je pravděpodobně nedostupný.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent na Freenode</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Invalid category name:
Please do not use any special characters in the category name.</source>
        <translation>Neplatný název kategorie:
Nepoužívejte žádné speciální znaky ani diakritiku v názvu kategorie.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Unknown</source>
        <translation>Neznámý</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Hard Disk</source>
        <translation>Pevný disk</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>Limit ratia musí být v rozsahu od 0 do 9998.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>Doba seedování musí být v rozsahu od 0 do 525600 minut.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>Port příchozích spojení musí být mezi 1 a 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>Port webového rozhraní musí být mezi 1 a 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Nelze se přihlásit, qBittorrent je pravděpodobně nedostupný</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>Invalid Username or Password.</source>
        <translation>Neplatné jméno nebo heslo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>Username</source>
        <translation>Uživatelské jméno</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Login</source>
        <translation>Přihlášení</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>Original authors</source>
        <translation>Původní autoři</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Nahrát torrenty</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Save files to location:</source>
        <translation>Ukládat soubory do umístění:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Type folder here</source>
        <translation>Zadejte název adresáře</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>More information</source>
        <translation>Více informací</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Information about certificates</source>
        <translation>Informace o certifikátech</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Save Files to</source>
        <translation>Uložit soubory do</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Set location</source>
        <translation>Nastavit umístění</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Limit upload rate</source>
        <translation>Omezit rychlost odesílání</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Limit download rate</source>
        <translation>Omezit rychlost stahování</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Rename torrent</source>
        <translation>Přejmenovat torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Jiná...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Pondělí</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Úterý</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Středa</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Čtvrtek</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Pátek</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sobota</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Neděle</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>Logout</source>
        <translation>Odhlásit</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Stahovat torrenty z jejich URL nebo Magnet linku</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Upload local torrent</source>
        <translation>Nahrát lokální torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Opravdu chcete smazat vybrané torrenty ze seznamu přenosů?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Klient qBittorrent není dostupný</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent byl ukončen.</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Seznam povolených IP podsítí</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Příklad: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>Přidat podsíť</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="92"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="92"/>
        <source>The entered subnet is invalid.</source>
        <translation>Zadaná podsíť je neplatná</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Clear</source>
        <translation>Vymazat</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>Ú&amp;pravy</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Nástroje</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>Nápo&amp;věda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Při &amp;dokončení stahování</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>&amp;Zobrazit</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>&amp;Možnosti...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>&amp;Obnovit</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Vytvoření torrentu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>Set Upload Limit...</source>
        <translation>Nastavit limit odesílání...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Download Limit...</source>
        <translation>Nastavit limit stahování...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Set Global Download Limit...</source>
        <translation>Nastavit celkový limit stahování...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="248"/>
        <source>Set Global Upload Limit...</source>
        <translation>Nastavit celkový limit odesílání...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Minimum Priority</source>
        <translation>Minimální priorita</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="261"/>
        <source>Top Priority</source>
        <translation>Top priorita</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="269"/>
        <source>Decrease Priority</source>
        <translation>Snížit prioritu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="277"/>
        <source>Increase Priority</source>
        <translation>Zvýšit prioritu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <location filename="../gui/mainwindow.ui" line="291"/>
        <source>Alternative Speed Limits</source>
        <translation>Alternativní limity rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>&amp;Top Toolbar</source>
        <translation>Horní panel nás&amp;trojů</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="302"/>
        <source>Display Top Toolbar</source>
        <translation>Zobrazit horní panel nástrojů</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="310"/>
        <source>Status &amp;Bar</source>
        <translation>Stavová lišta</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>R&amp;ychlost v záhlaví okna</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="321"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Zobrazit aktuální rychlost v záhlaví okna</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="329"/>
        <source>&amp;RSS Reader</source>
        <translation>&amp;RSS čtečka</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="337"/>
        <source>Search &amp;Engine</source>
        <translation>Vyhl&amp;edávač</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Zamkn&amp;out qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>Do&amp;nate!</source>
        <translation>Darujte!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="472"/>
        <source>Close Window</source>
        <translation>Zavřít okno</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>Obnovit vš&amp;e</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage Cookies...</source>
        <translation>Spravovat cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="427"/>
        <source>Manage stored network cookies</source>
        <translation>Spravovat uložené síťové cookies</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="443"/>
        <source>Normal Messages</source>
        <translation>Normální sdělení</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="451"/>
        <source>Information Messages</source>
        <translation>Informační sdělení</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="459"/>
        <source>Warning Messages</source>
        <translation>Varovná sdělení</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="467"/>
        <source>Critical Messages</source>
        <translation>Kritická sdělení</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="364"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Ukončit qBittorr&amp;ent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="372"/>
        <source>&amp;Suspend System</source>
        <translation>U&amp;spat počítač</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="380"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Režim spánku</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="388"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Vypnout počítač</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Zakázáno</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Statistika</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Updates</source>
        <translation>Zkontrolovat aktualizace</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="419"/>
        <source>Check for Program Updates</source>
        <translation>Zkontrolovat aktualizace programu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>O &amp;aplikaci</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>Po&amp;zastavit</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>Smaza&amp;t</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>Pozastavit vš&amp;e</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>Přid&amp;at torrent soubor...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>&amp;Konec</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>Otevřít URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentace</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="345"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="401"/>
        <location filename="../gui/mainwindow.ui" line="435"/>
        <location filename="../gui/mainwindow.cpp" line="1645"/>
        <source>Show</source>
        <translation>Ukázat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1850"/>
        <source>Check for program updates</source>
        <translation>Zkontrolovat aktualizace programu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Přidat torrent link...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="356"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Pokud se Vám qBittorrent líbí, prosím přispějte!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1885"/>
        <location filename="../gui/mainwindow.cpp" line="1887"/>
        <source>Execution Log</source>
        <translation>Záznamy programu (Log)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Clear the password</source>
        <translation>Vymazat heslo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="233"/>
        <source>Filter torrent list...</source>
        <translation>Filtrovat seznam torrentů...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="203"/>
        <source>&amp;Set Password</source>
        <translation>Na&amp;stavit heslo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="171"/>
        <source>Preferences</source>
        <translation>Předvolby</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="205"/>
        <source>&amp;Clear Password</source>
        <translation>Vyma&amp;zat heslo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="256"/>
        <source>Transfers</source>
        <translation>Přenosy</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="452"/>
        <source>Torrent file association</source>
        <translation>Asociace souboru .torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="453"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent není výchozí aplikací pro otevírání souborů .torrent ani Magnet linků.
Chcete asociovat qBittorrent se soubory .torrent a Magnet linky?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="536"/>
        <source>Icons Only</source>
        <translation>Jen ikony</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="538"/>
        <source>Text Only</source>
        <translation>Jen text</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="540"/>
        <source>Text Alongside Icons</source>
        <translation>Text vedle ikon</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="542"/>
        <source>Text Under Icons</source>
        <translation>Text pod ikonama</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="544"/>
        <source>Follow System Style</source>
        <translation>Jako systémový styl</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1023"/>
        <source>UI lock password</source>
        <translation>Heslo pro zamknutí UI</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1023"/>
        <source>Please type the UI lock password:</source>
        <translation>Zadejte prosím heslo pro zamknutí UI:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Heslo musí obsahovat nejméně 3 znaky</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>Password update</source>
        <translation>Změna hesla</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>Heslo pro zamknutí UI bylo úspěšně změněno</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Opravdu chcete vymazat heslo?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="706"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="722"/>
        <source>Transfers (%1)</source>
        <translation>Přenosy (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="818"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="818"/>
        <source>Failed to add torrent: %1</source>
        <translation>Selhalo načtení torrentu: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="825"/>
        <source>Torrent added</source>
        <translation>Torrent přidán</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="825"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; byl přidán.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="831"/>
        <source>Download completion</source>
        <translation>Kompletace stahování</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="837"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Chyba I/O</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="929"/>
        <source>Recursive download confirmation</source>
        <translation>Potvrzení rekurzivního stahování</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="930"/>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="931"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="932"/>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="955"/>
        <source>Global Upload Speed Limit</source>
        <translation>Celkový limit rychlosti odesílání</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="970"/>
        <source>Global Download Speed Limit</source>
        <translation>Celkový limit rychlosti stahování</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1046"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent byl právě aktualizován a vyžaduje restart, aby se změny provedly.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1143"/>
        <source>Some files are currently transferring.</source>
        <translation>Některé soubory jsou právě přenášeny.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1143"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Určitě chcete ukončit qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1145"/>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1146"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1147"/>
        <source>&amp;Always Yes</source>
        <translation>Vžd&amp;y</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1544"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1769"/>
        <source>Old Python Interpreter</source>
        <translation>Starý překladač jazyka Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1769"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Vaše verze Pythonu %1 je zastaralá. Pro zprovoznění vyhledávačů aktualizujte na nejnovější verzi. 
Minimální požadavky: 2.7.9 / 3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1834"/>
        <source>qBittorrent Update Available</source>
        <translation>qBittorrent aktualizace k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1835"/>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation>Je k dispozici nová verze.
Chcete stáhnout %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1844"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Již používáte nejnovější verzi qBittorrentu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1779"/>
        <source>Undetermined Python version</source>
        <translation>Nezjištěná verze Pythonu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="831"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Stahování &apos;%1&apos; bylo dokončeno.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="838"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Nastala I/O chyba torrentu %1.
Důvod: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="929"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent &apos;%1&apos; obsahuje soubory .torrent, chcete je také stáhnout?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="945"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Nelze stáhnout soubor z URL: &apos;%1&apos;, důvod: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1750"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>Python byl nalezen v %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1779"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>Nelze zjistit verzi Pythonu (%1). Vyhledávač vypnut.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1790"/>
        <location filename="../gui/mainwindow.cpp" line="1802"/>
        <source>Missing Python Interpreter</source>
        <translation>Chybí překladač jazyka Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1791"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Pro použití vyhledávačů je vyžadován Python, ten ale není nainstalován.
Chcete jej nyní nainstalovat?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1802"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Pro použití vyhledávačů je vyžadován Python, ten ale není nainstalován.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1845"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Nejsou žádné aktualizace.
Již používáte nejnovější verzi.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1849"/>
        <source>&amp;Check for Updates</source>
        <translation>Zkontrolovat aktualiza&amp;ce</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2010"/>
        <source>Checking for Updates...</source>
        <translation>Kontrolování aktualizací...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2011"/>
        <source>Already checking for program updates in the background</source>
        <translation>Kontrola aktualizací programu již probíha na pozadí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2027"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python nalezen v &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2096"/>
        <source>Download error</source>
        <translation>Chyba stahování</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2096"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Instalační soubor Pythonu nelze stáhnout, důvod: %1.
Nainstalujte jej prosím ručně.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <location filename="../gui/mainwindow.cpp" line="1038"/>
        <source>Invalid password</source>
        <translation>Neplatné heslo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="672"/>
        <location filename="../gui/mainwindow.cpp" line="683"/>
        <location filename="../gui/mainwindow.cpp" line="685"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="944"/>
        <source>URL download error</source>
        <translation>Chyba stahování URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1038"/>
        <source>The password is invalid</source>
        <translation>Heslo je neplatné</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1529"/>
        <location filename="../gui/mainwindow.cpp" line="1536"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Rychlost stahování: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1532"/>
        <location filename="../gui/mainwindow.cpp" line="1538"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Rychlost odesílání: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1551"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[S: %1, O: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1645"/>
        <source>Hide</source>
        <translation>Skrýt</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1141"/>
        <source>Exiting qBittorrent</source>
        <translation>Ukončování qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1340"/>
        <source>Open Torrent Files</source>
        <translation>Otevřít torrent soubory</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1341"/>
        <source>Torrent Files</source>
        <translation>Torrent soubory</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1391"/>
        <source>Options were saved successfully.</source>
        <translation>Nastavení bylo úspěšně uloženo.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Vašedynamická DNS byla úspěšně aktualizována.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Chyba dynamické DNS: Služba je dočasně nedostupná, akce bude opakována za 30 minut.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Chyba dynamické DNS: poskytnutý název hostitele pod tímto účtem neexistuje.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Chyba dynamické DNS: neplatné jméno/heslo.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Chyba dynamické DNS: qBittorrent je na černé listině této služby, nahlašte prosím chybu na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Chyba dynamické DNS: služba odpověděla %1, nahlašte prosím chybu na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Chyba dynamické DNS: Vaše přihlašovací jméno bylo zablokováno v důsledku zneužití.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Chyba dynamické DNS: poskytnutý doménový název je neplatný.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Chyba dynamické DNS: poskytnuté přihlašovací jméno je příliš krátké.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Chyba dynamické DNS: poskytnuté heslo je příliš krátké.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="105"/>
        <source>I/O Error</source>
        <translation>Chyba I/O</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="118"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>Velikost souboru je %1. Přesahuje limit pro stažení %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="187"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Neočekávané přesměrování na magnet URI.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="433"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>GeoIP databáze načtena. Typ: %1. Čas sestavení: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="454"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>Nelze načíst GeoIP databáze. Důvod: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela, Bolívarovská republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Viet Nam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <location filename="../base/net/geoipmanager.cpp" line="397"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="143"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>United Arab Emirates</source>
        <translation>Spojené arabské emiráty</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>Afghanistan</source>
        <translation>Afghánistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua a Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Albania</source>
        <translation>Albánie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Armenia</source>
        <translation>Arménie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Antarctica</source>
        <translation>Antarktida</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>American Samoa</source>
        <translation>Americká Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Austria</source>
        <translation>Rakousko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Australia</source>
        <translation>Austrálie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Azerbaijan</source>
        <translation>Ázerbájdžán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosna a Hercegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Bangladesh</source>
        <translation>Bangladéš</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Belgium</source>
        <translation>Belgie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Bulgaria</source>
        <translation>Bulharsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bahrain</source>
        <translation>Bahrajn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Bermuda</source>
        <translation>Bermudy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Brunei Darussalam</source>
        <translation>Brunej</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Brazil</source>
        <translation>Brazílie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Bahamas</source>
        <translation>Bahamy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bhutan</source>
        <translation>Bhútán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bouvet Island</source>
        <translation>Bouvetův ostrov</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Belarus</source>
        <translation>Bělorusko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Canada</source>
        <translation>Kanada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Kokosové ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Kongo, Demokratická republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Central African Republic</source>
        <translation>Středoafrická republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Congo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Switzerland</source>
        <translation>Švýcarsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cook Islands</source>
        <translation>Cookovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Cameroon</source>
        <translation>Kamerun</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>China</source>
        <translation>Čína</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Colombia</source>
        <translation>Kolumbie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Costa Rica</source>
        <translation>Kostarika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cuba</source>
        <translation>Kuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cape Verde</source>
        <translation>Kapverdy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Christmas Island</source>
        <translation>Vánoční ostrov</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Cyprus</source>
        <translation>Kypr</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Czech Republic</source>
        <translation>Česká republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Germany</source>
        <translation>Německo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Djibouti</source>
        <translation>Džibutsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Denmark</source>
        <translation>Dánsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Dominica</source>
        <translation>Dominika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominican Republic</source>
        <translation>Dominikánská republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Algeria</source>
        <translation>Alžírsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Ecuador</source>
        <translation>Ekvádor</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Estonia</source>
        <translation>Estonsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Egypt</source>
        <translation>Egypt</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Western Sahara</source>
        <translation>Západní Sahara</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Spain</source>
        <translation>Španělsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Ethiopia</source>
        <translation>Etiopie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Finland</source>
        <translation>Finsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Fiji</source>
        <translation>Fidži</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Falklandy, Malvíny</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Micronesia, Federated States of</source>
        <translation>Federativní státy Mikronésie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Faroe Islands</source>
        <translation>Faerské ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>France</source>
        <translation>Francie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>United Kingdom</source>
        <translation>Spojené království</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Georgia</source>
        <translation>Gruzie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>French Guiana</source>
        <translation>Francouzská Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Greenland</source>
        <translation>Grónsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Gambia</source>
        <translation>Gambie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Equatorial Guinea</source>
        <translation>Rovníková Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Greece</source>
        <translation>Řecko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Jižní Georgie a Jižní Sandwichovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Hong Kong</source>
        <translation>Hongkong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Heardův ostrov a McDonaldovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Croatia</source>
        <translation>Chorvatsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Hungary</source>
        <translation>Maďarsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Indonesia</source>
        <translation>Indonésie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Ireland</source>
        <translation>Irsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Israel</source>
        <translation>Izrael</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>India</source>
        <translation>Indie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>British Indian Ocean Territory</source>
        <translation>Britské indickooceánské území</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Iraq</source>
        <translation>Irák</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Írán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iceland</source>
        <translation>Island</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Italy</source>
        <translation>Itálie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jamaica</source>
        <translation>Jamajka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jordan</source>
        <translation>Jordánsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Japan</source>
        <translation>Japonsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Kenya</source>
        <translation>Keňa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kyrgyzstan</source>
        <translation>Kyrgyzstán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Cambodia</source>
        <translation>Kambodža</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Comoros</source>
        <translation>Komory</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Svatý Kryštof a Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Korejská lidově demokratická republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Republic of</source>
        <translation>Korea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Kuwait</source>
        <translation>Kuvajt</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Cayman Islands</source>
        <translation>Kajmanské ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Kazakhstan</source>
        <translation>Kazachstán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lebanon</source>
        <translation>Libanon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Saint Lucia</source>
        <translation>Svatá Lucie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Liechtenstein</source>
        <translation>Lichtenštejnsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Sri Lanka</source>
        <translation>Srí Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Liberia</source>
        <translation>Libérie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lithuania</source>
        <translation>Litva</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Luxembourg</source>
        <translation>Lucembursko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Latvia</source>
        <translation>Lotyšsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Morocco</source>
        <translation>Maroko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Monaco</source>
        <translation>Monako</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Moldova, Republic of</source>
        <translation>Moldavsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Madagascar</source>
        <translation>Madagaskar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Marshall Islands</source>
        <translation>Marshallovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Myanmar</source>
        <translation>Myanmar, Barma</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Mongolia</source>
        <translation>Mongolsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Northern Mariana Islands</source>
        <translation>Severní Mariany</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Martinique</source>
        <translation>Martinik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mauritania</source>
        <translation>Mauritánie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Mauritius</source>
        <translation>Mauricius</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Maldives</source>
        <translation>Maledivy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Mexico</source>
        <translation>Mexiko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Malaysia</source>
        <translation>Malajsie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Mozambique</source>
        <translation>Mosambik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Namibia</source>
        <translation>Namibie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>New Caledonia</source>
        <translation>Nová Kaledonie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Norfolk Island</source>
        <translation>Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Nigeria</source>
        <translation>Nigérie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nicaragua</source>
        <translation>Nikaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Netherlands</source>
        <translation>Nizozemsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Norway</source>
        <translation>Norsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Nepal</source>
        <translation>Nepál</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>New Zealand</source>
        <translation>Nový Zéland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Oman</source>
        <translation>Omán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>French Polynesia</source>
        <translation>Francouzská Polynésie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Papua New Guinea</source>
        <translation>Papua-Nová Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Philippines</source>
        <translation>Filipíny</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Pakistan</source>
        <translation>Pákistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Poland</source>
        <translation>Polsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint-Pierre a Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Puerto Rico</source>
        <translation>Portoriko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Portugal</source>
        <translation>Portugalsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Qatar</source>
        <translation>Katar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Reunion</source>
        <translation>Réunion</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Romania</source>
        <translation>Rumunsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Russian Federation</source>
        <translation>Rusko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Saudi Arabia</source>
        <translation>Saúdská Arábie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Solomon Islands</source>
        <translation>Šalamounovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Seychelles</source>
        <translation>Seychely</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Sudan</source>
        <translation>Súdán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sweden</source>
        <translation>Švédsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Slovenia</source>
        <translation>Slovinsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Špicberky a Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Slovakia</source>
        <translation>Slovensko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Somalia</source>
        <translation>Somálsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Sao Tome and Principe</source>
        <translation>Svatý Tomáš a Princův ostrov</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>El Salvador</source>
        <translation>Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Syrian Arab Republic</source>
        <translation>Sýrie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Swaziland</source>
        <translation>Svazijsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Turks and Caicos Islands</source>
        <translation>Turks a Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Chad</source>
        <translation>Čad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>French Southern Territories</source>
        <translation>Francouzská jižní a antarktická území</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Thailand</source>
        <translation>Thajsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Tajikistan</source>
        <translation>Tádžikistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Tunisia</source>
        <translation>Tunisko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="422"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>Nebylo možné rozbalit soubor databáze GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Timor-Leste</source>
        <translation>Východní Timor</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolívie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Karibské Nizozemsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Pobřeží slonoviny</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Libya</source>
        <translation>Libye</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Saint Martin (French part)</source>
        <translation>Svatý Martin (francouzská část)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Makedonie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Pitcairn</source>
        <translation>Pitcairnovy ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Palestine, State of</source>
        <translation>Palestina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Svatá Helena, Ascension a Tristan da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>South Sudan</source>
        <translation>Jižní Súdán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Svatý Martin (nizozemská část)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Turkey</source>
        <translation>Turecko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad a Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Taiwan</source>
        <translation>Taiwan, Čínská republika (ROC)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Ukraine</source>
        <translation>Ukrajina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Menší odlehlé ostrovy Spojených států amerických</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States</source>
        <translation>Spojené státy americké</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Svatý stolec (Vatikán)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Svatý Vincenc a Grenadiny</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Virgin Islands, British</source>
        <translation>Britské Panenské ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Americké Panenské ostrovy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis a Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Yemen</source>
        <translation>Jemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Serbia</source>
        <translation>Srbsko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>South Africa</source>
        <translation>Jihoafrická republika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Zambia</source>
        <translation>Zambie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Montenegro</source>
        <translation>Černá Hora</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aland Islands</source>
        <translation>Ålandy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Isle of Man</source>
        <translation>Ostrov Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Saint Barthelemy</source>
        <translation>Svatý Bartoloměj</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="443"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>Stažená GeoIP databáze nelze uložit.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="446"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>GeoIP databáze aktualizována.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="461"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>Nelze stáhnout GeoIP databázi. Důvod: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="129"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Podpora UPnP / NAT-PMP [ZAP]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="145"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Podpora UPnP / NAT-PMP [VYP]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="509"/>
        <source>Email Notification Error:</source>
        <translation>Chyba upozornění e-mailem:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdlg.ui" line="14"/>
        <source>Options</source>
        <translation>Možnosti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="52"/>
        <source>Behavior</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="57"/>
        <source>Downloads</source>
        <translation>Stahování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="62"/>
        <source>Connection</source>
        <translation>Připojení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="67"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="82"/>
        <source>Web UI</source>
        <translation>Web UI</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="87"/>
        <source>Advanced</source>
        <translation>Pokročilé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="133"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>Jazyk uživatelského rozhraní:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(Vyžaduje restart)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="197"/>
        <source>Transfer List</source>
        <translation>Seznam přenosů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation>Potvrdit smazání torrentu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Použít střídající se barvu řádků</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation>Skrýt nulové a nekonečné hodnoty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="233"/>
        <source>Always</source>
        <translation>Vždy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation>Pouze pozastavené torrenty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="267"/>
        <source>Action on double-click</source>
        <translation>Akce po dvojkliku</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation>Stahování torrentů:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="293"/>
        <location filename="../gui/optionsdlg.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Spustit / Zastavit torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="298"/>
        <location filename="../gui/optionsdlg.ui" line="324"/>
        <source>Open destination folder</source>
        <translation>Otevřít cílový adresář</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="303"/>
        <location filename="../gui/optionsdlg.ui" line="329"/>
        <source>No action</source>
        <translation>Žádná akce</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>Dokončené torrenty:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="343"/>
        <source>Desktop</source>
        <translation>Plocha</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Spustit qBittorrent po spuštění Windows</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation>Zobrazit úvodní obrazovku při startu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>Spustit qBittorrent minimalizovaně</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Potvrzení při ukončení, jsou-li torrenty aktivní</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Potvrzení při automatickém ukončení, jsou-li torrenty dokončeny</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="538"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1111"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Upozornění emailem při dokončení stahování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1206"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Spustit externí program při dokončení stažení torrentu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1692"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Filtrování IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1882"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Plánovat použití alternativních omezení rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2236"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2264"/>
        <source>&amp;Torrent Queueing</source>
        <translation>Řazení torrentů do fronty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2614"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Odesílat torrenty dokud není dosaženo jejich časového limitu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2647"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>Automaticky přidat tyto trackery k novým stahováním:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2720"/>
        <source>RSS Reader</source>
        <translation>RSS čtečka</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2726"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Zapnout načítání RSS feedů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2735"/>
        <source>Feeds refresh interval:</source>
        <translation>Interval obnovení feedů:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2745"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Maximální počet článků na feed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2579"/>
        <location filename="../gui/optionsdlg.ui" line="2755"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation>min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2799"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Automatické RSS stahování torrentů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2805"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Zapnout automatické RSS stahování torrentů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2812"/>
        <source>Edit auto downloading rules...</source>
        <translation>Upravit pravidla automatického stahování...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2882"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Webové uživatelské rozhraní (vzdálená správa)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2896"/>
        <source>IP address:</source>
        <translation>IP adresa:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2903"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>IP adresa ke které bude Web UI přiřazeno.
Zvolte IPv4 nebo IPv6 adresu. Můžete zadat &quot;0.0.0.0&quot; pro jakoukoliv IPv4 adresu,
&quot;::&quot; pro jakoukoliv IPv6 adresu, nebo &quot;*&quot; pro jakékoliv IPv4 nebo IPv6 adresy.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2936"/>
        <source>Server domains:</source>
        <translation>Domény serveru:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2943"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>Seznam povolených pro filtrování hodnot HTTP hlaviček hostitele.
Pro obranu proti DNS rebinding útokům
best měli vložit doménové názvy použité pro WebUI server.

Použijte &apos;;&apos; pro oddělení více položek. Můžete použít masku &apos;*&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2966"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>Použít HTTPS místo HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3105"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Přeskočit ověření klientů na místní síti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3112"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Přeskočit ověření klientů na seznamu povolených IP podsítí</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3125"/>
        <source>IP subnet whitelist...</source>
        <translation>Seznam povolených IP podsítí...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3174"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Aktualizovat můj dynamické doménový název (DDNS)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimalizovat qBittorrent do oznamovací oblasti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Zavírat qBittorrent do oznamovací oblasti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>Styl ikony v oznamovací oblasti:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="429"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochromatický (Tmavý motiv)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochromatický (Světlý motiv)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="452"/>
        <source>File association</source>
        <translation>Asociace souborů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Použít qBittorent pro soubory .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Použít qBittorent pro Magnet linky </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="478"/>
        <source>Power Management</source>
        <translation>Správa napájení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="484"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Zakázat uspání počítače existují-li aktivní torrenty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="514"/>
        <source>Save path:</source>
        <translation>Uložit do:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="531"/>
        <source>Backup the log file after:</source>
        <translation>Zálohovat log soubor po:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="574"/>
        <source>Delete backup logs older than:</source>
        <translation>Smazat log soubor starší než:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="598"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>dnů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="603"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>měsíců</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="608"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>roky</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="682"/>
        <source>When adding a torrent</source>
        <translation>Při přidání torrentu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="700"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Dialog torrentu do popředí</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="723"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Nespouštět stahování automaticky</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="730"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>Má být .torrent soubor po přidání smazán</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="745"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Smazat i .torrent soubory, jejichž přidání bylo zrušeno</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="748"/>
        <source>Also when addition is cancelled</source>
        <translation>Také pokud bylo přidání zrušeno</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="770"/>
        <source>Warning! Data loss possible!</source>
        <translation>Varování! Možnost ztráty dat!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="785"/>
        <source>Saving Management</source>
        <translation>Uložení nastavení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="793"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Výchozí režim správy torrentu:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="805"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>Automatický mód znamená, že různé vlastnosti torrentu (např. cesta pro uložení) se budou řídit podle příslušné kategorie</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="809"/>
        <source>Manual</source>
        <translation>Manuální</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="814"/>
        <source>Automatic</source>
        <translation>Automatický</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="837"/>
        <source>When Torrent Category changed:</source>
        <translation>Když je kategorie torrentu změněna:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="847"/>
        <source>Relocate torrent</source>
        <translation>Přemístit torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="852"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>přepnout torrent do ručního módu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="875"/>
        <source>When Default Save Path changed:</source>
        <translation>Při změně výchozí cesty pro uložení:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="888"/>
        <location filename="../gui/optionsdlg.ui" line="929"/>
        <source>Relocate affected torrents</source>
        <translation>Přemístit dotčené torrenty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="893"/>
        <location filename="../gui/optionsdlg.ui" line="934"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Přepnout dotčené torrenty do ručního módu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="916"/>
        <source>When Category changed:</source>
        <translation>Při změně kategorie:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="959"/>
        <source>Use Subcategories</source>
        <translation>Použít podkategorie</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="978"/>
        <source>Default Save Path:</source>
        <translation>Výchozí cesta pro uložení:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="992"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Ponechat nedokončené torrenty v:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="985"/>
        <source>Copy .torrent files to:</source>
        <translation>Kopírovat .torrent soubory do:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Zobrazit qBittorrent v oznamovací oblasti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="494"/>
        <source>&amp;Log file</source>
        <translation>Soubor logů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="688"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Zobrazit obsah torrentu a některé volby</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="713"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>Vytvořit podadresář pro torrent s více soubory</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="733"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>Později smazat .torrent soubory</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="971"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopírovat .torrent soubory dokončených stahování do:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1010"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Předem vyhradit místo na disku pro všechny soubory</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1017"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Přidat příponu .!qB k nedokončeným souborům</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1027"/>
        <source>Automatically add torrents from:</source>
        <translation>Automaticky přidávat .torrent soubory z:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1074"/>
        <source>Add entry</source>
        <translation>Přidat položku</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1084"/>
        <source>Remove entry</source>
        <translation>Odstranit položku</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1135"/>
        <source>SMTP server:</source>
        <translation>SMTP server:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1157"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Tento server vyžaduje zabezpečené připojení (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1164"/>
        <location filename="../gui/optionsdlg.ui" line="3073"/>
        <source>Authentication</source>
        <translation>Ověření</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1176"/>
        <location filename="../gui/optionsdlg.ui" line="1653"/>
        <location filename="../gui/optionsdlg.ui" line="3132"/>
        <location filename="../gui/optionsdlg.ui" line="3232"/>
        <source>Username:</source>
        <translation>Uživatelské jméno:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1186"/>
        <location filename="../gui/optionsdlg.ui" line="1663"/>
        <location filename="../gui/optionsdlg.ui" line="3139"/>
        <location filename="../gui/optionsdlg.ui" line="3246"/>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1274"/>
        <source>Enabled protocol:</source>
        <translation>Zapnout protokol:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1282"/>
        <source>TCP and μTP</source>
        <translation>TCP a μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1302"/>
        <source>Listening Port</source>
        <translation>Naslouchací port</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1310"/>
        <source>Port used for incoming connections:</source>
        <translation>Port použitý pro příchozí spojení:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1330"/>
        <source>Random</source>
        <translation>Náhodný</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1352"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Použít přesměrování portů UPnP / NAT-PMP z mého routeru</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1362"/>
        <source>Use different port on each startup</source>
        <translation>Při každém spuštění použít náhodné porty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1372"/>
        <source>Connections Limits</source>
        <translation>Limit spojení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1388"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maximální počet spojení na torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1398"/>
        <source>Global maximum number of connections:</source>
        <translation>Celkový maximální počet spojení:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1437"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maximální počet odesílacích slotů na torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1447"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Celkový maximální počet odesílacích slotů:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1486"/>
        <source>Proxy Server</source>
        <translation>Proxy server</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1494"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1502"/>
        <source>(None)</source>
        <translation>(žádný)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1507"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1512"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1517"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1528"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1548"/>
        <location filename="../gui/optionsdlg.ui" line="2912"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1576"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>V opačném případě je proxy server použit pouze pro připojení k trackeru</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1579"/>
        <source>Use proxy for peer connections</source>
        <translation>Použít proxy pro připojení k protějškům</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1588"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Zakázat připojení nepodporovaná připojením proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1598"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;More information&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1623"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>RSS zdroje, vyhledávací nástroje, updaty software nebo cokoliv jiného než torrentové přenosy a související operace (jako výměny informací mezi protějšky) použijí přímé připojení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1626"/>
        <source>Use proxy only for torrents</source>
        <translation>Použít proxy pouze pro torrenty</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1639"/>
        <source>A&amp;uthentication</source>
        <translation>Ověření</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1679"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: Heslo je uloženo nešifrované</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1700"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Cesta k filtru (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1716"/>
        <source>Reload the filter</source>
        <translation>Znovunačíst filtr</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1731"/>
        <source>Manually banned IP addresses...</source>
        <translation>Seznam ručně zakázaných IP adres...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1738"/>
        <source>Apply to trackers</source>
        <translation>Použít pro trackery</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1796"/>
        <source>Global Rate Limits</source>
        <translation>Celkové limity rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1805"/>
        <location filename="../gui/optionsdlg.ui" line="1831"/>
        <location filename="../gui/optionsdlg.ui" line="2010"/>
        <location filename="../gui/optionsdlg.ui" line="2029"/>
        <location filename="../gui/optionsdlg.ui" line="2403"/>
        <location filename="../gui/optionsdlg.ui" line="2416"/>
        <source> KiB/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1821"/>
        <location filename="../gui/optionsdlg.ui" line="1993"/>
        <source>Upload:</source>
        <translation>Odesílání:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1850"/>
        <location filename="../gui/optionsdlg.ui" line="2000"/>
        <source>Download:</source>
        <translation>Stahování:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1873"/>
        <source>Alternative Rate Limits</source>
        <translation>Alternativní limity rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1148"/>
        <location filename="../gui/optionsdlg.ui" line="1894"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Od:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1128"/>
        <location filename="../gui/optionsdlg.ui" line="1918"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Do:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1945"/>
        <source>When:</source>
        <translation>Kdy:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1959"/>
        <source>Every day</source>
        <translation>Každý den</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1964"/>
        <source>Weekdays</source>
        <translation>Pracovní dny</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1969"/>
        <source>Weekends</source>
        <translation>Víkendy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2061"/>
        <source>Rate Limits Settings</source>
        <translation>Nastavení poměru sdílení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2081"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Omezit poměr sdílení protějškům na LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2074"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Použít limity rychlosti pro režijní provoz</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2067"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Použít omezení rychlosti pro uTP připojení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2139"/>
        <source>Privacy</source>
        <translation>Soukromí</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2145"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Zapnout DHT síť (decentralizovaná síť) k nalezení většího počtu protějšků</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2155"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Vyměňovat protějšky s kompatibilními klienty Bittorrent (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2158"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Zapnout Peer Exchange (PeX) k nalezení většího počtu protějšků</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2168"/>
        <source>Look for peers on your local network</source>
        <translation>Hledat protějšky na lokální síti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2171"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Zapnout místní vyhledávání k nalezení většího počtu protějšků</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2183"/>
        <source>Encryption mode:</source>
        <translation>Režim šifrování:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2191"/>
        <source>Prefer encryption</source>
        <translation>Upřednostnit šifrování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2196"/>
        <source>Require encryption</source>
        <translation>Vyžadovat šifrování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2201"/>
        <source>Disable encryption</source>
        <translation>Vypnout šifrování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2226"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Povolit při použití proxy nebo VPN připojení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2229"/>
        <source>Enable anonymous mode</source>
        <translation>Povolit anonymní režim</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2279"/>
        <source>Maximum active downloads:</source>
        <translation>Max. počet aktivních stahování:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2299"/>
        <source>Maximum active uploads:</source>
        <translation>Max. počet aktivních odesílání:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2319"/>
        <source>Maximum active torrents:</source>
        <translation>Maximální počet aktivních torrentů:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2378"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Nezapočítávat pomalé torrenty do těchto limitů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2429"/>
        <source>Upload rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2436"/>
        <source>Download rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2469"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2485"/>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2498"/>
        <source>Share Ratio Limiting</source>
        <translation>Omezení ratia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2504"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sdílet torrenty dokud ratio nedosáhne</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2524"/>
        <source>then</source>
        <translation>potom</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2625"/>
        <source>Pause them</source>
        <translation>Pozastavit je</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2630"/>
        <source>Remove them</source>
        <translation>Odstranit je</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2822"/>
        <source>RSS Smart Episode Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2956"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Použít UPnP / NAT-PMP k přesměrování portu z mého routeru</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2985"/>
        <source>Certificate:</source>
        <translation>Certifikát:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2997"/>
        <source>Import SSL Certificate</source>
        <translation>Importovat SSL certifikát</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3026"/>
        <source>Key:</source>
        <translation>Klíč:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3038"/>
        <source>Import SSL Key</source>
        <translation>Importovat SSL klíč</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3060"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Informace o certifikátech&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3149"/>
        <source>Use alternative Web UI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3161"/>
        <source>Files location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3186"/>
        <source>Service:</source>
        <translation>Služba:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3209"/>
        <source>Register</source>
        <translation>Registrovat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3218"/>
        <source>Domain name:</source>
        <translation>Doména:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="122"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Zapnutím těchto voleb můžete &lt;strong&gt;nevratně ztratit&lt;/strong&gt; vaše .torrent soubory!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="124"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Pokud jsou tyto volby zapnuty, qBittorrent &lt;strong&gt;smaže&lt;/strong&gt; .torrent soubory poté, co byly úspěšně (první možnost) nebo neúspěšně (druhá možnost) přidány do fronty pro stažení. Toto nastane &lt;strong&gt;nejen&lt;/strong&gt; u souborů otevřených pomocí volby menu &amp;ldquo;Přidat torrent&amp;rdquo;, ale také u souborů otevřených pomocí &lt;strong&gt;souborové asociace&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="129"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Pokud zapnete druhou volbu (&amp;ldquo;Také, když je přidán zrušeno&amp;rdquo;) .torrent soubor  &lt;strong&gt;bude smazán&lt;/strong&gt; i když stisknete &amp;ldquo;&lt;strong&gt;Zrušit&lt;/strong&gt;&amp;rdquo; v dialogu &amp;ldquo;Přidat torrent&amp;rdquo;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="187"/>
        <source>Choose Alternative UI files location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="276"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Podporované parametry (citlivé na velikost znaků):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="277"/>
        <source>%N: Torrent name</source>
        <translation>%N: Název torrentu</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="278"/>
        <source>%L: Category</source>
        <translation>%L: Kategorie</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="279"/>
        <source>%G: Tags (seperated by comma)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="280"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Umístění obsahu (stejné jako zdrojová cesta u vícesouborového torrentu)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="281"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Zdrojová cesta (první podadresář torrentu)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="282"/>
        <source>%D: Save path</source>
        <translation>%D: Cesta pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="283"/>
        <source>%C: Number of files</source>
        <translation>%C: Počet souborů</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="284"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Velikost torrentu (v bytech)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="285"/>
        <source>%T: Current tracker</source>
        <translation>%T: Současný tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="286"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="287"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Tip: Ohraničit parametr uvozovkami, aby nedošlo k odstřižení textu za mezerou (např. &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="360"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1498"/>
        <source>Select folder to monitor</source>
        <translation>Vyberte sledovaný adresář </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1505"/>
        <source>Folder is already being monitored:</source>
        <translation>Adresář je již sledován:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1508"/>
        <source>Folder does not exist:</source>
        <translation>Adresář neexistuje:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1511"/>
        <source>Folder is not readable:</source>
        <translation>Adresář nelze přečíst:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1522"/>
        <source>Adding entry failed</source>
        <translation>Přidání položky selhalo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="410"/>
        <location filename="../gui/optionsdlg.cpp" line="413"/>
        <location filename="../gui/optionsdlg.cpp" line="1550"/>
        <location filename="../gui/optionsdlg.cpp" line="1552"/>
        <source>Choose export directory</source>
        <translation>Vyberte adresář pro export</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="407"/>
        <location filename="../gui/optionsdlg.cpp" line="420"/>
        <location filename="../gui/optionsdlg.cpp" line="423"/>
        <source>Choose a save directory</source>
        <translation>Vyberte adresář pro ukládání</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="416"/>
        <source>Choose an IP filter file</source>
        <translation>Vyberte soubor s IP filtry</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="417"/>
        <source>All supported filters</source>
        <translation>Všechny podporované filtry</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1586"/>
        <source>SSL Certificate</source>
        <translation>SSL certifikát</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1636"/>
        <source>Parsing error</source>
        <translation>Chyba zpracování</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1636"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Nepovedlo se zpracovat poskytnutý IP filtr</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1638"/>
        <source>Successfully refreshed</source>
        <translation>Úspěšně obnoveno</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1638"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>IP filter byl úspěšně zpracován: bylo aplikováno %1 pravidel.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1611"/>
        <source>Invalid key</source>
        <translation>Neplatný klíč</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1611"/>
        <source>This is not a valid SSL key.</source>
        <translation>Toto není platný SSL klíč.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1596"/>
        <source>Invalid certificate</source>
        <translation>Neplatný certifikát</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="87"/>
        <source>Preferences</source>
        <translation>Předvolby</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1586"/>
        <source>Import SSL certificate</source>
        <translation>Importovat SSL certifikát</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1596"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Toto není platný SSL certifikát.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1601"/>
        <source>Import SSL key</source>
        <translation>Importovat SSL klíč</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1601"/>
        <source>SSL key</source>
        <translation>SSL klíč</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1761"/>
        <source>Time Error</source>
        <translation>Chyba času</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1761"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Časy zahájení a ukončení nemohou být stejné.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1770"/>
        <location filename="../gui/optionsdlg.cpp" line="1774"/>
        <source>Length Error</source>
        <translation>Chyba délky</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1770"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Uživatelské jméno pro webové rozhraní musí být nejméně 3 znaky dlouhé.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1774"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Heslo pro webové rozhraní musí být nejméně 6 znaků dlouhé.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="283"/>
        <source>Interested(local) and Choked(peer)</source>
        <translation>Zájemci(místní) a Přiškrcení(protějšek)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="289"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>zájem(místní) a uvolněný(protějšek)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="298"/>
        <source>interested(peer) and choked(local)</source>
        <translation>zájem(protějšek) a přiškrcený(místní)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>zájem(protějšek) a uvolněný(místní)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>optimistic unchoke</source>
        <translation>optimisticky uvolněný</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="319"/>
        <source>peer snubbed</source>
        <translation>lokálně zasekaný</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="326"/>
        <source>incoming connection</source>
        <translation>příchozí spojení</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="333"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>nezájem(místní) a uvolněný(protějšek)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="340"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>nezájem(protějšek) a uvolněný(místní)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="347"/>
        <source>peer from PEX</source>
        <translation>protějšek z PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="354"/>
        <source>peer from DHT</source>
        <translation>protějšek z DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="361"/>
        <source>encrypted traffic</source>
        <translation>šifrovaný přenos</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="368"/>
        <source>encrypted handshake</source>
        <translation>šifrovaný handshake</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="382"/>
        <source>peer from LSD</source>
        <translation>lokální protějšek (z LSD)</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Flags</source>
        <translation>Vlajky</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Connection</source>
        <translation>Připojení</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Průběh</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Rychlost stahování</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Rychlost odesílání</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Staženo</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Odesláno</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Důležitost</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Soubory</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="154"/>
        <source>Column visibility</source>
        <translation>Viditelnost sloupců</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="230"/>
        <source>Add a new peer...</source>
        <translation>Přidat nový protějšek...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="238"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="277"/>
        <source>Ban peer permanently</source>
        <translation>Natrvalo zakázat protějšek</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="251"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Ruční přidání protějšku &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="255"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>Protějšek &apos;%1&apos; nemohl být přidán do tohoto torrentu.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="287"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Ručně zakázat protějšek &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="261"/>
        <source>Peer addition</source>
        <translation>Přidání protějšku</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Country</source>
        <translation>Země</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="236"/>
        <source>Copy IP:port</source>
        <translation>Kopírovat IP:port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Některé protějšky nemohly být přidány. Více detailů najdete v logu.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="261"/>
        <source>The peers were added to this torrent.</source>
        <translation>Protějšky byly přidány do tohoto torrentu.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="277"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Opravdu chcete natrvalo zakázat označené protějšky?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ano</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="59"/>
        <source>No peer entered</source>
        <translation>Protějšek nezadán</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="60"/>
        <source>Please type at least one peer.</source>
        <translation>Prosím zadejte alespoň jeden protějšek.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="70"/>
        <source>Invalid peer</source>
        <translation>Neplatný protějšek</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="71"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>Protějšek &apos;%1&apos; je neplatný.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>Bílé: Nedostupné díly</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>Modré: Dostupné díly</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>Soubory v této části:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>Soubor v této části</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>Soubor v těchto částech</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Vyčkejte než bude možné zobrazit metadata pro detailnější informace</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Držte klávesu Shift pro detailní informace</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Pluginy pro vyhledávání</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Nainstalované vyhledávače:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="53"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="58"/>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="68"/>
        <location filename="../gui/search/pluginselectdlg.ui" line="134"/>
        <source>Enabled</source>
        <translation>Zapnuto</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Varování: Ujistěte se, že dodržujete zákony Vaší země o ochraně duševního vlastnictví když stahujete torrenty z kteréhokoliv z těchto vyhledávačů.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Nové vyhledávače můžete získat zde: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Nainstalovat nový</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Zkontrolovat aktualizace</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="122"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Odinstalovat</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="161"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="223"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="282"/>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="165"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="204"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="227"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="286"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="210"/>
        <source>Uninstall warning</source>
        <translation>Upozornění na odstranění</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="210"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Některé zásuvné moduly nelze odstranit, protože jsou součástí qBittorrent.
Můžete odstranit pouze moduly, které jste sami přidali.
Moduly byly alespoň vypnuty.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="212"/>
        <source>Uninstall success</source>
        <translation>Odstranění bylo úspěšné</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="212"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Vybrané zásuvné moduly byly úspěšně odstraněny</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="324"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Plugin instalován nebo aktualizován: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="344"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="351"/>
        <source>New search engine plugin URL</source>
        <translation>URL nového vyhledávacího modulu</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="345"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="352"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="349"/>
        <source>Invalid link</source>
        <translation>Neplatný odkaz</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="349"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Odkaz zřejmě neodkazuje na zásuvný modul vyhledávače.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="365"/>
        <source>Select search plugins</source>
        <translation>Vybrat vyhledávače</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="366"/>
        <source>qBittorrent search plugin</source>
        <translation>qBittorrent - vyhledávače</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="324"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="423"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="437"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="469"/>
        <source>Search plugin update</source>
        <translation>Aktualizovat vyhledávač</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="423"/>
        <source>All your plugins are already up to date.</source>
        <translation>Všechny zásuvné moduly jsou aktuální.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="437"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Nelze zkontrolovat aktualizace pluginů. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="451"/>
        <source>Search plugin install</source>
        <translation>Nainstalovat vyhledávač</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="452"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Nelze nainstalovat plugin vyhledávače &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="470"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Nelze aktualizovat plugin vyhledávače &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Zdroj zásuvného modulu</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Hledat zdroj zásuvného modulu:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="36"/>
        <source>Local file</source>
        <translation>Místní soubor</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="43"/>
        <source>Web link</source>
        <translation>Webový odkaz</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="55"/>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="64"/>
        <source>Progress</source>
        <translation>Průběh</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Preview impossible</source>
        <translation>Náhled není možný</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Je nám líto, nemůžeme zobrazit náhled tohoto souboru</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; neexistuje</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; není adresář</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; není soubor</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>Není oprávnění ke čtení pro &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>Není oprávnění k zápisu pro &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="118"/>
        <source>Not downloaded</source>
        <translation>Nestaženo</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="136"/>
        <source>N/A</source>
        <translation>není k dispozici</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="188"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Nestahovat</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="121"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Vysoká</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mix</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="124"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximální</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>Trackers</source>
        <translation>Trackery</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Protějšky</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="77"/>
        <source>HTTP Sources</source>
        <translation>HTTP zdroje</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="86"/>
        <source>Content</source>
        <translation>Obsah</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="97"/>
        <source>Speed</source>
        <translation>Rychlost</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Staženo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Dostupnost:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Přenos</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktivní po dobu:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Odh. čas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Odesláno:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Zdroje:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Rychlost stahování:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Rychlost odesílání:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Protějšky:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Omezení stahování:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Omezení odesílání:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Zahozeno:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Připojení:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Informace</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Komentář:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1023"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1030"/>
        <source>Select None</source>
        <translation>Zrušit výběr</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1106"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1101"/>
        <source>High</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Poměr sdílení:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Znovu-oznámit za:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Poslední komplet zdroj:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Celková velikost:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Části:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Vytvořil/a:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Přidáno:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Dokončeno:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Vytvořeno:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Kontrolní součet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Uložit do:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1096"/>
        <source>Maximum</source>
        <translation>Maximální</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1091"/>
        <source>Do not download</source>
        <translation>Nestahovat</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="464"/>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="471"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (má %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="416"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="419"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 toto sezení)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="428"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sdíleno %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="435"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 max)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="448"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="452"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 celkem)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="456"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="460"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 prům.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="604"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="605"/>
        <source>Open Containing Folder</source>
        <translation>Otevřít cílový adresář</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="606"/>
        <source>Rename...</source>
        <translation>Přejmenovat...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="611"/>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="659"/>
        <source>New Web seed</source>
        <translation>Nový webový seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="665"/>
        <source>Remove Web seed</source>
        <translation>Odstranit webový seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="667"/>
        <source>Copy Web seed URL</source>
        <translation>Kopírovat URL webového zdroje</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="668"/>
        <source>Edit Web seed URL</source>
        <translation>Upravit URL webového zdroje</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="696"/>
        <source>New name:</source>
        <translation>Nový název:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="731"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="769"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Tento název je již v tomto adresáři použit. Vyberte prosím jiný název.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="768"/>
        <source>The folder could not be renamed</source>
        <translation>Adresář nelze přejmenovat</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="872"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="94"/>
        <source>Filter files...</source>
        <translation>Filtrovat soubory...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="696"/>
        <source>Renaming</source>
        <translation>Přejmenování</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="701"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="730"/>
        <source>Rename error</source>
        <translation>Chyba přejmenování</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="702"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>Název je prázdný nebo obsahuje nepovolené znaky, prosím zvolte jiný.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="815"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nový URL zdroj</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="816"/>
        <source>New URL seed:</source>
        <translation>Nový URL zdroj:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="822"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="873"/>
        <source>This URL seed is already in the list.</source>
        <translation>Tento URL zdroj už v seznamu existuje.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="866"/>
        <source>Web seed editing</source>
        <translation>Úpravy webového zdroje</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="867"/>
        <source>Web seed URL:</source>
        <translation>URL webového zdroje:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="143"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 je neznámý parametr příkazové řádky.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="153"/>
        <location filename="../app/main.cpp" line="162"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 musí být jediný parametr příkazové řádky.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="185"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Nemůžete použít %1: qBittorrent pro tohoto uživatele již beží.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="521"/>
        <source>Usage:</source>
        <translation>Používání:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="524"/>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="158"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>Parametr  &apos;%1&apos; musí dodržovat syntaxi &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="204"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>Parametr &apos;%1&apos; musí dodržovat syntaxi &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="218"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>V proměnné předpokládáno celé číslo &apos;%1&apos;, ale obdrženo &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="271"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>Parametr &apos;%1&apos; musí dodržovat syntaxi &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="295"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>Předpokládáno %1 v proměnné &apos;%2&apos;, ale obdrženo &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>port</source>
        <translation>port</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="420"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 musí určovat správný port (od 1 do 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>Display program version and exit</source>
        <translation>Zobrazit verzi programu a skončit</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>Display this help message and exit</source>
        <translation>Zobrazit nápovědu a skončit</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="530"/>
        <source>Change the Web UI port</source>
        <translation>Změnit port Web UI</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="533"/>
        <source>Disable splash screen</source>
        <translation>Zakáže úvodní obrazovku</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="535"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Spustit na pozadí</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>adr</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Uložit soubory konfigurace do &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <location filename="../app/cmdoptions.cpp" line="556"/>
        <source>name</source>
        <translation>název</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Uložit soubory konfigurace v adresářích qBittorrent_ &lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Vniknout do souborů libtorrent fastresume a vztáhnout cesty k souborům podle adresáře profilu</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>files or URLs</source>
        <translation>soubory nebo URL odkazy</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Download the torrents passed by the user</source>
        <translation>Stáhnout soubory přidané uživatelem</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="563"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Určit, zda se otevře dialog &quot;Přidat nový torrent&quot; když je torrent přidáván.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Options when adding new torrents:</source>
        <translation>Volby při přidávání torrentů:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>Zkratka pro %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>path</source>
        <translation>cesta</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Torrent save path</source>
        <translation>Cesta uložení torrentu</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Add torrents as started or paused</source>
        <translation>Přidat torrenty jako spuštěné nebo pozastavené</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Skip hash check</source>
        <translation>Přeskočit kontrolu hashe</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Přiřadit torrenty do kategorie. Když kategorie neexistuje, bude vytvořena.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Download files in sequential order</source>
        <translation>Stahovat soubory v sekvenčním pořadí</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Download first and last pieces first</source>
        <translation>Stáhnout nejprve první a poslední část</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="567"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Hodnoty předvoleb mohou být zadány pomocí proměnných. Pro volt nazvanou &apos;parameter-name&apos;, je proměnná prostředí &apos;QBT_PARAMETER_NAME&apos; (velkými písmeny, znak &apos;-&apos; je nahrazen znakem &apos;_&apos;). Pro předání stavové hodnoty nastavte proměnnou na &apos;1&apos; nebo &apos;TRUE&apos;. Příklad vypnutí úvodní obrazovky: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Parametry příkazového řádku mají přednost před parametry proměnných prostředí</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="583"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="352"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Spusťte aplikaci s parametrem -h pro nápovědu příkazové řádky</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="354"/>
        <source>Bad command line</source>
        <translation>Nesprávný příkaz z příkazové řádky</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="360"/>
        <source>Bad command line: </source>
        <translation>Nesprávný příkaz z příkazové řádky:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="374"/>
        <source>Legal Notice</source>
        <translation>Právní podmínky</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="375"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="376"/>
        <source>No further notices will be issued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="388"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent je program na sdílení souborů. Spustíte-li torrent, jeho data budou zpřístupněna ostatním ke stažení. Veškerý obsah sdílíte na svou vlastní odpovědnost.

Další upozornění již nebudou zobrazena.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="377"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Stisknutím klávesy %1 souhlasíte a pokračujete...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="389"/>
        <source>Legal notice</source>
        <translation>Právní podmínky</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="390"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="391"/>
        <source>I Agree</source>
        <translation>Souhlasím</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="205"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Vzdálený server nebyl nalezen (neplatný název hostitele)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="207"/>
        <source>The operation was canceled</source>
        <translation>Operace byla zrušena</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="209"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Vzdálený server předčasně ukončil připojení, dříve než byla celá odpověď přijata a zpracována</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="211"/>
        <source>The connection to the remote server timed out</source>
        <translation>Připojení k vzdálenému serveru vypršelo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="213"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS handshake selhalo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="215"/>
        <source>The remote server refused the connection</source>
        <translation>Vzdálený server odmítl připojení</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="217"/>
        <source>The connection to the proxy server was refused</source>
        <translation>Připojení k proxy serveru bylo odmítnuto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="219"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Proxy server předčasně ukončil připojení</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="221"/>
        <source>The proxy host name was not found</source>
        <translation>Název proxy serveru nebyl nalezen</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="223"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Připojení k proxy serveru vypršelo nebo proxy dostatečně rychle neodpověděla na zaslaný požadavek</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="225"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>Proxy vyžaduje ověření, ale neakceptovala žádné z nabízených přihlašovacích údajů</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="227"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Přístup ke vzdálenému obsahu byl odepřen (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="229"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Požadovaná operace na vzdáleném obsahu není dovolena</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="231"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Vzdálený obsah nebyl na serveru nalezen (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="233"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Vzdálený server vyžaduje přihlášení, ale neakceptoval žádné z nabízených přihlašovacích údajů</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="235"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>API pro připojení k síti nemohlo akceptovat požadavek z důvodu neznámého protokolu</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="237"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Požadovaná operace je pro tento protokol neplatná</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="239"/>
        <source>An unknown network-related error was detected</source>
        <translation>Byla detekována neznámá chyba sítě</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="241"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Byla detekována neznámá chyba související s proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="243"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Byla detekována neznámá chyba související se vzdáleným obsahem</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="245"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Byla detekována chyba v protokolu</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="247"/>
        <source>Unknown error</source>
        <translation>Neznámá chyba</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="78"/>
        <source>Upgrade</source>
        <translation>Upgrade</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="68"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Provedli jute update ze starší verze, která ukládá odlišně. Musíte přejít k novému ukládacímu systému. Potom už nebudete moci použít verzi starší než v3.3.0. Pokračovat? [a/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="77"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Provedli jste update ze starší verze, která ukládá odlišně. Musíte přejít k novému ukládacímu systému. Potom už nebudete moci použít verzi starší než v3.3.0. </translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="183"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>Nelze migrovat torrent s hashem: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="186"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>Torrent nelze migrovat. Neplatný fastresume název: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="244"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>Detekováno nesprávné ukončení programu. Pro obnovení nastavení je použita dříve uložená verze.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="307"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Vyskytla se chyba při pokusu o zápis do konfiguračního souboru.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="309"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Vyskytla se chyba formátu při pokusu o zápis do konfiguračního souboru.</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="80"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="87"/>
        <source>Invalid data format.</source>
        <translation>Neplatný formát dat.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="122"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="276"/>
        <source>Invalid data format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="419"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="431"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="192"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="229"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="234"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="256"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="267"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="273"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="282"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="578"/>
        <source>Invalid RSS feed.</source>
        <translation>Neplatný RSS feed.</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="581"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (řádek: %2, sloupec: %3, offset: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="161"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>RSS feed se zadanou URL už už existuje: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="180"/>
        <source>Cannot move root folder.</source>
        <translation>Nelze přesunout kořenový adresář.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="187"/>
        <location filename="../base/rss/rss_session.cpp" line="225"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>Položka neexistuje: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="218"/>
        <source>Cannot delete root folder.</source>
        <translation>Nelze smazat kořenový adresář.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="355"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Nesprávná cesta položky RSS: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="361"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>žka RSS se zadanou cestou neexistuje: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="369"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>Nadřazený adresář neexistuje: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Získávání RSS feedů je nyní vypnuto! Můžete ho zapnout v nastavení aplikace.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nový odběr</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Označ jako přečtené.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Obnovit RSS proudy</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Aktualizovat vše</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>RSS stahovač...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrenty: (dvojklik ke stažení)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Přejmenovat...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Přejmenovat</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Aktualizace</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nový odběr...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Aktualizovat všechny feedy</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Stáhnout torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Otevřít odkaz zpráv</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Kopírovat odkaz feedů</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Nová složka...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Please choose a folder name</source>
        <translation>Vyberte název složky</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Folder name:</source>
        <translation>Název složky:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>New folder</source>
        <translation>Nová složka</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Please type a RSS feed URL</source>
        <translation>Prosím vložte odkaz RSS feedu</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Feed URL:</source>
        <translation>Odkaz feedu</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Deletion confirmation</source>
        <translation>Smazat potvrzení</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Určitě chcete smazar označené RSS feedy?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Zvolte název pro tento RSS feed, prosím</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>New feed name:</source>
        <translation>Nový název feedu:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="391"/>
        <source>Rename failed</source>
        <translation>Přejmenovaní neuspěšné</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="454"/>
        <source>Date: </source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="456"/>
        <source>Author: </source>
        <translation>Autor</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Select save location</source>
        <translation>Vybrat umístění pro uložení</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="151"/>
        <source>Monitored Folder</source>
        <translation>Sledovaný adresář</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="154"/>
        <source>Override Save Location</source>
        <translation>Přepsat umístění pro uložení</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Monitored folder</source>
        <translation>Sledovaný adresář</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Default save location</source>
        <translation>Výchozí umístění pro uložení:</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="399"/>
        <source>Browse...</source>
        <translation>Procházet...</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="66"/>
        <source>All categories</source>
        <translation>Všechny kategorie</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="67"/>
        <source>Movies</source>
        <translation>Filmy</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="68"/>
        <source>TV shows</source>
        <translation>TV seriály</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="69"/>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="70"/>
        <source>Games</source>
        <translation>Hry</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="71"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="72"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="73"/>
        <source>Pictures</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="74"/>
        <source>Books</source>
        <translation>Knihy</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="199"/>
        <source>Unknown search engine plugin file format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="213"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="241"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="244"/>
        <source>Plugin is not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="344"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="362"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="364"/>
        <source>Failed to download the plugin file. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="523"/>
        <source>An incorrect update info received.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="563"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="79"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="80"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="81"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seedeři</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="82"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecheři</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="83"/>
        <source>Search engine</source>
        <translation>Vyhledávač</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="276"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Výsledky (zobrazuje &lt;i&gt;%1&lt;/i&gt; z &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="325"/>
        <source>Torrent names only</source>
        <translation>Pouze názvy torrentů</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="326"/>
        <source>Everywhere</source>
        <translation>Všude</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="337"/>
        <source>Searching...</source>
        <translation>Hledám...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="339"/>
        <source>Search has finished</source>
        <translation>Hledání ukončeno</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="341"/>
        <source>Search aborted</source>
        <translation>Hledání přerušeno</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="343"/>
        <source>An error occurred during search...</source>
        <translation>Během hledání nastala chyba...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="345"/>
        <source>Search returned no results</source>
        <translation>Nebyly nalezeny žádné výsledky</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="369"/>
        <source>Column visibility</source>
        <translation>Viditelnost sloupců</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="14"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Výsledky(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="45"/>
        <source>Search in:</source>
        <translation>Prohledat:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nastavte minimální a maximální povolený počet seederů&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Seedy:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimální počet seederů&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="116"/>
        <location filename="../gui/search/searchtab.ui" line="204"/>
        <source>to</source>
        <translation>do</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximální počet seederů&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="126"/>
        <location filename="../gui/search/searchtab.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nastavte minimální a maximální povolenou velikost torrentu&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="170"/>
        <source>Size:</source>
        <translation>Velikost&quot;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimální velikost torrentu&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximální velikost torrentu&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="273"/>
        <location filename="../gui/search/searchwidget.cpp" line="293"/>
        <location filename="../gui/search/searchwidget.cpp" line="360"/>
        <location filename="../gui/search/searchwidget.cpp" line="368"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>Žádné vyhledávací pluginy nejsou nainstalovány.
Klikněte na tlačítko &quot;Vyhledávácí pluginy...&quot; dole vpravo v okně, abyste nějaké nainstalovali.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>Stáhnout</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>Přejít na stránku s popisem</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>Kopírovat URL stránky s popisem</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>Pluginy pro vyhledávání</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="103"/>
        <source>A phrase to search for.</source>
        <translation>Fráze k vyhledání</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="104"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Mezery v hledaném výrazu moho být chráněny uvozovkami.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="106"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Příklad:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="108"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: vyhledat &lt;b&gt;foo&lt;/b&gt; a &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="112"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: vyhledat &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="185"/>
        <source>All plugins</source>
        <translation>Všechny pluginy</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="184"/>
        <source>Only enabled</source>
        <translation>Pouze zapnuté</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="186"/>
        <source>Select...</source>
        <translation>Vybrat...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="286"/>
        <location filename="../gui/search/searchwidget.cpp" line="354"/>
        <location filename="../gui/search/searchwidget.cpp" line="356"/>
        <source>Search Engine</source>
        <translation>Vyhledávač</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="286"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Pro použití vyhledávače nainstalujte Python.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="303"/>
        <source>Empty search pattern</source>
        <translation>Prázdný hledaný řetězec</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="303"/>
        <source>Please type a search pattern first</source>
        <translation>Nejdříve napište hledaný řetězec</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="332"/>
        <source>Stop</source>
        <translation>Zastavit</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="356"/>
        <source>Search has finished</source>
        <translation>Hledání ukončeno</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="354"/>
        <source>Search has failed</source>
        <translation>Hledání selhalo</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="113"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorrent se nyní ukončí.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="114"/>
        <source>E&amp;xit Now</source>
        <translation>&amp;Ukončit nyní</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="115"/>
        <source>Exit confirmation</source>
        <translation>Potvrdit vypnutí</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="118"/>
        <source>The computer is going to shutdown.</source>
        <translation>Počítač se vypíná.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="119"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Vypnout nyní</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="123"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>Počítač přechází do režimu spánku.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="124"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Uspat nyní.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="125"/>
        <source>Suspend confirmation</source>
        <translation>Potvrzení uspání</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="128"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>Počítač přechází do režimu hibernace.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="129"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Přejít do hibernace nyní</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="130"/>
        <source>Hibernate confirmation</source>
        <translation>Potvrzení hibernace</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="140"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Můžete zrušit akci během %1 sekund.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="120"/>
        <source>Shutdown confirmation</source>
        <translation>Potvrdit vypnutí</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="84"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Upload</source>
        <translation>Odesláno celkem</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="54"/>
        <source>Total Download</source>
        <translation>Staženo celkem</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Upload</source>
        <translation>Odeslání užitečných dat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="59"/>
        <source>Payload Download</source>
        <translation>Stažení užitečných dat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Upload</source>
        <translation>Odeslání režie</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="64"/>
        <source>Overhead Download</source>
        <translation>Stažení režie</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Upload</source>
        <translation>Odeslání DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="69"/>
        <source>DHT Download</source>
        <translation>Stažení DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Upload</source>
        <translation>Odeslání tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="74"/>
        <source>Tracker Download</source>
        <translation>Stažení tracker</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="69"/>
        <source>Period:</source>
        <translation>Období:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>1 Minute</source>
        <translation>1 minuta</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>5 Minutes</source>
        <translation>5 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>30 Minutes</source>
        <translation>30 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="75"/>
        <source>6 Hours</source>
        <translation>6 hodin</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="107"/>
        <source>Select Graphs</source>
        <translation>Vybrat grafy</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Upload</source>
        <translation>Celkově odesláno</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Total Download</source>
        <translation>Staženo celkem</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Upload</source>
        <translation>Odeslání užitečných dat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Payload Download</source>
        <translation>Stažení užitečných dat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Upload</source>
        <translation>Odeslání režie</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Overhead Download</source>
        <translation>Stažení režie</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Upload</source>
        <translation>Odeslání DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>DHT Download</source>
        <translation>Stažení DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Upload</source>
        <translation>Nahrání trackeru</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="90"/>
        <source>Tracker Download</source>
        <translation>Stáhnutí trackeru</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Statistika</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Statistiky uživatele</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Statistiky vyrovnávací paměti</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Přístupy do cache pro čtení:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Průměrná doba ve frontě:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Statistiky výkonu</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>I/O úkoly ve frontě:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Přeplnění cache pro zápis:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Přetížení cache pro čtení:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Celková velikost fronty:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="105"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Stav připojení:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Žádná přímá spojení. To může značit problémy s nastavením sítě.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 uzlů</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>Je nutné restartovat qBittorrent!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Stav připojení:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. To obvykle znamená, že qBittorrent nedokázal naslouchat na portu nastaveném pro příchozí spojení.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Kliknutí přepne na alternativní limity rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Kliknutím přepnete na normální limity rychlosti</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Celkový limit rychlosti stahování</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Celkový limit rychlosti odesílání</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="137"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Vše (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="140"/>
        <source>Downloading (0)</source>
        <translation>Stahuji (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="143"/>
        <source>Seeding (0)</source>
        <translation>Sdílím (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="146"/>
        <source>Completed (0)</source>
        <translation>Dokončeno (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="149"/>
        <source>Resumed (0)</source>
        <translation>Obnoveno (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="152"/>
        <source>Paused (0)</source>
        <translation>Pozastaveno (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="155"/>
        <source>Active (0)</source>
        <translation>Aktivní (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>Inactive (0)</source>
        <translation>Neaktivní (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Errored (0)</source>
        <translation>S chybou (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="178"/>
        <source>All (%1)</source>
        <translation>Vše (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>Downloading (%1)</source>
        <translation>Stahuji (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="180"/>
        <source>Seeding (%1)</source>
        <translation>Sdílím (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="181"/>
        <source>Completed (%1)</source>
        <translation>Dokončeno (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Paused (%1)</source>
        <translation>Pozastaveno (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>Resumed (%1)</source>
        <translation>Obnoveno (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="184"/>
        <source>Active (%1)</source>
        <translation>Aktivní (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="185"/>
        <source>Inactive (%1)</source>
        <translation>Neaktivní (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="186"/>
        <source>Errored (%1)</source>
        <translation>S chybou (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="147"/>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="258"/>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>Untagged</source>
        <translation>Neoznačeno</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="113"/>
        <source>Add tag...</source>
        <translation>Přidat štítek...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove tag</source>
        <translation>Odebrat štítek</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="126"/>
        <source>Remove unused tags</source>
        <translation>Odebrat nepoužité štítky</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Pokračování torrentů</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="139"/>
        <source>Pause torrents</source>
        <translation>Pozastavení torrentů</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="145"/>
        <source>Delete torrents</source>
        <translation>Smazat torrenty</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>New Tag</source>
        <translation>Nový štítek</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>Tag:</source>
        <translation>Štítek:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Invalid tag name</source>
        <translation>Neplatný název štítku</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>Název štítku &quot;%1&quot; je neplatný</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag exists</source>
        <translation>Štítek existuje</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag name already exists.</source>
        <translation>Název štítku již existuje.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Vlastnosti kategorie torrentů</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Název:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Uložit do:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation type="unfinished">Vyberte cestu pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>Nová kategorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>Neplatný název kategorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>Název kategorie nemůže obsahovat znak &apos;\&apos;.
Název kategorie nemůže začínat/končit znakem &apos;/&apos;.
Název kategorie nemůže obsahovat sekvenci znaků &apos;//&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation>Problém s vytvořením kategorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Název kategorie již existuje.
Prosím zvolte jiný název kategorie a zkuste to znovu.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Progress</source>
        <translation>Průběh</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Download Priority</source>
        <translation>Priorita stahování</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Remaining</source>
        <translation>Zbývající</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Availability</source>
        <translation>Dostupnost</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="70"/>
        <source>Create Torrent</source>
        <translation>Vytvořit Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="148"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Důvod: Cesta k adresáři/složce není čitelná.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="148"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="182"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="194"/>
        <source>Torrent creation failed</source>
        <translation>Vytvoření torentu nebylo úspěšné</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="155"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Soubory torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="155"/>
        <source>Select where to save the new torrent</source>
        <translation>Vyberte adresář pro přidání do torrentu</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="182"/>
        <source>Reason: %1</source>
        <translation>Důvod: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="194"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Důvod: Vytvořený torrent je špatný. Nebude přidán do seznamu stahování.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="205"/>
        <source>Torrent creator</source>
        <translation>Autor torrentu</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="206"/>
        <source>Torrent created:</source>
        <translation>Torrent vytvořen:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Autor torrentu</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>Vyberte adresář/soubor ke sdílení</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="31"/>
        <source>Path:</source>
        <translation>Cesta:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[Sem přetáhněte soubory]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="68"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="111"/>
        <source>Select file</source>
        <translation>Vyber soubor</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="75"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="104"/>
        <source>Select folder</source>
        <translation>Vyber adresář</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="87"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="95"/>
        <source>Piece size:</source>
        <translation>Velikost části:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="109"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="169"/>
        <source>32 MiB</source>
        <translation>32 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="177"/>
        <source>Calculate number of pieces:</source>
        <translation>Spočítaný počet částí:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="206"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Soukromý torrent (nebude šířen na DHT síti)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="213"/>
        <source>Start seeding immediately</source>
        <translation>Začít seedovat ihned</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="223"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorovat ratio pro tento torent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="230"/>
        <source>Optimize alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="243"/>
        <source>Fields</source>
        <translation>Pole</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="249"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Skupiny nebo třídy trackerů můžete oddělit prázdnou řádkou.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="259"/>
        <source>Web seed URLs:</source>
        <translation>URL odkazy pro webseed:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="280"/>
        <source>Tracker URLs:</source>
        <translation>URL Trackeru:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="287"/>
        <source>Comments:</source>
        <translation>Komentáře:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="294"/>
        <source>Source:</source>
        <translation>Zdroj:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="309"/>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Zdroje</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Protějšky</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Rychlost stahování</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Rychlost odesílání</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Odh. čas</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Category</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Přidán</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Dokončen</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limit stahování</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limit odesílání</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Staženo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Odesláno</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Staženo po spuštění</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Odesláno po spuštění</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Zbývající</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Aktivní po dobu</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Cesta pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Dokončeno</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Omezení ratia</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Poslední komplet zdroj</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Poslední aktivita</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="125"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Celková velikost</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="313"/>
        <source>Not contacted yet</source>
        <translation type="unfinished">Dosud nekontaktován</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="315"/>
        <source>Updating...</source>
        <translation type="unfinished">Aktualizuji...</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="317"/>
        <source>Working</source>
        <translation type="unfinished">Funkční</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="319"/>
        <source>Not working</source>
        <translation type="unfinished">Nefunkční</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="509"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="692"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="703"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="714"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="725"/>
        <source>Torrent queueing must be enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="744"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="758"/>
        <source>Incorrect torrent name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="799"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="809"/>
        <source>Incorrect category name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="206"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Vše (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="209"/>
        <source>Trackerless (0)</source>
        <translation>Bez trackeru (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="212"/>
        <source>Error (0)</source>
        <translation>Chyby (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="215"/>
        <source>Warning (0)</source>
        <translation>Varování (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="259"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="314"/>
        <source>Trackerless (%1)</source>
        <translation>Bez trackeru (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="353"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="385"/>
        <source>Error (%1)</source>
        <translation>Chyby (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="400"/>
        <source>Warning (%1)</source>
        <translation>Varování (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="460"/>
        <source>Resume torrents</source>
        <translation>Obnovit torrenty</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="461"/>
        <source>Pause torrents</source>
        <translation>Pozastavit torrenty</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="462"/>
        <source>Delete torrents</source>
        <translation>Smazat torrenty</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="496"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="510"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Vše (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="586"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="587"/>
        <source>Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="588"/>
        <source>Received</source>
        <translation>Přijato</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="589"/>
        <source>Seeds</source>
        <translation>Seedy</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="590"/>
        <source>Peers</source>
        <translation>Protějšky</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="591"/>
        <source>Downloaded</source>
        <translation>Staženo</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="592"/>
        <source>Message</source>
        <translation>Zpráva</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="255"/>
        <location filename="../gui/properties/trackerlist.cpp" line="345"/>
        <source>Working</source>
        <translation>Funkční</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="256"/>
        <source>Disabled</source>
        <translation>Vypnuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="277"/>
        <source>This torrent is private</source>
        <translation>Tento torrent je soukromý</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="349"/>
        <source>Updating...</source>
        <translation>Aktualizuji...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="353"/>
        <source>Not working</source>
        <translation>Nefunkční</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="357"/>
        <source>Not contacted yet</source>
        <translation>Dosud nekontaktován</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="456"/>
        <source>Tracker URL:</source>
        <translation>URL trackeru:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="456"/>
        <source>Tracker editing</source>
        <translation>Upravit tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="461"/>
        <location filename="../gui/properties/trackerlist.cpp" line="471"/>
        <source>Tracker editing failed</source>
        <translation>Úprava trackeru selhala</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="461"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>Zadaná URL trackeru je neplatná.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="471"/>
        <source>The tracker URL already exists.</source>
        <translation>Tato URL trackeru již existuje.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="525"/>
        <source>Add a new tracker...</source>
        <translation>Přidat nový tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="531"/>
        <source>Copy tracker URL</source>
        <translation>Kopírovat URL trackeru</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="532"/>
        <source>Edit selected tracker URL</source>
        <translation>Upravit označenou URL trackeru</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="537"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Vynutit oznámení vybraným trackerům</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="539"/>
        <source>Force reannounce to all trackers</source>
        <translation>Vynutit oznámení všem trackerům</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="612"/>
        <source>Column visibility</source>
        <translation>Zobrazení sloupců</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="530"/>
        <source>Remove tracker</source>
        <translation>Odstranit tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Dialog pro přidání trackeru</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Seznam trackerů pro přidání (jeden na řádek):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Seznam URL kompatibilní s µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="84"/>
        <source>I/O Error</source>
        <translation>Chyba I/O</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="84"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Chyba při pokusu o otevření staženého souboru.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="122"/>
        <source>No change</source>
        <translation>Žádná změna</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="122"/>
        <source>No additional trackers were found.</source>
        <translation>Nebyly nalezeny žádné další trackery.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="130"/>
        <source>Download error</source>
        <translation>Chyba stahování</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="130"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Seznam trackerů nemohl být stažen, důvod: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="232"/>
        <source>Downloading</source>
        <translation>Stahuji</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="238"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Stahuji metadata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="244"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Přiděluji místo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="270"/>
        <source>Paused</source>
        <translation>Pozastaveno</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="255"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Zařazeno do fronty</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="248"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sdílím</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="235"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Pozastaveno</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="241"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Stahuji</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="251"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sdílím</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="259"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Kontroluji</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="263"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>Ve frontě na kontrolu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="267"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Kontrola dat pro obnovení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="273"/>
        <source>Completed</source>
        <translation>Dokončeno</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="276"/>
        <source>Missing Files</source>
        <translation>Chybějící soubory</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="279"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>S chybou</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="128"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sdíleno %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="189"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>před %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="590"/>
        <source>Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="598"/>
        <source>Categories</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="617"/>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="635"/>
        <source>Trackers</source>
        <translation>Trackery</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="699"/>
        <source>Column visibility</source>
        <translation>Zobrazení sloupců</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="394"/>
        <source>Choose save path</source>
        <translation>Vyberte cestu pro uložení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="612"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limit rychlosti stahování torrentu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="637"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limit rychlosti odesílání torrentu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="681"/>
        <source>Recheck confirmation</source>
        <translation>Zkontrolovat potvrzení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="681"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Opravdu chcete znovu zkontrolovat označené torrenty?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="828"/>
        <source>Rename</source>
        <translation>Přejmenovat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="828"/>
        <source>New name:</source>
        <translation>Nový název:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="863"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Vynutit obnovení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="865"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pozastavit</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="401"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>Nastavit umístění: přesunout &quot;%1&quot;, z &quot;%2&quot; do &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="770"/>
        <source>Add Tags</source>
        <translation>Přidat Štítek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="778"/>
        <source>Remove All Tags</source>
        <translation>Odstranit všechny Štítky</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="778"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Smazat všechny štítky z označených torrentů?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="792"/>
        <source>Comma-separated tags:</source>
        <translation>Čárkou oddelěné štítky:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="799"/>
        <source>Invalid tag</source>
        <translation>Neplatný štítek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="800"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>Název štítku: &apos;%1&apos; je neplatný</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Preview file...</source>
        <translation>Náhled souboru...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Limit share ratio...</source>
        <translation>Omezit ratio...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="875"/>
        <source>Limit upload rate...</source>
        <translation>Omezit rychlost odesílání...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="877"/>
        <source>Limit download rate...</source>
        <translation>Omezit rychlost stahování...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="879"/>
        <source>Open destination folder</source>
        <translation>Otevřít cílový adresář</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Přesunout nahoru</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="883"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Přesunout dolů</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="885"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Přesunout na začátek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="887"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Přesunout na konec</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="889"/>
        <source>Set location...</source>
        <translation>Nastavit umístění...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="893"/>
        <source>Force reannounce</source>
        <translation>Vynutit oznámení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="897"/>
        <source>Copy name</source>
        <translation>Kopírovat název</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="899"/>
        <source>Copy hash</source>
        <translation>Zkopírovat hash</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="909"/>
        <source>Download first and last pieces first</source>
        <translation>Stáhnout nejdříve první a poslední část</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="912"/>
        <source>Automatic Torrent Management</source>
        <translation>Automatická správa torrentu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="914"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatický mód znamená, že různé vlastnosti torrentu (např. cesta pro uložení) se budou řídit podle příslušné kategorie</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1021"/>
        <source>Category</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1022"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nový...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1023"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Resetovat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1040"/>
        <source>Tags</source>
        <translation>Štítky</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1041"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Přidat...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1042"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Odstranit vše</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1104"/>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="891"/>
        <source>Force recheck</source>
        <translation>Vynutit překontrolování</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="895"/>
        <source>Copy magnet link</source>
        <translation>Kopírovat Magnet link</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="901"/>
        <source>Super seeding mode</source>
        <translation>Mód super sdílení</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="904"/>
        <source>Rename...</source>
        <translation>Přejmenovat...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="906"/>
        <source>Download in sequential order</source>
        <translation>Stahovat postupně</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Omezení ratia pro odesílání/stahování torrentu</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global share limit</source>
        <translation>Nastavení globálního limitu sdílení</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no share limit</source>
        <translation>Nastavit sdílení bez limitu</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set share limit to</source>
        <translation>Nastavit limit sdílení na</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="100"/>
        <source>ratio</source>
        <translation>ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="107"/>
        <source>minutes</source>
        <translation>minuty</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="84"/>
        <source>No share limit method selected</source>
        <translation>Nevybrána žádná metoda omezování sdílení</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="85"/>
        <source>Please select a limit method first</source>
        <translation>Nejdříve prosím vyberte způsob omezování sdílení</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="217"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="224"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="466"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="667"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="676"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="693"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="725"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Webové rozhraní: HTTPS nastaveno úspěšně</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Web UI: Nastavení HTTPS selhalo, přecházím zpět na HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Webové rozhraní naslouchá na IP: %1, portu: %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Webové rozhraní: Nelze vázat na IP: % 1, port: % 2. Důvod: % 3</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="71"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Pokročilý BitTorrent klient naprogramován v jazyce C++, založený na Qt toolkit a libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="72"/>
        <source>Copyright %1 2006-2018 The qBittorrent project</source>
        <translation>Copyright %1 2006-2018 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="73"/>
        <source>Home Page:</source>
        <translation>Domovská stránka:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="74"/>
        <source>Forum:</source>
        <translation>Fórum:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="75"/>
        <source>Bug Tracker:</source>
        <translation>Sledování chyb:</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Přidaní Peerů</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Seznam peerů, které chcete přidat (jednu IP na řádek):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formát: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Ověření trackeru</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Přihlášení</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Uživatelské jméno:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Potvrzení o smazání</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Zapamatovat volbu</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Smazat soubory také z pevného disku</translation>
    </message>
</context>
<context>
    <name>confirmShutdownDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>Znovu nezobrazovat</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Přidat odkazy torrentů</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Stahovat z URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Jeden odkaz na jeden řádek (odkazy HTTP, Magnet linky odkazy a info-hashes jsou podporovány)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="56"/>
        <source>Download</source>
        <translation>Stahovat</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="111"/>
        <source>No URL entered</source>
        <translation>Nebylo vloženo žádné URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="111"/>
        <source>Please type at least one URL.</source>
        <translation>Prosím napište alespoň jedno URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Info o pádu</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="93"/>
        <source>Downloads</source>
        <translation>Stahování</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="81"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="87"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="291"/>
        <source>Python not detected</source>
        <translation>Python nebyl nalezen</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="320"/>
        <source>Python version: %1</source>
        <translation>Verze Pythonu: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="333"/>
        <source>Normalized Python version: %1</source>
        <translation>Normalizovaná verze Pythonu: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="379"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="471"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="476"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="372"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Neznámá</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="127"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Jsou staženy všechny torrenty, qBittorrent nyní vypne počítač.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="462"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="466"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Výběr náhledu</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Následující soubory podporují náhled, vyberte prosím jeden z nich:</translation>
    </message>
</context>
<context>
    <name>trackerLogin</name>
    <message>
        <location filename="../gui/trackerlogin.cpp" line="47"/>
        <source>Log in</source>
        <translation>Přihlásit se</translation>
    </message>
</context>
</TS>
