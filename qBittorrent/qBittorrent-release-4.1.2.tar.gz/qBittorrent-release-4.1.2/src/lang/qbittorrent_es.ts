<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation type="unfinished">Acerca de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation type="unfinished">Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation type="unfinished">Autor</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation type="unfinished">Encargado actual</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation type="unfinished">Grecia</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation type="unfinished">Nacionalidad:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation type="unfinished">E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation type="unfinished">Autor original</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation type="unfinished">Francia</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation type="unfinished">Agradecimientos especiales</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation type="unfinished">Traductores</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="293"/>
        <source>License</source>
        <translation type="unfinished">Licencia</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="319"/>
        <source>Libraries</source>
        <translation type="unfinished">Bibliotecas</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="325"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation type="unfinished">qBittorrent fue compilado con las siguientes librerías:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="70"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation type="unfinished">Un cliente BitTorrent avanzado programado en C++, basado en el toolkit Qt y en libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="71"/>
        <source>Copyright %1 2006-2018 The qBittorrent project</source>
        <translation type="unfinished">Copyright %1 2006-2018 El proyecto qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="72"/>
        <source>Home Page:</source>
        <translation type="unfinished">Página Web:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="73"/>
        <source>Forum:</source>
        <translation type="unfinished">Foro: </translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="74"/>
        <source>Bug Tracker:</source>
        <translation type="unfinished">Bug Tracker: </translation>
    </message>
</context>
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation type="vanished">Acerca de qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="vanished">Acerca de</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="vanished">Autor</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation type="vanished">Nacionalidad:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="vanished">Nombre:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="vanished">E-mail:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="vanished">Grecia</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation type="vanished">Encargado actual</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation type="vanished">Autor original</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation type="vanished">Agradecimientos especiales</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation type="vanished">Traductores</translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation type="vanished">Bibliotecas</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation type="vanished">qBittorrent fue compilado con las siguientes librerías:</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="vanished">Francia</translation>
    </message>
    <message>
        <source>License</source>
        <translation type="vanished">Licencia</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Guardar en</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>No volver a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Propiedades del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>Establecer como categoría predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="204"/>
        <source>Torrent information</source>
        <translation>Información del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>No comprobar hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="223"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="271"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="250"/>
        <source>Date:</source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Modo de administración del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Remember last used save path</source>
        <translation>Recordar la ultima ubicación</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Al activarse, el archivo .torrent no sera borrado, no importa cual sea la configuración de &quot;Descargas&quot; de las opciones.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>No eliminar el archivo .torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>Crear subcarpeta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="187"/>
        <source>Download in sequential order</source>
        <translation type="unfinished">Descargar en orden secuencial</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="194"/>
        <source>Download first and last pieces first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="376"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="381"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="386"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="391"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="275"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="281"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="706"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Invalid torrent</source>
        <translation>Torrent inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="492"/>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="497"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="522"/>
        <source>Rename error</source>
        <translation>Error al renombrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="498"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation> El nombre está vacío o contiene caracteres prohibidos, por favor, elija uno diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="732"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="733"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="741"/>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>Invalid magnet link</source>
        <translation>Enlace magnet inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="275"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>El archivo torrent &apos;%1&apos; no existe.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="281"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>El archivo torrent &apos;%1&apos; no puede ser leído del disco.
Probablemente no tengas permisos suficientes.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Fallo al cargar el torrent: %1
Error: %2</translation>
    </message>
    <message>
        <source>Already in the download list</source>
        <translation type="vanished">Ya está en la lista de descargas</translation>
    </message>
    <message>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers weren&apos;t merged because it is a private torrent.</source>
        <translation type="vanished">El torrent &apos;%1&apos; ya está en la lista de descargas. Los Trackers no fueron fusionados porque el torrent es privado.</translation>
    </message>
    <message>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation type="vanished">El torrent &apos;%1&apos; ya está en la lista de descargas. Los Trackers fueron fusionados.</translation>
    </message>
    <message>
        <source>Cannot add torrent</source>
        <translation type="vanished">No se pudo agregar el torrent</translation>
    </message>
    <message>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation type="vanished">No se pudo agregar este torrent. Tal vez ya se esté agregando.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>This magnet link was not recognized</source>
        <translation>Este enlace magnet no pudo ser reconocido</translation>
    </message>
    <message>
        <source>Magnet link &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation type="vanished">El enlace magnet &apos;%1&apos; ya está en la lista de descargas. Los Trackers fueron fusionados.</translation>
    </message>
    <message>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation type="vanished">No se pudo agregar este torrent. Tal vez ya se esté agregando.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="354"/>
        <source>Magnet link</source>
        <translation>Enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="360"/>
        <source>Retrieving metadata...</source>
        <translation>Recibiendo metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="444"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="446"/>
        <source>Free space on disk: %1</source>
        <translation>Espacio libre en disco: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="101"/>
        <source>Choose save path</source>
        <translation>Elegir ruta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="302"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="307"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="311"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="341"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="345"/>
        <source>Torrent is already present</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="302"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="307"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="311"/>
        <source>Torrent is already queued for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="341"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="345"/>
        <source>Magnet link is already queued for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="492"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="523"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="561"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="560"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se pudo renombrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="608"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="612"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="707"/>
        <source>Invalid metadata</source>
        <translation>Metadatos inválidos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="714"/>
        <source>Parsing metadata...</source>
        <translation>Analizando metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="718"/>
        <source>Metadata retrieval complete</source>
        <translation>Recepción de metadatos completa</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="773"/>
        <source>Download Error</source>
        <translation>Error de descarga</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="252"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="385"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Puertos de salida (Min) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="390"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Puertos de salida (Máx) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="400"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar torrents completados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="406"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de actualización de la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="123"/>
        <source>Setting</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="123"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="248"/>
        <location filename="../gui/advancedsettings.cpp" line="260"/>
        <source> (disabled)</source>
        <translation>(deshabilitado)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="250"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="258"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="271"/>
        <source>All addresses</source>
        <translation>Todas las direcciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="308"/>
        <source>qBittorrent Section</source>
        <translation>Sección de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="311"/>
        <location filename="../gui/advancedsettings.cpp" line="316"/>
        <source>Open documentation</source>
        <translation>Abrir documentación</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="314"/>
        <source>libtorrent Section</source>
        <translation>Sección de libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="324"/>
        <source>Asynchronous I/O threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="338"/>
        <source>Disk cache</source>
        <translation>Caché de disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="343"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="344"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de expiración de la caché de disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Enable OS cache</source>
        <translation>Activar caché del S.O.</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source>Guided read cache</source>
        <translation>Cache de lectura guiado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="354"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>Combinar lecturas y escrituras</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="358"/>
        <source>Send upload piece suggestions</source>
        <translation>Enviar sugerencias de piezas a subir</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="362"/>
        <location filename="../gui/advancedsettings.cpp" line="367"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="364"/>
        <source>Send buffer watermark</source>
        <translation>Enviar buffer watermark</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="369"/>
        <source>Send buffer low watermark</source>
        <translation>Enviar buffer lowmark</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="374"/>
        <source>Send buffer watermark factor</source>
        <translation>Enviar buffer watermark factor</translation>
    </message>
    <message>
        <source> m</source>
        <comment> minutes</comment>
        <translation type="vanished">m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="392"/>
        <source>Prefer TCP</source>
        <translation>Preferir TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="392"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="397"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Permitir múltiples conexiones de la misma dirección IP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="409"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Resolver países de los pares (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="412"/>
        <source>Resolve peer host names</source>
        <translation>Resolver nombres de host de los pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="420"/>
        <source>Strict super seeding</source>
        <translation>Super-Siembra</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="445"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interfaz de red (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="448"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Dirección IP opcional a escuchar (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="451"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Escuchar en la dirección IPv6 (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="459"/>
        <source>Display notifications</source>
        <translation>Mostrar notificaciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="462"/>
        <source>Display notifications for added torrents</source>
        <translation>Mostrar notificaciones para torrents agregados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="465"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Descargar favicon del tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="469"/>
        <source>Save path history length</source>
        <translation>Tamaño del historial de rutas de guardado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="479"/>
        <source>Fixed slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="479"/>
        <source>Upload rate based</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="481"/>
        <source>Upload slots behavior</source>
        <translation>Comportamiento de los puestos de subida</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Round-robin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Fastest upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Anti-leech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="485"/>
        <source>Upload choking algorithm</source>
        <translation>Algoritmo de bloqueo de subidas</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="497"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmar la verificación del torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="501"/>
        <source>Confirm removal of all tags</source>
        <translation>Confirmar la eliminación de todas las etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="505"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Siempre anunciar a todos los trackers del nivel</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="509"/>
        <source>Always announce to all tiers</source>
        <translation>Siempre anunciar a todos los niveles</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Cualquier interfaz</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Intervalo entre el guardado de datos de reanudación</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="394"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>Algoritmo de modo mixto %1-TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="417"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Número máximo de conexiones semi-abiertas [0: Sin límite]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="454"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Dirección IP para informar a los trackers (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="472"/>
        <source>Enable embedded tracker</source>
        <translation>Activar tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="477"/>
        <source>Embedded tracker port</source>
        <translation>Puerto del tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="489"/>
        <source>Check for software updates</source>
        <translation>Comprobar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="493"/>
        <source>Use system icon theme</source>
        <translation>Usar iconos del tema actual</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="157"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciado</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="308"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, ejecutando programa externo , comando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="335"/>
        <source>Torrent name: %1</source>
        <translation>Nombre del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="336"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="337"/>
        <source>Save path: %1</source>
        <translation>Guardar en: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="338"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt se descargó en %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="340"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gracias por utilizar qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="347"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; ha terminado de descargarse</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="361"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, enviando correo de notificación</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="522"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="523"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>Para controlar qBittorrent, accede a la interfaz web en %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="525"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>El nombre de usuario del administrador de la interfaz Web es: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="529"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contraseña del administrador de la interfaz Web sigue siendo por defecto: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="530"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Esto es un riesgo de seguridad, por favor considere cambiar su contraseña en las preferencias del programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="693"/>
        <source>Saving torrent progress...</source>
        <translation>Guardando progreso del torrent...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="750"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation>Las opciones de Modo portátil y ruta de perfil son mutuamente excluyentes</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="753"/>
        <source>Portable mode implies relative fastresume</source>
        <translation>El modo portátil implica continuación rápida relativa</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="54"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="58"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Tu dirección IP ha sido bloqueada después múltiples intentos de autenticación fallidos.</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="76"/>
        <source>WebAPI login success. IP: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="81"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="240"/>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Descargador RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>La auto-descarga por canales RSS esta Desactivada. Puedes habilitarla en las opciones.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Reglas de descarga</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Definición de reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.01.01 and 01.01.2017 (Date formats also support - as a separator)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>Usar Filtro Inteligente de Episodios</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>No debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Assign Category:</source>
        <translation>Asignar categoría:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="228"/>
        <source>Save to a Different Directory</source>
        <translation>Guardar en una ruta diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="268"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorar coincidencias posteriores a (0 para deshabilitar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="278"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="281"/>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="314"/>
        <source>Add Paused:</source>
        <translation>Agregar pausado:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="322"/>
        <source>Use global settings</source>
        <translation>Usar preferencias globales</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="327"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="332"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="353"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar regla a los canales:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="375"/>
        <source>Matching RSS Articles</source>
        <translation>Coincidencias de artículos RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="403"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="413"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Filtrar artículos en base al filtro de episodios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Example: </source>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>coincidirá con los episodios 2, 5, del 8 al 15, y del 30 en adelante de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Episode filter rules: </source>
        <translation>Reglas del filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada debe ser distinto de cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Filter must end with semicolon</source>
        <translation>El filtro debe finalizar con punto y coma (;)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Son soportados tres tipos de rango de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Un número: &lt;b&gt;1x25;&lt;/b&gt; coincidirá con el episodio 25 de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Un rango: &lt;b&gt;1x25-40;&lt;/b&gt; coincidirá con los episodios del 25 al 40 de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>El número de episodio debe ser un valor positivo</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="62"/>
        <source>Rules</source>
        <translation>Reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules (legacy)</source>
        <translation>Reglas (antiguas)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Rango infinito: &lt;b&gt;1x25-;&lt;/b&gt; coincidirá con los episodios del 25 en adelante de la temporada uno, y todos los episodios de las temporadas siguientes</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="276"/>
        <source>Last Match: %1 days ago</source>
        <translation>Última coincidencia: %1 días atrás</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="278"/>
        <source>Last Match: Unknown</source>
        <translation>Última coincidencia: Desconocida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>New rule name</source>
        <translation>Nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor, escriba el nombre de la nueva regla de descarga.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="366"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>Rule name conflict</source>
        <translation>Conflicto con el nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="367"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ya existena una regla con este nombre, por favor, elija otro nombre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="381"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>¿Está seguro de querer eliminar la regla de descarga llamada &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>¿Está seguro que desea eliminar las reglas de descarga seleccionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="384"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar la eliminación de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="393"/>
        <source>Destination directory</source>
        <translation>Ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>Invalid action</source>
        <translation>Acción no válida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="402"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La lista está vacía, no hay nada para exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="408"/>
        <source>Export RSS rules</source>
        <translation>Exportar reglas RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>No se pudo crear el archivo de destino. Razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="440"/>
        <source>Import RSS rules</source>
        <translation>Importar reglas RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation> Fallo al abrir el archivo. Razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="464"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="465"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>No se pudo importar el archivo de reglas seleccionado. Razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="472"/>
        <source>Add new rule...</source>
        <translation>Agregar nueva regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="482"/>
        <source>Rename rule...</source>
        <translation>Renombrar regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="485"/>
        <source>Delete selected rules</source>
        <translation>Eliminar reglas seleccionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="488"/>
        <source>Clear downloaded episodes...</source>
        <translation>Limpiar episodios descargados...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="512"/>
        <source>Rule renaming</source>
        <translation>Renombrando regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="512"/>
        <source>Please type the new rule name</source>
        <translation>Por favor, escriba el nombre de la nueva regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="538"/>
        <source>Clear downloaded episodes</source>
        <translation>Limpiar episodios descargados</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="539"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="643"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Modo Regex: usar expresiones regulares compatibles con Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="685"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="723"/>
        <source>Position %1: %2</source>
        <translation>Posición %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="646"/>
        <source>Wildcard mode: you can use</source>
        <translation>Modo comodín: puedes usar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="647"/>
        <source>? to match any single character</source>
        <translation>? para coincidir cualquier carácter</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="648"/>
        <source>* to match zero or more of any characters</source>
        <translation>* para coincidir cero o más de cualquier carácter</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="649"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Los espacios cuentan como operadores AND (todas las palabras, cualquier orden)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="650"/>
        <source>| is used as OR operator</source>
        <translation>| es usado como operador OR</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="651"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Si el orden de las palabras es importante use * en vez de espacios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="658"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Una expresión con una cláusula %1 vacía (p.ej. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="662"/>
        <source> will match all articles.</source>
        <translation>coincidirá con todos los artículos.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="663"/>
        <source> will exclude all articles.</source>
        <translation>excluirá todos los artículos.</translation>
    </message>
</context>
<context>
    <name>BanListOptions</name>
    <message>
        <source>List of banned IP addresses</source>
        <translation type="vanished">Lista de direcciones IP prohibidas</translation>
    </message>
    <message>
        <source>Ban IP</source>
        <translation type="vanished">Prohibir IP</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Eliminar</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="vanished">Advertencia</translation>
    </message>
    <message>
        <source>The entered IP address is invalid.</source>
        <translation type="vanished">La dirección IP introducida no es válida.</translation>
    </message>
    <message>
        <source>The entered IP is already banned.</source>
        <translation type="vanished">La dirección IP introducida ya está prohibida.</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation type="unfinished">Lista de direcciones IP prohibidas</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="77"/>
        <source>Ban IP</source>
        <translation type="unfinished">Prohibir IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="84"/>
        <source>Delete</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>Warning</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <source>The entered IP address is invalid.</source>
        <translation type="unfinished">La dirección IP introducida no es válida.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>The entered IP is already banned.</source>
        <translation type="unfinished">La dirección IP introducida ya está prohibida.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="596"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Es necesario reiniciar para cambiar el soporte PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1245"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>No se pudo obtener GUID de la interfaz de red configurada. Enlazando a la IP %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1752"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Tracker integrado [Activado]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1754"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error al iniciar el tracker integrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1757"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Tracker integrado [Desactivado]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>El estado de la red del equipo cambió a %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>ONLINE</source>
        <translation>EN LÍNEA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>OFFLINE</source>
        <translation>FUERA DE LÍNEA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2449"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>La configuración de red de %1 ha cambiado, refrescando la sesión</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2466"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>La interfaz de red configurada %1 no es válida</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="482"/>
        <location filename="../base/bittorrent/session.cpp" line="2813"/>
        <source>Encryption support [%1]</source>
        <translation>Cifrado [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <source>FORCED</source>
        <translation>FORZADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2938"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 no es una dirección IP válida y ha sido rechazada al aplicar la lista de direcciones prohibidas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>Anonymous mode [%1]</source>
        <translation>Modo Anónimo [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3676"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>No se pudo decodificar el torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3813"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Descarga recursiva del archivo &apos;%1&apos; incluido en el torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3913"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>Las posiciones de cola fueron corregidas en %1 archivos de continuación</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4134"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>No se pudo guardar &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4181"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4194"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias y del disco.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4206"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias pero los archivos no pudieron ser eliminados. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4271"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>porque %1 está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4274"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>porque %1 está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4292"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Falló la búsqueda de la semilla Url: &apos;%1&apos;, mensaje: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4340"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>qBittorrent falló al escuchar en la interfaz %1 puerto: %2/%3. Razón: %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2090"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, por favor espere...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1209"/>
        <location filename="../base/bittorrent/session.cpp" line="2543"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent está tratando de escuchar en cualquier interfaz, puerto: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2485"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfaz de red definida no es válida: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1222"/>
        <location filename="../base/bittorrent/session.cpp" line="2554"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está tratando de escuchar en la interfaz %1 puerto: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="476"/>
        <source>Peer ID: </source>
        <translation>ID del Par:</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="477"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>El User-Agent HTTP es &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <source>DHT support [%1]</source>
        <translation>DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>ON</source>
        <translation>Activado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>OFF</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Buscar pares locales [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <source>PeX support [%1]</source>
        <translation>Soporte PeX [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1802"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Eliminado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1807"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Pausado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1827"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Eliminado...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1832"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Pausado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2519"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent no encuentra una dirección local %1 para escuchar</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2547"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent falló tratando de escuchar en cualquier interfaz, Puerto: %1. Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3581"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>El tracker &apos;%1&apos; se agregó al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3593"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>El tracker &apos;%1&apos; se eliminó del torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3610"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>La semilla URL &apos;%1&apos; se agregó al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3617"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>La semilla URL &apos;%1&apos; se eliminó del torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3861"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>No se pudo continuar el torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3947"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas aplicadas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3957"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Falló el análisis del filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4120"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4165"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>No se pudo agregar el torrent. Razón: %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation type="vanished">&apos;%1&apos; continuado. (continuación rápida)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4141"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; agregado a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4233"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Ocurrió un error de I/O, &apos;%1&apos; pausado. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4243"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Falló el mapeo del puerto, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4249"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Puerto mapeado correctamente, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4259"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>por el filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4262"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>por el filtro de puertos.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4265"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>por restricciones del modo mixto i2p.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4268"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>por tener un puerto bajo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4313"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está escuchando en la interfaz %1 puerto: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4350"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP Externa: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="189"/>
        <source>create new torrent file failed</source>
        <translation>fallo al crear el archivo torrent</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1338"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>Priorizar la primera y la última parte: %1, torrent: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1339"/>
        <source>On</source>
        <translation>Activado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1339"/>
        <source>Off</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1454"/>
        <source>Successfully moved torrent: %1. New path: %2</source>
        <translation>El Torrent: %1. Fue movido correctamente a: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1489"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>No se pudo mover el torrent: &apos;%1&apos;. Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1672"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1678"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="240"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="394"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="401"/>
        <source>Uncategorized</source>
        <translation>Sin categorizar</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="114"/>
        <source>Add category...</source>
        <translation>Agregar categoría...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="122"/>
        <source>Add subcategory...</source>
        <translation>Agregar subcategoría...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="128"/>
        <source>Edit category...</source>
        <translation>Editar categoría...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Remove category</source>
        <translation>Eliminar categoría</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="139"/>
        <source>Remove unused categories</source>
        <translation>Eliminar categorías sin utilizar</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="146"/>
        <source>Resume torrents</source>
        <translation>Continuar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="151"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="156"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Administrar Cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Dominio</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Fecha de caducidad</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation type="unfinished">Confirmar eliminación</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation type="unfinished">Recordar siempre esta elección</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation type="unfinished">Eliminar también los archivos del disco duro</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="52"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation type="unfinished">¿Seguro que desea eliminar &apos;%1&apos; de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="54"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation type="unfinished">¿Seguro que desea eliminar estos %1 torrents de la lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation type="vanished">¿Seguro que desea eliminar &apos;%1&apos; de la lista de transferencias?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation type="vanished">¿Seguro que desea eliminar estos %1 torrents de la lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation type="unfinished">Descargar de URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation type="unfinished">Agregar enlace torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="unfinished">Un enlace por línea (pueden ser enlaces HTTP, enlaces magnet o info-hashes) </translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="64"/>
        <source>Download</source>
        <translation type="unfinished">Descargar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>No URL entered</source>
        <translation type="unfinished">No se ha introducido ninguna URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>Please type at least one URL.</source>
        <translation type="unfinished">Por favor introduce al menos una URL.</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>Blanco: Piezas faltantes</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>Verde: Piezas descargadas parcialmente</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>Azul: Piezas completadas</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>General</source>
        <translation type="vanished">General</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="vanished">IPs bloqueadas</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue bloqueado %2</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue baneado</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="39"/>
        <source>General</source>
        <translation type="unfinished">General</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation type="unfinished">IPs bloqueadas</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="106"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue bloqueado %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="108"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue baneado</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="49"/>
        <source>RSS feeds</source>
        <translation>Canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="61"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="115"/>
        <source>Unread  (%1)</source>
        <translation>No leídos (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="170"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="56"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="58"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Examinar...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="60"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Elija un archivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="62"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Elija una carpeta</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="101"/>
        <source>Any file</source>
        <translation>Cualquier archivo</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="276"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="438"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Error de I/O: No se pudo abrir el archivo de filtros IP en modo lectura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="344"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>La linea %1 del filtro IP no es correcta.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="222"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="362"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>La linea %1 del filtro IP no es correcta. La IP inicial del rango no es valida.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="231"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="371"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>La linea %1 del filtro IP no es correcta. La IP final del rango no es valida.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="239"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="379"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>La linea %1 del filtro IP no es correcta. Una IP es IPv4 y la otra IPv6</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="253"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="392"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>Excepción del filtro IP para la linea %1. Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="263"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="402"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>%1 errores extra ocurridos al analizar el filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="449"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="482"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="491"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="511"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="531"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Error de análisis: El archivo de filtros no es un P2B valido de PeerGuardian.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="94"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="124"/>
        <source>Unsupported database file size.</source>
        <translation>El tamaño del archivo de base de datos no es soportado.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="223"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Error de metadatos: no se encontró la entrada &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="224"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Error de metadatos: la entrada &apos;%1&apos;  tiene un tipo invalido.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="233"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versión de base de datos no soportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="240"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versión de IP no soportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="247"/>
        <source>Unsupported record size: %1</source>
        <translation>Tamaño del registro no soportado: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Invalid database type: %1</source>
        <translation>Tipo de base de datos invalido: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="281"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de datos corrupta: no se encontró la sección de datos.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="69"/>
        <source>Http request size exceeds limiation, closing socket. Limit: %ld, IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="82"/>
        <source>Bad Http request, closing socket. IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Exit qBittorrent</source>
        <translation>Salir de qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Only one link per line</source>
        <translation>Solamente un enlace por línea</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>El número máximo de descargas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>El número máximo de subidas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>El número máximo de torrents activos debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo de puestos de subida por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Error al guardar las preferencias del programa, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent en Freenode</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Invalid category name:
Please do not use any special characters in the category name.</source>
        <translation>Nombre de categoría invalido:
Por favor no use caracteres especiales para el nombre de la categoría.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Hard Disk</source>
        <translation>Disco duro</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>El limite de ratio debe estar entre 0 y 9998</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>El limite de tiempo de sembrado debe estar entre 0 y 525600 minutos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>El puerto utilizado para conexiones entrantes debe estar comprendido entre 1 y 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>El puerto utilizado para la interfaz Web debe estar comprendido entre 1 y 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Error al iniciar sesión, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>Invalid Username or Password.</source>
        <translation>Nombre de usuario o contraseña inválidos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>Original authors</source>
        <translation>Autores originales</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Subir Torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Save files to location:</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Type folder here</source>
        <translation>Escribir carpeta aquí</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>More information</source>
        <translation>Más Información</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Information about certificates</source>
        <translation>Información sobre certificados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Save Files to</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Set location</source>
        <translation>Establecer destino</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Limit upload rate</source>
        <translation>Tasa límite de subida</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Limit download rate</source>
        <translation>Tasa límite de bajada...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Rename torrent</source>
        <translation>Renombrar torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Otro...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lunes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Martes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Miércoles</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Jueves</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Viernes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sábado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Domingo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>Logout</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Descargar torrents desde sus URL o enlaces magnet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Upload local torrent</source>
        <translation>Subir torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>¿Seguro que desea eliminar los torrents seleccionados de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Imposible conectar a qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent se ha cerrado.</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Lista blanca de subredes</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Ejemplo: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>Agregar subred</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>The entered subnet is invalid.</source>
        <translation>La subred introducida es inválida</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="50"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Al finalizar las &amp;descargas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>&amp;Continuar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Crear torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>Set Upload Limit...</source>
        <translation>Establecer límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Download Limit...</source>
        <translation>Establecer límite de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Set Global Download Limit...</source>
        <translation>Límite global de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="248"/>
        <source>Set Global Upload Limit...</source>
        <translation>Límite global de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Minimum Priority</source>
        <translation>Mínima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="261"/>
        <source>Top Priority</source>
        <translation>Máxima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="269"/>
        <source>Decrease Priority</source>
        <translation>Disminuir prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="277"/>
        <source>Increase Priority</source>
        <translation>Incrementar prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <location filename="../gui/mainwindow.ui" line="291"/>
        <source>Alternative Speed Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="302"/>
        <source>Display Top Toolbar</source>
        <translation>Mostrar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="310"/>
        <source>Status &amp;Bar</source>
        <translation>Barra de estado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Velocidad en la barra de título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="321"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar Velocidad de Transferencia en la Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="329"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="337"/>
        <source>Search &amp;Engine</source>
        <translation>Motor de Búsqu&amp;eda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Bl&amp;oquear qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="472"/>
        <source>Close Window</source>
        <translation>Cerrar ventana</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eanudar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage Cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="427"/>
        <source>Manage stored network cookies</source>
        <translation>Administrar cookies de red almacenadas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="443"/>
        <source>Normal Messages</source>
        <translation>Mensajes Normales</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="451"/>
        <source>Information Messages</source>
        <translation>Mensajes de Información</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="459"/>
        <source>Warning Messages</source>
        <translation>Mensajes de advertencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="467"/>
        <source>Critical Messages</source>
        <translation>Mensajes Críticos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="364"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Salir de &amp;qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="372"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="380"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="388"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Apagar Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>&amp;Statistics</source>
        <translation>E&amp;stadísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="419"/>
        <source>Check for Program Updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>Pa&amp;usar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Agregar archivo torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="345"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="401"/>
        <location filename="../gui/mainwindow.ui" line="435"/>
        <location filename="../gui/mainwindow.cpp" line="1687"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1891"/>
        <source>Check for program updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Agregar &amp;enlace torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="356"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si le gusta qBittorrent, por favor realice una donación!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1926"/>
        <location filename="../gui/mainwindow.cpp" line="1928"/>
        <source>Execution Log</source>
        <translation>Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="657"/>
        <source>Clear the password</source>
        <translation>Borrar la contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="235"/>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="206"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Establecer Contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="174"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="208"/>
        <source>&amp;Clear Password</source>
        <translation>Limpiar C&amp;ontraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="261"/>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1256"/>
        <source>qBittorrent is minimized to tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1167"/>
        <location filename="../gui/mainwindow.cpp" line="1256"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="462"/>
        <source>Torrent file association</source>
        <translation>Asociación de archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no es la aplicación por defecto para abrir archivos torrent o enlaces magnet.
¿Quiere que qBittorrent sea el programa por defecto para gestionar estos archivos?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="546"/>
        <source>Icons Only</source>
        <translation>Solo iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="548"/>
        <source>Text Only</source>
        <translation>Solo texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="550"/>
        <source>Text Alongside Icons</source>
        <translation>Texto al lado de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="552"/>
        <source>Text Under Icons</source>
        <translation>Texto debajo de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="554"/>
        <source>Follow System Style</source>
        <translation>Usar estilo del equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <location filename="../gui/mainwindow.cpp" line="669"/>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>UI lock password</source>
        <translation>Contraseña de bloqueo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <location filename="../gui/mainwindow.cpp" line="669"/>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor, escriba la contraseña de bloqueo:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <source>The password should contain at least 3 characters</source>
        <translation>La contraseña debe tener como mínimo 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="650"/>
        <source>Password update</source>
        <translation>Actualizar contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="650"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contraseña de bloqueo de qBittorrent se ha actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="657"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>¿Seguro que desea borrar la contraseña?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="711"/>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="733"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="749"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="845"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="845"/>
        <source>Failed to add torrent: %1</source>
        <translation>Error al agregar torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>Torrent added</source>
        <translation>Torrent agregado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; fue agregado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="858"/>
        <source>Download completion</source>
        <translation>Descarga completada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="864"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="957"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación de descargas recursivas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="963"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="964"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="965"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="990"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite de velocidad de subida global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1005"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite de velocidad de descarga global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1081"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent ha sido actualizado y debe ser reiniciado para que los cambios sean efectivos.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1167"/>
        <source>qBittorrent is closed to tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1180"/>
        <source>Some files are currently transferring.</source>
        <translation>Algunos archivos aún están transfiriéndose.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1180"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>¿Está seguro de que quiere cerrar qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1182"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1183"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1184"/>
        <source>&amp;Always Yes</source>
        <translation>S&amp;iempre sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1586"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1801"/>
        <source>Couldn&apos;t determine your Python version. Search engine disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1816"/>
        <source>Old Python Interpreter</source>
        <translation>Intérprete de Python antiguo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1816"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Su versión de Python (%1) está desactualizada. Por favor actualizela a la ultima versión para poder utilizar el motor de búsqueda. La versión mínima es: 2.7.9/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1873"/>
        <source>qBittorrent Update Available</source>
        <translation>Actualización de qBittorrent disponible</translation>
    </message>
    <message>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation type="vanished">Hay una nueva versión disponible.
¿Desea descargar %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1885"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>qBittorrent está actualizado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1801"/>
        <source>Undetermined Python version</source>
        <translation>Versión de Python indeterminada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="858"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; se ha descargado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="865"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Se produjo un error de I/O en el torrent &apos;%1&apos;.
Razón: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="958"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Este torrent &apos;%1&apos; contiene archivos torrent, ¿Desea seguir adelante con su descarga?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="980"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>No se pudo descargar el archivo desde la URL: &apos;%1&apos;, razón: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1792"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>Python encontrado en %1: %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation type="vanished">No se pudo determinar su versión de Python (%1). Motor de búsqueda deshabilitado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1829"/>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta el intérprete de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1830"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python es necesario para utilizar el motor de búsqueda pero no parece que esté instalado.
¿Desea instalarlo ahora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python es necesario para utilizar el motor de búsqueda pero no parece que esté instalado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1874"/>
        <source>A new version is available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1875"/>
        <source>Do you want to download %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1876"/>
        <source>Open changelog...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1886"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>No hay actualizaciones disponibles.
Ya está utilizando la versión mas reciente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1890"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2053"/>
        <source>Checking for Updates...</source>
        <translation>Buscando actualizaciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2054"/>
        <source>Already checking for program updates in the background</source>
        <translation>Ya se están buscando actualizaciones del programa en segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2070"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python encontrado en &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2139"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2139"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>La instalación de Python no se pudo realizar, la razón: %1.
Por favor, instálelo de forma manual.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <location filename="../gui/mainwindow.cpp" line="1073"/>
        <source>Invalid password</source>
        <translation>Contraseña no válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="682"/>
        <location filename="../gui/mainwindow.cpp" line="693"/>
        <location filename="../gui/mainwindow.cpp" line="695"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="979"/>
        <source>URL download error</source>
        <translation>Error descargando de URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1073"/>
        <source>The password is invalid</source>
        <translation>La contraseña no es válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1571"/>
        <location filename="../gui/mainwindow.cpp" line="1578"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. descarga: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1574"/>
        <location filename="../gui/mainwindow.cpp" line="1580"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. subida: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1593"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[B: %1, S: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1687"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1178"/>
        <source>Exiting qBittorrent</source>
        <translation>Cerrando qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1382"/>
        <source>Open Torrent Files</source>
        <translation>Abrir archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1383"/>
        <source>Torrent Files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1433"/>
        <source>Options were saved successfully.</source>
        <translation>Opciones guardadas correctamente.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>El DNS dinámico se actualizó correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error del DNS dinámico: El servicio no está disponible temporalmente, nuevo reintento en 30 minutos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error del DNS dinámico: El nombre de host proporcionado no existe en la cuenta especificada.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error del DNS dinámico: El nombre de usuario/contraseña no es válido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: qBittorrent ha sido incluido en la Lista Negra por el servicio, por favor, informar de ésto en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: %1 fue rechazado por el servicio, por favor, informe de este error en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error del DNS dinámico: Su nombre de usuario fue bloqueado debido a excesos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error del DNS dinámico: El nombre de dominio proporcionado no válido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error del DNS dinámico: El nombre de usuario proporcionado es demasiado corto.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error del DNS dinámico: La contraseña proporcionada demasiado corta.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="127"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="140"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>El tamaño de archivo es %1. Excede el limite de descarga de %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="174"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redirección inesperada hacia un enlace magnet.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished">El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The operation was canceled</source>
        <translation type="unfinished">La operación fue cancelada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished">El servidor remoto cerró la conexión prematuramente, antes de que se recibiera y procesara toda la respuesta</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished">La conexión con el servidor remoto ha agotado el tiempo de espera</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished">Handshake SSL/TLS fallido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The remote server refused the connection</source>
        <translation type="unfinished">El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished">La conexión con el servidor proxy fué rechazada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished">El servidor proxy cerró la conexión antes de tiempo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The proxy host name was not found</source>
        <translation type="unfinished">No se encontró el nombre del servidor proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished">La conexión con el servidor proxy ha agotado el tiempo de espera o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation type="unfinished">El proxy requiere autenticación para poder atender la solicitud, pero no aceptó las credenciales proporcionadas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished">El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished">La operación solicitada en el contenido remoto no está permitida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished">El contenido remoto no se encontró en el servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished">El servidor remoto requiere autenticación para servir el contenido, pero no se aceptaron las credenciales proporcionadas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished">La API de acceso a la red no pudo cumplir con la solicitud debido a que el protocolo es desconocido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished">La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished">Se ha detectado un error desconocido relacionado con la red</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished">Se ha detectado un error desconocido relacionado con el proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished">Se ha detectado un error desconocido relacionado con el contenido remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished">Se ha detectado una ruptura en el protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="248"/>
        <source>Unknown error</source>
        <translation type="unfinished">Error desconocido</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="434"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Base de datos GeoIP cargada. Tipo: %1. Creada el: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="455"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>No se pudo cargar la base de datos GeoIP. Razon: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Viet Nam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Emiratos Árabes Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afganistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua y Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>Anguila</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antarctica</source>
        <translation>Antártida</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>American Samoa</source>
        <translation>Samoa Americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Austria</source>
        <translation>Austria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>Azerbaiyán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnia y Herzegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>Bangladés</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Bélgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>Baréin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>Benín</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bermuda</source>
        <translation>Bermudas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Brunei Darussalam</source>
        <translation>Brunéi Darussalam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bhutan</source>
        <translation>Bután</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bouvet Island</source>
        <translation>Isla Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Botswana</source>
        <translation>Botsuana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belarus</source>
        <translation>Bielorrusia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Belize</source>
        <translation>Belice</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Canada</source>
        <translation>Canadá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Islas Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>República Democrática del Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Central African Republic</source>
        <translation>República Centroafricana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Switzerland</source>
        <translation>Suiza</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cook Islands</source>
        <translation>Islas Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Cameroon</source>
        <translation>Camerún</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Colombia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cape Verde</source>
        <translation>Cabo Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Curacao</source>
        <translation>Curazao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Christmas Island</source>
        <translation>Isla de Navidad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Cyprus</source>
        <translation>Chipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Czech Republic</source>
        <translation>República Checa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Germany</source>
        <translation>Alemania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Djibouti</source>
        <translation>Yibuti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Algeria</source>
        <translation>Argelia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Estonia</source>
        <translation>Estonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Egypt</source>
        <translation>Egipto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Western Sahara</source>
        <translation>Sahara Occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Spain</source>
        <translation>España</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Ethiopia</source>
        <translation>Etiopía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Finland</source>
        <translation>Finlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Fiji</source>
        <translation>Fiyi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Islas Malvinas (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Micronesia, Federated States of</source>
        <translation>Estados Federados de Micronesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Faroe Islands</source>
        <translation>Islas Feroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gabon</source>
        <translation>Gabón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>United Kingdom</source>
        <translation>Reino Unido</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Georgia</source>
        <translation>Georgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>French Guiana</source>
        <translation>Guayana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Greenland</source>
        <translation>Groenlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Ecuatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Islas Georgias del Sur y Sandwich del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bisáu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Islas Heard y McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Croatia</source>
        <translation>Croacia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Haiti</source>
        <translation>Haití</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hungary</source>
        <translation>Hungría</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Indonesia</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>India</source>
        <translation>India</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territorio Británico del Océano Índico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Irán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Iceland</source>
        <translation>Islandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Italy</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Jordan</source>
        <translation>Jordania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Japan</source>
        <translation>Japón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kyrgyzstan</source>
        <translation>Kirguistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cambodia</source>
        <translation>Camboya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Comoros</source>
        <translation>Comoras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Saint Kitts and Nevis</source>
        <translation>San Cristóbal y Nieves</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Corea del Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Korea, Republic of</source>
        <translation>Corea del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Cayman Islands</source>
        <translation>Islas Caimán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kazakhstan</source>
        <translation>Kazajistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lebanon</source>
        <translation>Líbano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Saint Lucia</source>
        <translation>Santa Lucía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lesotho</source>
        <translation>Lesoto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Lithuania</source>
        <translation>Lituania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Luxembourg</source>
        <translation>Luxemburgo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Latvia</source>
        <translation>Letonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Morocco</source>
        <translation>Marruecos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Monaco</source>
        <translation>Mónaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Moldova, Republic of</source>
        <translation>Moldavia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Marshall Islands</source>
        <translation>Islas Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mali</source>
        <translation>Malí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Myanmar</source>
        <translation>Birmania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mongolia</source>
        <translation>Mongolia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Northern Mariana Islands</source>
        <translation>Islas Marianas del Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Mauritania</source>
        <translation>Mauritania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mauritius</source>
        <translation>Mauricio</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Maldives</source>
        <translation>Maldivas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malawi</source>
        <translation>Malaui</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mexico</source>
        <translation>México</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malaysia</source>
        <translation>Malasia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>New Caledonia</source>
        <translation>Nueva Caledonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Norfolk Island</source>
        <translation>Isla Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Netherlands</source>
        <translation>Países Bajos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>New Zealand</source>
        <translation>Nueva Zelanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Oman</source>
        <translation>Omán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>French Polynesia</source>
        <translation>Polinesia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Papua New Guinea</source>
        <translation>Papúa Nueva Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Philippines</source>
        <translation>Filipinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Pakistan</source>
        <translation>Pakistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Poland</source>
        <translation>Polonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>San Pedro y Miquelón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Palau</source>
        <translation>Palaos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Qatar</source>
        <translation>Catar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Reunion</source>
        <translation>Reunión</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Romania</source>
        <translation>Rumanía </translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Russian Federation</source>
        <translation>Rusia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Saudi Arabia</source>
        <translation>Arabia Saudita</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Solomon Islands</source>
        <translation>Islas Salomón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sudan</source>
        <translation>Sudán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Sweden</source>
        <translation>Suecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovenia</source>
        <translation>Eslovenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard y Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Slovakia</source>
        <translation>Eslovaquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leona</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sao Tome and Principe</source>
        <translation>Santo Tomé y Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Syrian Arab Republic</source>
        <translation>Siria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Swaziland</source>
        <translation>Suazilandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Turks and Caicos Islands</source>
        <translation>Islas Turcas y Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Chad</source>
        <translation>Chad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>French Southern Territories</source>
        <translation>Tierras Australes y Antárticas Francesas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Thailand</source>
        <translation>Tailandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tajikistan</source>
        <translation>Tayikistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tunisia</source>
        <translation>Túnez</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="423"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>No se pudo descomprimir el archivo de base de datos GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Timor-Leste</source>
        <translation>Timor Oriental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Costa de Marfil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Libya</source>
        <translation>Libia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Saint Martin (French part)</source>
        <translation>San Martín (Parte Francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Pitcairn</source>
        <translation>Islas Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palestine, State of</source>
        <translation>Palestina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Elena, Ascensión y Tristán de Acuña</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>South Sudan</source>
        <translation>Sudán del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (Parte neerlandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Turkey</source>
        <translation>Turquía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad y Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Taiwan</source>
        <translation>Taiwán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Ukraine</source>
        <translation>Ucrania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Islas Ultramarinas Menores de Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>United States</source>
        <translation>Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Santa Sede (Estado de la ciudad del Vaticano)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>San Vicente y las Granadinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, British</source>
        <translation>Islas Vírgenes Británicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Islas Vírgenes de los Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis y Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Yemen</source>
        <translation>Yemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Serbia</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>South Africa</source>
        <translation>Sudáfrica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zambia</source>
        <translation>Zambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Zimbabwe</source>
        <translation>Zimbabue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aland Islands</source>
        <translation>Åland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Isle of Man</source>
        <translation>Isla de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Saint Barthelemy</source>
        <translation>San Bartolomé</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>No se pudo guardar la base de datos GeoIP descargada.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Base de datos GeoIP actualizada correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>No se pudo descargar la base de datos GeoIP. Razon: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="129"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [Activado]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="145"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [Desactivado]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="506"/>
        <source>Email Notification Error:</source>
        <translation>Error en la notificación por E-mail:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Interfaz Web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>Idioma de la interfaz:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(Es necesario reiniciar qBittorrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="197"/>
        <source>Transfer List</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar al eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternar colores en la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation>Ocultar los valores cero e infinito</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="233"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation>Solo torrents pausados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="267"/>
        <source>Action on double-click</source>
        <translation>Acción a realizar con un doble-click</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation>Torrents descargando:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="293"/>
        <location filename="../gui/optionsdialog.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="298"/>
        <location filename="../gui/optionsdialog.ui" line="324"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="329"/>
        <source>No action</source>
        <translation>Sin acción</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="343"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent cuando arranque Windows</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar pantalla de bienvenida al iniciar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmación al salir mientras haya torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirmar la salida automática cuando las descargas finalicen</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="545"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1125"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Notificarme por correo electrónico de la finalización de las descargas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1220"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Ejecutar un programa externo al completar el torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1706"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Filtrado IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1896"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Programar el uso de límites alternativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2250"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Más información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2278"/>
        <source>&amp;Torrent Queueing</source>
        <translation>Torrents en cola</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2628"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Sembrar torrents hasta que su tiempo de siembra alcance</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2661"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>Agregar automáticamente estos trackers a las descargas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2734"/>
        <source>RSS Reader</source>
        <translation>Lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2740"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Habilitar búsqueda por canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2749"/>
        <source>Feeds refresh interval:</source>
        <translation>Intervalo de actualización de canales RSS:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2759"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artículos por canal:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2593"/>
        <location filename="../gui/optionsdialog.ui" line="2769"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation>min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2813"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Descargador RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2819"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Habilitar auto descarga de torrents RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2826"/>
        <source>Edit auto downloading rules...</source>
        <translation>Editar reglas de auto descarga...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2896"/>
        <source>Web User Interface (Remote control)</source>
        <translation>interfaz Web (Control remoto)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2910"/>
        <source>IP address:</source>
        <translation>Direcciones IP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2917"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>Dirección IP que la interfaz Web escuchará.
Especifique una dirección IPv4 o IPv6. 
&quot;0.0.0.0&quot; para cualquier dirección IPv4.
&quot;::&quot; para cualquier dirección IPv6.
&quot;*&quot; para cualquier dirección IPv4 O IPv6</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2950"/>
        <source>Server domains:</source>
        <translation>Dominios de servidor:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2957"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>Lista blanca para filtrar valores de cabeceras de hosts HTTP.
Para defenderse de ataques DNS rebinding,
no debería utilizar nombres de dominio utilizados por el servidor de la interfaz Web.

Use &apos;;&apos; para dividir múltiples entradas. Puede usar el comodin &apos;*&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2980"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Usar HTTPS en lugar de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3119"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Eludir la autenticación para clientes en localhost</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3126"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Eludir la autenticación para clientes en la lista blanca de subredes IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3139"/>
        <source>IP subnet whitelist...</source>
        <translation>Lista blanca de subredes IP...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3202"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Actualizar mi nombre de dominio dinámico</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar qBittorrent en el area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Cerrar qBittorrent al area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>Estilo del icono del area de notificación:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="429"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromo (tema oscuro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromo (tema claro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="452"/>
        <source>File association</source>
        <translation>Asociación de archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar qBittorrent para los archivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar qBittorrent para los enlaces magnet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="478"/>
        <source>Power Management</source>
        <translation>Administración de energía</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation type="vanished">Inhabilitar la suspensión del equipo cuando queden torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="521"/>
        <source>Save path:</source>
        <translation>Ruta Destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="538"/>
        <source>Backup the log file after:</source>
        <translation>Respaldar el archivo de logs después de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="581"/>
        <source>Delete backup logs older than:</source>
        <translation>Eliminar logs de más antiguos que:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="605"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="610"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>meses</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="615"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>años</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="689"/>
        <source>When adding a torrent</source>
        <translation>Al agregar un torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="707"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Traer el diálogo del torrent al frente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="730"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciar las descargas de forma automática</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="737"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>Debería el archivo .torrent ser borrado después de ser agregado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="752"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>También eliminar archivos .torrent si su agregado fue cancelado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="755"/>
        <source>Also when addition is cancelled</source>
        <translation>También cuando su agregado es cancelado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="777"/>
        <source>Warning! Data loss possible!</source>
        <translation>¡Peligro! Perdida de datos posible.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="813"/>
        <source>Saving Management</source>
        <translation>Administración de guardado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="821"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Administración de Torrents predeterminada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="833"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="837"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="842"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="865"/>
        <source>When Torrent Category changed:</source>
        <translation>Cuando cambia la categoría del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="875"/>
        <source>Relocate torrent</source>
        <translation>Reubicar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="880"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Cambiar torrent a modo manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="903"/>
        <source>When Default Save Path changed:</source>
        <translation>Cuando la ubicación de guardado predeterminada cambia:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="916"/>
        <location filename="../gui/optionsdialog.ui" line="957"/>
        <source>Relocate affected torrents</source>
        <translation>Reubicar los torrents afectados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="921"/>
        <location filename="../gui/optionsdialog.ui" line="962"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Cambiar los torrents afectados a modo manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="944"/>
        <source>When Category changed:</source>
        <translation>Cuando cambia la categoría:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="987"/>
        <source>Use Subcategories</source>
        <translation>Usar subcategorias:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1006"/>
        <source>Default Save Path:</source>
        <translation>Ubicación de guardado predeterminada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1020"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantener torrents incompletos en:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1013"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar archivos .torrent en:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Mostrar &amp;qBittorrent en el área de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="501"/>
        <source>&amp;Log file</source>
        <translation>Archivo de &amp;logs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="695"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Mostrar el contenido del Torrent y opciones</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="720"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>Crear una sub-carpeta para torrentes con múltiples archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="740"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>Después eliminar el archivo .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="999"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar archivos .torrent de descargas finalizadas a:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="792"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar espacio en el disco para todos los archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="484"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="491"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="799"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Agregar la extensión .!qB a los archivos incompletos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="806"/>
        <source>Enable recursive download dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1041"/>
        <source>Automatically add torrents from:</source>
        <translation>Agregar automáticamente los torrents de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1088"/>
        <source>Add entry</source>
        <translation>Agregar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1098"/>
        <source>Remove entry</source>
        <translation>Eliminar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1149"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1171"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requiere una conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1178"/>
        <location filename="../gui/optionsdialog.ui" line="3087"/>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1190"/>
        <location filename="../gui/optionsdialog.ui" line="1667"/>
        <location filename="../gui/optionsdialog.ui" line="3146"/>
        <location filename="../gui/optionsdialog.ui" line="3260"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1200"/>
        <location filename="../gui/optionsdialog.ui" line="1677"/>
        <location filename="../gui/optionsdialog.ui" line="3153"/>
        <location filename="../gui/optionsdialog.ui" line="3274"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1288"/>
        <source>Enabled protocol:</source>
        <translation>Protocolo Activado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1296"/>
        <source>TCP and μTP</source>
        <translation>TCP y μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1316"/>
        <source>Listening Port</source>
        <translation>Puerto de escucha</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1324"/>
        <source>Port used for incoming connections:</source>
        <translation>Puerto utilizado para conexiones entrantes:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1344"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1366"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar reenvío de puertos UPnP / NAT-PMP de mi router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1376"/>
        <source>Use different port on each startup</source>
        <translation>Usar un puerto diferente en cada inicio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1386"/>
        <source>Connections Limits</source>
        <translation>Límites de conexión</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1402"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Máximo de conexiones por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1412"/>
        <source>Global maximum number of connections:</source>
        <translation>Máximo de conexiones totales:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1451"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Máximo de puestos de subida por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1461"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Máximo total de puestos de subida:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1500"/>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1508"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1516"/>
        <source>(None)</source>
        <translation>(Ninguno)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1521"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1526"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1531"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1542"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1562"/>
        <location filename="../gui/optionsdialog.ui" line="2926"/>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1590"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Sino, el servidor proxy se utilizará solamente para las conexiones al tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1593"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para las conexiones a los pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1602"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Deshabilitar conexiones no soportadas por los proxis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1612"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;Más información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1637"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Canales RSS, motores de búsqueda. actualizaciones del software o cualquier otra cosa que no sean transferencias de torrents y operaciones relacionadas (como intercambio de pares) usarán una conexión directa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1640"/>
        <source>Use proxy only for torrents</source>
        <translation>Usar proxy solo para torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1653"/>
        <source>A&amp;uthentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1693"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: La contraseña se guarda sin cifrar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1714"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta del filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1730"/>
        <source>Reload the filter</source>
        <translation>Actualizar el filtro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1745"/>
        <source>Manually banned IP addresses...</source>
        <translation>Direcciones IP prohibidas manualmente...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1752"/>
        <source>Apply to trackers</source>
        <translation>Aplicar a los trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1810"/>
        <source>Global Rate Limits</source>
        <translation>Limites globales de velocidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1819"/>
        <location filename="../gui/optionsdialog.ui" line="1845"/>
        <location filename="../gui/optionsdialog.ui" line="2024"/>
        <location filename="../gui/optionsdialog.ui" line="2043"/>
        <location filename="../gui/optionsdialog.ui" line="2417"/>
        <location filename="../gui/optionsdialog.ui" line="2430"/>
        <source> KiB/s</source>
        <translation> KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1835"/>
        <location filename="../gui/optionsdialog.ui" line="2007"/>
        <source>Upload:</source>
        <translation>Subida:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1864"/>
        <location filename="../gui/optionsdialog.ui" line="2014"/>
        <source>Download:</source>
        <translation>Bajada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1887"/>
        <source>Alternative Rate Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1162"/>
        <location filename="../gui/optionsdialog.ui" line="1908"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Desde las:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1142"/>
        <location filename="../gui/optionsdialog.ui" line="1932"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Hasta:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1959"/>
        <source>When:</source>
        <translation>Cuándo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1973"/>
        <source>Every day</source>
        <translation>Todos los días</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1978"/>
        <source>Weekdays</source>
        <translation>Días laborales</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1983"/>
        <source>Weekends</source>
        <translation>Fines de semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2075"/>
        <source>Rate Limits Settings</source>
        <translation>Configuración de los limites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2095"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar el límite a los pares en LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2088"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límite para el exceso de transporte (Overhead)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2081"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar límite para conexiones µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2153"/>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2159"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (red descentralizada) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2169"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercambiar pares con clientes Bittorrent compatibles (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2172"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercambio de pares (PeX) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2182"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar pares en su red local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2185"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar busqueda local de pares para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2197"/>
        <source>Encryption mode:</source>
        <translation>Modo de cifrado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2205"/>
        <source>Prefer encryption</source>
        <translation>Preferir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2210"/>
        <source>Require encryption</source>
        <translation>Exigir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2215"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2240"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilitar cuando se use un proxy o un VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2243"/>
        <source>Enable anonymous mode</source>
        <translation>Activar modo anónimo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2293"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de descargas activas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2313"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de subidas activas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2333"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents activos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2392"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>No contar torrents lentos en estos límites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2443"/>
        <source>Upload rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2450"/>
        <source>Download rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2483"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation>seg</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2499"/>
        <source>Torrent inactivity timer:</source>
        <translation>Temporizador de inactividad de Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2512"/>
        <source>Share Ratio Limiting</source>
        <translation>Limite de ratio de compartición</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2518"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sembrar torrents hasta que su ratio sea</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2538"/>
        <source>then</source>
        <translation>luego</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2639"/>
        <source>Pause them</source>
        <translation>Pausarlos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2644"/>
        <source>Remove them</source>
        <translation>Eliminarlos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2836"/>
        <source>RSS Smart Episode Filters</source>
        <translation>Filtro Inteligente de Episodios por RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2970"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP para redirigir el puerto de mi router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2999"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3011"/>
        <source>Import SSL Certificate</source>
        <translation>Importar certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3040"/>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3052"/>
        <source>Import SSL Key</source>
        <translation>Importar clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3074"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Información acerca de los certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3163"/>
        <source>Use alternative Web UI</source>
        <translation>Usar la Interfaz de Usuario Web alternativa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3175"/>
        <source>Files location:</source>
        <translation>Ubicación de archivos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3188"/>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3195"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3214"/>
        <source>Service:</source>
        <translation>Servicio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3237"/>
        <source>Register</source>
        <translation>Registro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3246"/>
        <source>Domain name:</source>
        <translation>Nombre de dominio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="133"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Al activar estas opciones, puedes &lt;strong&gt;perder permanentemente&lt;/strong&gt; tus archivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="135"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Cuando estas opciones estén habilitadas, qBittorrent &lt;strong&gt;eliminará&lt;/strong&gt; los archivos .torrent después de ser exitosamente (la primera opción) o no (la segunda opción) agregado a la lista de descargas. Esto aplicará &lt;strong&gt;no solo&lt;/strong&gt; a los archivos abiertos por &amp;ldquo;Abrir torrent&amp;rdquo; del menú, sino a aquellos abiertos por su asociación de &lt;strong&gt;tipo de archivo&lt;/strong&gt; también.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="140"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Si habilitas la segunda opción (&amp;ldquo;También cuando la agregado es cancelado&amp;rdquo;) el archivo .torrent &lt;strong&gt; será borrado &lt;/strong&gt; incluso si elijes &amp;ldquo;&lt;strong&gt;Cancelar&lt;/strong&gt;&amp;rdquo; en la ventana de &amp;ldquo;Agregar torrent&amp;rdquo; </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="198"/>
        <source>Choose Alternative UI files location</source>
        <translation>Elegir ubicación de archivos de la Interfaz de Usuario alternativa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="290"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parámetros soportados (sensible a mayúsculas):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="291"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nombre del torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="292"/>
        <source>%L: Category</source>
        <translation>%L: Categoría</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="293"/>
        <source>%G: Tags (seperated by comma)</source>
        <translation>%G: Etiquetas (separadas por coma)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="294"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Ruta del contenido (misma ruta que la raíz para torrents muilti-archivo)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="295"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Ruta Raíz (primer subdirectorio del torrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="296"/>
        <source>%D: Save path</source>
        <translation>%D: Ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="297"/>
        <source>%C: Number of files</source>
        <translation>%C: Cantidad de archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="298"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamaño del torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="299"/>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker actual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="300"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="301"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Consejo: Encapsula el parámetro con comillas para evitar que el texto sea cortado en un espacio (ej: &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="374"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1528"/>
        <source>Select folder to monitor</source>
        <translation>Seleccione una carpeta para monitorear</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1535"/>
        <source>Folder is already being monitored:</source>
        <translation>Esta carpeta ya está monitoreada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1538"/>
        <source>Folder does not exist:</source>
        <translation>La carpeta no existe:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1541"/>
        <source>Folder is not readable:</source>
        <translation>La carpeta no es legible:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1552"/>
        <source>Adding entry failed</source>
        <translation>Fallo al agregar entrada </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="426"/>
        <location filename="../gui/optionsdialog.cpp" line="429"/>
        <location filename="../gui/optionsdialog.cpp" line="1580"/>
        <location filename="../gui/optionsdialog.cpp" line="1582"/>
        <source>Choose export directory</source>
        <translation>Selecciona una ruta de exportación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="423"/>
        <location filename="../gui/optionsdialog.cpp" line="436"/>
        <location filename="../gui/optionsdialog.cpp" line="439"/>
        <source>Choose a save directory</source>
        <translation>Seleccione una ruta para guardar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="432"/>
        <source>Choose an IP filter file</source>
        <translation>Seleccione un archivo de filtro IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="433"/>
        <source>All supported filters</source>
        <translation>Todos los filtros soportados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1616"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1666"/>
        <source>Parsing error</source>
        <translation>Error de análisis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1666"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No se ha podido analizar el filtro IP proporcionado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1668"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1668"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas fueron aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1641"/>
        <source>Invalid key</source>
        <translation>Clave no válida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1641"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta no es una clave SSL válida.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1626"/>
        <source>Invalid certificate</source>
        <translation>Certificado no válido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="98"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1616"/>
        <source>Import SSL certificate</source>
        <translation>Importar certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1626"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este no es un Certificado SSL válido.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1631"/>
        <source>Import SSL key</source>
        <translation>Importar clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1631"/>
        <source>SSL key</source>
        <translation>Clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1790"/>
        <source>Time Error</source>
        <translation>Error de tiempo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1790"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Los tiempos de inicio y finalización no pueden ser iguales.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1799"/>
        <location filename="../gui/optionsdialog.cpp" line="1803"/>
        <source>Length Error</source>
        <translation>Error de longitud</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1799"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nombre de usuario de la interfaz Web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1803"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>La contraseña de Interfaz de Usuario Web debe ser de al menos 6 caracteres.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="283"/>
        <source>Interested(local) and Choked(peer)</source>
        <translation>interesado(local) y ahogado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="289"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interesado(local) y no bloqueado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="298"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interesado(par) y bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interesado(par) y no bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>optimistic unchoke</source>
        <translation>desbloqueo optimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="319"/>
        <source>peer snubbed</source>
        <translation>par descartado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="326"/>
        <source>incoming connection</source>
        <translation>Conexión entrante</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="333"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>no interesado(local) y no bloqueado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="340"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>no interesado(par) y no bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="347"/>
        <source>peer from PEX</source>
        <translation>par de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="354"/>
        <source>peer from DHT</source>
        <translation>par de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="361"/>
        <source>encrypted traffic</source>
        <translation>trafico cifrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="368"/>
        <source>encrypted handshake</source>
        <translation>negociación cifrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="382"/>
        <source>peer from LSD</source>
        <translation>par de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Flags</source>
        <translation>Banderas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Importancia</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Archivos</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="158"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="234"/>
        <source>Add a new peer...</source>
        <translation>Agregar nuevo par...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="242"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <source>Ban peer permanently</source>
        <translation>Prohibir este par permanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="255"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Agregando manualmente el par &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>El par no se pudo agregar al torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="291"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Prohibiendo manualmente al par &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="263"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="265"/>
        <source>Peer addition</source>
        <translation>Agregar par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Country</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="240"/>
        <source>Copy IP:port</source>
        <translation>Copiar IP:puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="263"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Algunos pares no pudieron agregarse. Revisa el log para obtener más detalles.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="265"/>
        <source>The peers were added to this torrent.</source>
        <translation>Los pares se agregaron a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>¿Seguro que desea prohibir permanentemente los pares seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation type="unfinished">Agregar pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation type="unfinished">Lista de pares a agregar (una IP por línea):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation type="unfinished">Formato: IPv4:puerto / [IPv6]:puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="59"/>
        <source>No peer entered</source>
        <translation type="unfinished">No se ha introducido ningún par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="60"/>
        <source>Please type at least one peer.</source>
        <translation type="unfinished">Por favor introduce al menos un par.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="70"/>
        <source>Invalid peer</source>
        <translation type="unfinished">Par invalido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="71"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation type="unfinished">El par &apos;%1&apos; es invalido.</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <source>No peer entered</source>
        <translation type="vanished">No se ha introducido ningún par</translation>
    </message>
    <message>
        <source>Please type at least one peer.</source>
        <translation type="vanished">Por favor introduce al menos un par.</translation>
    </message>
    <message>
        <source>Invalid peer</source>
        <translation type="vanished">Par invalido</translation>
    </message>
    <message>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation type="vanished">El par &apos;%1&apos; es invalido.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>Blanco: Piezas no disponibles</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>Azul: Piezas disponibles</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>Archivos en esta pieza:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>Archivo en esta pieza</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>Archivo en estas piezas</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Espere hasta que los metadatos estén disponibles para ver la información detallada.</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Mantén Shift para información detallada</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation type="unfinished">Plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation type="unfinished">Plugins de búsqueda instalados:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation type="unfinished">Versión</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation type="unfinished">Habilitado</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="unfinished">Advertencia: Asegúrese de cumplir con las leyes de copyright de su país cuando descarga torrents de estos motores de búsqueda. </translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation type="unfinished">Puedes obtener nuevos plugins de búsqueda aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation type="unfinished">Instalar uno nuevo</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation type="unfinished">Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation type="unfinished">Desinstalar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="159"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="221"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="280"/>
        <source>Yes</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="163"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="202"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="284"/>
        <source>No</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Uninstall warning</source>
        <translation type="unfinished">Advertencia de desinstalación</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation type="unfinished">Algunos plugins no pudieron ser desinstalados porque vienen incluidos en qBittorrent. Solamente pueden desinstalarse los que han sido agregados por ti.
En su lugar, esos plugins fueron deshabilitados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>Uninstall success</source>
        <translation type="unfinished">Desinstalación correcta</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation type="unfinished">Todos los plugins seleccionados fueron desinstalados correctamente</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="468"/>
        <source>Search plugin update</source>
        <translation type="unfinished">Actualización de los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <source>Plugins installed or updated: %1</source>
        <translation type="unfinished">Plugins instalados o actualizados: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="343"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="350"/>
        <source>New search engine plugin URL</source>
        <translation type="unfinished">URL del nuevo plugin de motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="344"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="351"/>
        <source>URL:</source>
        <translation type="unfinished">URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Invalid link</source>
        <translation type="unfinished">Enlace inválido</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation type="unfinished">El enlace no parece contener un plugin de búsqueda.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="364"/>
        <source>Select search plugins</source>
        <translation type="unfinished">Seleccione los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="365"/>
        <source>qBittorrent search plugin</source>
        <translation type="unfinished">Plugin de búsqueda de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <source>All your plugins are already up to date.</source>
        <translation type="unfinished">Todos los plugins ya están actualizados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation type="unfinished">No se pudo buscar actualizaciones de plugins. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="450"/>
        <source>Search plugin install</source>
        <translation type="unfinished">Instalar plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="451"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation type="unfinished">No se pudo instalar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation type="unfinished">No se pudo actualizar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Search plugins</source>
        <translation type="vanished">Plugins de búsqueda</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation type="vanished">Plugins de búsqueda instalados:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="vanished">Versión</translation>
    </message>
    <message>
        <source>Url</source>
        <translation type="vanished">URL</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="vanished">Habilitado</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="vanished">Advertencia: Asegúrese de cumplir con las leyes de copyright de su país cuando descarga torrents de estos motores de búsqueda. </translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation type="vanished">Puedes obtener nuevos plugins de búsqueda aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation type="vanished">Instalar uno nuevo</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="vanished">Buscar actualizaciones</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Cerrar</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation type="vanished">Desinstalar</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="vanished">Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="vanished">No</translation>
    </message>
    <message>
        <source>Uninstall warning</source>
        <translation type="vanished">Advertencia de desinstalación</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation type="vanished">Algunos plugins no pudieron ser desinstalados porque vienen incluidos en qBittorrent. Solamente pueden desinstalarse los que han sido agregados por ti.
En su lugar, esos plugins fueron deshabilitados.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation type="vanished">Desinstalación correcta</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation type="vanished">Todos los plugins seleccionados fueron desinstalados correctamente</translation>
    </message>
    <message>
        <source>Plugins installed or updated: %1</source>
        <translation type="vanished">Plugins instalados o actualizados: %1</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation type="vanished">URL del nuevo plugin de motor de búsqueda</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation type="vanished">URL:</translation>
    </message>
    <message>
        <source>Invalid link</source>
        <translation type="vanished">Enlace inválido</translation>
    </message>
    <message>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation type="vanished">El enlace no parece contener un plugin de búsqueda.</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation type="vanished">Seleccione los plugins de búsqueda</translation>
    </message>
    <message>
        <source>qBittorrent search plugin</source>
        <translation type="vanished">Plugin de búsqueda de qBittorrent</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation type="vanished">Actualización de los plugins de búsqueda</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation type="vanished">Todos los plugins ya están actualizados.</translation>
    </message>
    <message>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation type="vanished">No se pudo buscar actualizaciones de plugins. %1</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation type="vanished">Instalar plugin de búsqueda</translation>
    </message>
    <message>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation type="vanished">No se pudo instalar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation type="vanished">No se pudo actualizar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation type="unfinished">Fuente del plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation type="unfinished">Fuente del plugin de búsqueda:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation type="unfinished">Archivo local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation type="unfinished">Enlace web</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation type="vanished">Fuente del plugin</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation type="vanished">Fuente del plugin de búsqueda:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation type="vanished">Archivo local</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation type="vanished">Enlace web</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="77"/>
        <source>qBittorrent is active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="55"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="64"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Preview impossible</source>
        <translation>Imposible previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>No se pudo previsualizar este archivo</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; no existe</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; no apunta a un directorio</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; no apunta a un archivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>No tiene permiso de lectura en &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>No tiene permiso de escritura en &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="118"/>
        <source>Not downloaded</source>
        <translation>No descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="136"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="188"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="121"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="124"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="77"/>
        <source>HTTP Sources</source>
        <translation>Fuentes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="86"/>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="97"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Disponibilidad:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tiempo activo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Tiempo restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocidad de descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocidad de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Límite de descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Desperdiciado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Conexiones:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1023"/>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1030"/>
        <source>Select None</source>
        <translation>Seleccionar ninguno</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1106"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1101"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Ratio de compartición:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Anunciar en:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Ultima vez visto completo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Tamaño total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Piezas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Creado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Agregado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Completado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Creado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Hash del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1096"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1091"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="456"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="463"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tienes %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="408"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="411"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 en esta sesión)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="420"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrado durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="427"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="440"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="444"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="448"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="452"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 prom.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="596"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="597"/>
        <source>Open Containing Folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="598"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="603"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="651"/>
        <source>New Web seed</source>
        <translation>Nueva semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="657"/>
        <source>Remove Web seed</source>
        <translation>Eliminar semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="659"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="660"/>
        <source>Edit Web seed URL</source>
        <translation>Editar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="688"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="723"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="761"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="760"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se pudo renombrar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="864"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="91"/>
        <source>Filter files...</source>
        <translation>Filtrar archivos...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="688"/>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="693"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="722"/>
        <source>Rename error</source>
        <translation>Error al renombrar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="694"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation> El nombre está vacío o contiene caracteres prohibidos, por favor, elija uno diferente </translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="807"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nueva semilla URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="808"/>
        <source>New URL seed:</source>
        <translation>Nueva semilla URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="814"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="865"/>
        <source>This URL seed is already in the list.</source>
        <translation>Esta semilla URL ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="858"/>
        <source>Web seed editing</source>
        <translation>Editando semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="859"/>
        <source>Web seed URL:</source>
        <translation>URL de la semilla Web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="141"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 es un parámetro de la línea de comandos desconocido.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="151"/>
        <location filename="../app/main.cpp" line="160"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 debe ser el único parámetro de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="183"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>No puedes usar %1: qBittorrent ya se está ejecutando para este usuario.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="519"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="522"/>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="156"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>El parámetro &apos;%1&apos; debe seguir la sintaxis &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="202"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>El parámetro &apos;%1&apos; debe seguir la sintaxis &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="216"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>Esperado un número entero en la variable del entorno &apos;%1&apos;, pero se obtuvo &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="269"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>El parámetro &apos;%1&apos; debe seguir la sintaxis &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="293"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>Esperado %1 en la variable del entorno &apos;%2&apos;, pero se obtuvo &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="527"/>
        <source>port</source>
        <translation>puerto</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="418"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 debe especificar un puerto válido (entre 1 y 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="524"/>
        <source>Display program version and exit</source>
        <translation>Muestra la versión del programa y sale</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>Display this help message and exit</source>
        <translation>Muestra este mensaje de ayuda y sale</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>Change the Web UI port</source>
        <translation>Cambia el puerto de la interfaz Web</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="531"/>
        <source>Disable splash screen</source>
        <translation>Desactivar pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="533"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Ejecutar en modo servicio (segundo plano)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="536"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>ruta</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Guardar archivos de configuración en &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>name</source>
        <translation>nombre</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Guardar archivos de configuración en direcciones qBittorrent_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Modificar los archivos de continuación rápida de libtorrent y hacer las rutas relativas a la ruta del perfil.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>files or URLs</source>
        <translation>archivos o URLs</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Download the torrents passed by the user</source>
        <translation>Descarga los torrents pasados por el usuario</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Especifica si el dialogo de &quot;Agregar torrent&quot; se abre al agregar un torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="550"/>
        <source>Options when adding new torrents:</source>
        <translation>Opciones cuando agregue nuevos torrents:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="544"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>Atajo para %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>path</source>
        <translation>ruta</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Torrent save path</source>
        <translation>Ruta de destino del Torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Add torrents as started or paused</source>
        <translation>Agregar torrents iniciados o pausados</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Skip hash check</source>
        <translation>No comprobar hash</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Asignar torrents a la categoría. Si la categoría no existe, será creada.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Download files in sequential order</source>
        <translation>Descargar archivos en orden secuencial</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Download first and last pieces first</source>
        <translation>Comenzar por las primeras y últimas partes</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="565"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Valores opcionales pueden ser provistos por variables del entorno. Para la opción llamada &apos;parameter-name&apos;, la variable del entorno se llama &apos;QBT_PARAMETER_NAME&apos; (en mayúsculas y &apos;-&apos; es reemplazado por &apos;_&apos;). Para pasar valores de bandera, defina la variable como &apos;1&apos; o &apos;TRUE&apos;. Por Ej: para desactivar la pantalla de inicio:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="570"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Los parámetros de linea de comandos tienen prioridad sobre las variables del entorno</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="581"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="350"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Ejecuta la aplicación con la opción -h para obtener información sobre los parámetros de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="352"/>
        <source>Bad command line</source>
        <translation>Parámetros de la línea de comandos incorrectos</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="358"/>
        <source>Bad command line: </source>
        <translation>Parámetros de la línea de comandos incorrectos:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="372"/>
        <source>Legal Notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="373"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>qBittorrent es un programa para compartir archivos. Cuando se descarga un torrent, los datos del mismo se pondrán a disposición de los demás usuarios por medio de las subidas. Cualquier contenido que usted comparta, lo hace bajo su propia responsabilidad.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="374"/>
        <source>No further notices will be issued.</source>
        <translation>No se le volverá a notificar sobre esto.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="386"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent es un programa para compartir archivos. Cuando se descarga un torrent, los datos del mismo se pondrán a disposición de los demás usuarios por medio de las subidas. Cualquier contenido que usted comparta, lo hace bajo su propia responsabilidad.

No se le volverá a notificar sobre esto.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="375"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pulse la tecla %1 para aceptar y continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="387"/>
        <source>Legal notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="388"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="389"/>
        <source>I Agree</source>
        <translation>Estoy de acuerdo</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="vanished">El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="vanished">La operación fue cancelada</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="vanished">El servidor remoto cerró la conexión prematuramente, antes de que se recibiera y procesara toda la respuesta</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="vanished">La conexión con el servidor remoto ha agotado el tiempo de espera</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="vanished">Handshake SSL/TLS fallido</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="vanished">El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="vanished">La conexión con el servidor proxy fué rechazada</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="vanished">El servidor proxy cerró la conexión antes de tiempo</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="vanished">No se encontró el nombre del servidor proxy</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="vanished">La conexión con el servidor proxy ha agotado el tiempo de espera o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation type="vanished">El proxy requiere autenticación para poder atender la solicitud, pero no aceptó las credenciales proporcionadas</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="vanished">El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="vanished">La operación solicitada en el contenido remoto no está permitida</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="vanished">El contenido remoto no se encontró en el servidor (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="vanished">El servidor remoto requiere autenticación para servir el contenido, pero no se aceptaron las credenciales proporcionadas</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="vanished">La API de acceso a la red no pudo cumplir con la solicitud debido a que el protocolo es desconocido</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="vanished">La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="vanished">Se ha detectado un error desconocido relacionado con la red</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="vanished">Se ha detectado un error desconocido relacionado con el proxy</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="vanished">Se ha detectado un error desconocido relacionado con el contenido remoto</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="vanished">Se ha detectado una ruptura en el protocolo</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Error desconocido</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="78"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="68"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Actualizaste desde una versión anterior que guardaba las cosas de forma diferente. Debes migrar al nuevo sistema de guardado. Si continuas, no podrás volver a usar una versión anterior a v3.3.0. ¿Continuar? [y/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="77"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Actualizaste desde una versión anterior que guardaba las cosas de forma diferente. Debes migrar al nuevo sistema de guardado. Si continuas, no podrás volver a usar una versión anterior a v3.3.0.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="210"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>No se pudo migrar el torrent con el hash: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="213"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>No se pudo migrar el torrent. Nombre del archivo de continuación rapida invalido: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="240"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation>Se ha detectado un cierre inesperado. Usando el archivo de respaldo para restaurar la configuración: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="307"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Ocurrió un error de acceso tratando de escribir el archivo de configuración.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="310"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Ocurrió un error de formato tratando de escribir el archivo de configuración.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="313"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation>Ocurrió un error de formato tratando de escribir el archivo de configuración.</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="80"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="87"/>
        <source>Invalid data format.</source>
        <translation>Formato de datos inválido.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="122"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>No se guardaron las reglas del descargador RSS en %1. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="276"/>
        <source>Invalid data format</source>
        <translation>Formato de datos inválido.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="407"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>No se pudo leer las reglas del descargador RSS de %1. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="419"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>No se cargaron las reglas del descargador RSS Razón: %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="208"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>No se pudo descargar el feed RSS: &apos;%1&apos;, razón: %2.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="251"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>Actualizado Feed RSS en &apos;%1&apos;. Agregados %2 nuevos artículos.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="256"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>No se pudo analizar el feed RSS: &apos;%1&apos;, razón: %2.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="278"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>No se pudieron leer los datos de sesión RSS de %1. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="289"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>No se pudieron leer los datos de sesión RSS. Error: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="295"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>No se pudieron leer los datos de sesión RSS. Formato inválido.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="304"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>No se pudieron cargar los artículos RSS &apos;%1#%2&apos;. Formato inválido.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="578"/>
        <source>Invalid RSS feed.</source>
        <translation>Canal RSS inválido.</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="581"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (linea: %2, columna: %3, margen: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="161"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>El canal RSS con la URL dada ya existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="180"/>
        <source>Cannot move root folder.</source>
        <translation>No se puede mover la carpeta raíz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="187"/>
        <location filename="../base/rss/rss_session.cpp" line="225"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>El item no existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="218"/>
        <source>Cannot delete root folder.</source>
        <translation>No se puede eliminar la carpeta raíz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="380"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Elemento RSS incorrecto Ruta : %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="386"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>El canal RSS con la ruta dada ya existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="394"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>La carpeta no existe: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>La busqueda por canales RSS esta desactivada. Puedes habilitarla en las opciones.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nueva suscripción</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Marcar como leídos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar los Canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>Descargador RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (doble-click para descargar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nueva suscripción...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Actualizar todos los canales</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Descargar torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Copiar URL del canal</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Nueva carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>Please choose a folder name</source>
        <translation>Por favor elija un nombre para la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>Folder name:</source>
        <translation>Nombre de la carpeta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="215"/>
        <source>New folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="255"/>
        <source>Please type a RSS feed URL</source>
        <translation>Por favor escribe una URL de un Canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="255"/>
        <source>Feed URL:</source>
        <translation>URL del canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="296"/>
        <source>Deletion confirmation</source>
        <translation>Confirmar eliminación</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="296"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>¿Esta seguro que desea eliminar los canales RSS seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="385"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor, elija un nuevo nombre para el canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="385"/>
        <source>New feed name:</source>
        <translation>Nombre del nuevo canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="392"/>
        <source>Rename failed</source>
        <translation>Renombrado fallido</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="455"/>
        <source>Date: </source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="457"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="99"/>
        <source>Select save location</source>
        <translation>Seleccione la ubicación de guardado</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="149"/>
        <source>Monitored Folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="152"/>
        <source>Override Save Location</source>
        <translation>Cambiar ubicación de guardado</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="393"/>
        <source>Monitored folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Default save location</source>
        <translation>Ubicación de guardado predeterminada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Browse...</source>
        <translation>Examinar...</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished">Formulario</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation type="unfinished">Resultados(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation type="unfinished">Buscar en:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Algunos motores de búsqueda, buscan en la descripción del torrent y también en los nombres de archivo. Este modo controla si esos resultados son o no mostrados.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Todo &lt;/span&gt;deshabilita el filtrado y muestra todo lo devuelto por los motores de búsqueda.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Solo nombres de torrent&lt;/span&gt; muestra solo los torrents cuyo nombre coincide con los términos de búsqueda.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establece el número mínimo y máximo de sembradores permitidos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation type="unfinished">Semillas:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número mínimo de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation type="unfinished">a</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Máximo numero de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation type="unfinished">∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer los tamaños mínimos y máximos permitidos de un torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation type="unfinished">Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño mínimo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño máximo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation type="unfinished">Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation type="unfinished">Semillas</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation type="unfinished">Pares</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="82"/>
        <source>Search engine</source>
        <translation type="unfinished">Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="133"/>
        <source>Filter search results...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="286"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation type="unfinished">Resultados (mostrando &lt;i&gt;%1&lt;/i&gt; de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="335"/>
        <source>Torrent names only</source>
        <translation type="unfinished">Solo nombres de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="336"/>
        <source>Everywhere</source>
        <translation type="unfinished">En todas partes</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="353"/>
        <source>Searching...</source>
        <translation type="unfinished">Buscando...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="355"/>
        <source>Search has finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="357"/>
        <source>Search aborted</source>
        <translation type="unfinished">Búsqueda abortada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="359"/>
        <source>An error occurred during search...</source>
        <translation type="unfinished">Ha ocurrido un error durante la búsqueda...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="361"/>
        <source>Search returned no results</source>
        <translation type="unfinished">La búsqueda no ha devuelto resultados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="385"/>
        <source>Column visibility</source>
        <translation type="unfinished">Visibilidad de columnas</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="210"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Formato de plugin de motor de búsqueda desconocido.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="224"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Una versión más reciente del plugin ya está instalada.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="251"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="254"/>
        <source>Plugin is not supported.</source>
        <translation>Plugin no soportado.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="323"/>
        <source>All categories</source>
        <translation>Todas</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="324"/>
        <source>Movies</source>
        <translation>Películas</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="325"/>
        <source>TV shows</source>
        <translation>Programas de TV</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="326"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="327"/>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="328"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="329"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="330"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="331"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="370"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>El servidor de actualizaciones no está disponible temporalmente. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="388"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="390"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Error al descargar el plugin. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="525"/>
        <source>An incorrect update info received.</source>
        <translation>La información de actualización recibida es incorrecta.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="560"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>El plugin de búsqueda &apos;%1&apos; contiene una cadena de versión invalida (&apos;%2&apos;)</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation type="vanished">Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation type="vanished">Tamaño</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation type="vanished">Semillas</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation type="vanished">Pares</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation type="vanished">Motor de búsqueda</translation>
    </message>
    <message>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation type="vanished">Resultados (mostrando &lt;i&gt;%1&lt;/i&gt; de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation type="vanished">Solo nombres de Torrent</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation type="vanished">En todas partes</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation type="vanished">Buscando...</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation type="vanished">La búsqueda ha finalizado</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation type="vanished">Búsqueda abortada</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation type="vanished">Ha ocurrido un error durante la búsqueda...</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation type="vanished">La búsqueda no ha devuelto resultados</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation type="vanished">Visibilidad de columnas</translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulario</translation>
    </message>
    <message>
        <source>Results(xxx)</source>
        <translation type="vanished">Resultados(xxx)</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation type="vanished">Buscar en:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Algunos motores de búsqueda, buscan en la descripción del torrent y también en los nombres de archivo. Este modo controla si esos resultados son o no mostrados.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Todo &lt;/span&gt;deshabilita el filtrado y muestra todo lo devuelto por los motores de búsqueda.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Solo nombres de torrent&lt;/span&gt; muestra solo los torrents cuyo nombre coincide con los términos de búsqueda.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establece el número mínimo y máximo de sembradores permitidos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation type="vanished">Semillas:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número mínimo de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="vanished">a</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Máximo numero de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>∞</source>
        <translation type="vanished">∞</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer los tamaños mínimos y máximos permitidos de un torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Tamaño:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño mínimo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño máximo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="287"/>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <location filename="../gui/search/searchwidget.cpp" line="386"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>No hay plugins de búsqueda instalados.
Presione el boton &quot;Plugins de búsqueda...&quot; ubicado abajo a la derecha para instalar algunos.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>Ir a la página de la descripción</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>Copiar URL de la descripción</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>Plugins de búsqueda...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="102"/>
        <source>A phrase to search for.</source>
        <translation>Una frase a buscar.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="103"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Los espacios de una búsqueda pueden ser protegidos por comillas dobles.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="105"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="107"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: buscar &lt;b&gt;foo&lt;/b&gt; y &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="111"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: buscar &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="187"/>
        <source>All plugins</source>
        <translation>Todos los motores</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="186"/>
        <source>Only enabled</source>
        <translation>Solo habilitados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="188"/>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="300"/>
        <location filename="../gui/search/searchwidget.cpp" line="372"/>
        <location filename="../gui/search/searchwidget.cpp" line="374"/>
        <source>Search Engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="300"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Por favor, instala Python para usar el motor de búsqueda.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Empty search pattern</source>
        <translation>Patrón de búsqueda vacío</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor, escriba un patrón de búsqueda primero</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="350"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="374"/>
        <source>Search has finished</source>
        <translation>La búsqueda ha terminado</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="372"/>
        <source>Search has failed</source>
        <translation>La búsqueda ha fallado</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation type="unfinished">No volver a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="113"/>
        <source>qBittorrent will now exit.</source>
        <translation type="unfinished">qBittorrent se cerrará ahora.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>E&amp;xit Now</source>
        <translation type="unfinished">&amp;Salir ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="115"/>
        <source>Exit confirmation</source>
        <translation type="unfinished">Confirmar salida</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="118"/>
        <source>The computer is going to shutdown.</source>
        <translation type="unfinished">El equipo se apagará.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>&amp;Shutdown Now</source>
        <translation type="unfinished">&amp;Apagar ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="120"/>
        <source>Shutdown confirmation</source>
        <translation type="unfinished">Confirmar al cerrar</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="123"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation type="unfinished">El equipo  entrará en modo suspensión.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>&amp;Suspend Now</source>
        <translation type="unfinished">&amp;Suspender Ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="125"/>
        <source>Suspend confirmation</source>
        <translation type="unfinished">Confirmar Suspensión</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="128"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation type="unfinished">El equipo entrará en modo hibernación.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>&amp;Hibernate Now</source>
        <translation type="unfinished">&amp;Hibernar Ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="130"/>
        <source>Hibernate confirmation</source>
        <translation type="unfinished">Confirmar Hibernación</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="140"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation type="unfinished">Puedes cancelar la acción durante %1 segundos.</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>qBittorrent will now exit.</source>
        <translation type="vanished">qBittorrent se cerrará ahora.</translation>
    </message>
    <message>
        <source>E&amp;xit Now</source>
        <translation type="vanished">&amp;Salir ahora</translation>
    </message>
    <message>
        <source>Exit confirmation</source>
        <translation type="vanished">Confirmar salida</translation>
    </message>
    <message>
        <source>The computer is going to shutdown.</source>
        <translation type="vanished">El equipo se apagará.</translation>
    </message>
    <message>
        <source>&amp;Shutdown Now</source>
        <translation type="vanished">&amp;Apagar ahora</translation>
    </message>
    <message>
        <source>The computer is going to enter suspend mode.</source>
        <translation type="vanished">El equipo  entrará en modo suspensión.</translation>
    </message>
    <message>
        <source>&amp;Suspend Now</source>
        <translation type="vanished">&amp;Suspender Ahora</translation>
    </message>
    <message>
        <source>Suspend confirmation</source>
        <translation type="vanished">Confirmar Suspensión</translation>
    </message>
    <message>
        <source>The computer is going to enter hibernation mode.</source>
        <translation type="vanished">El equipo entrará en modo hibernación.</translation>
    </message>
    <message>
        <source>&amp;Hibernate Now</source>
        <translation type="vanished">&amp;Hibernar Ahora</translation>
    </message>
    <message>
        <source>Hibernate confirmation</source>
        <translation type="vanished">Confirmar Hibernación</translation>
    </message>
    <message>
        <source>You can cancel the action within %1 seconds.</source>
        <translation type="vanished">Puedes cancelar la acción durante %1 segundos.</translation>
    </message>
    <message>
        <source>Shutdown confirmation</source>
        <translation type="vanished">Confirmar al cerrar</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.cpp" line="85"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Upload</source>
        <translation>Subida total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="54"/>
        <source>Total Download</source>
        <translation>Descarga total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Upload</source>
        <translation>Subida útil </translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="59"/>
        <source>Payload Download</source>
        <translation>Descarga útil</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Upload</source>
        <translation>Subida exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="64"/>
        <source>Overhead Download</source>
        <translation>Descarga exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Upload</source>
        <translation>Subida DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="69"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Upload</source>
        <translation>Subida tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="74"/>
        <source>Tracker Download</source>
        <translation>Descarga tracker</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Periodo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="106"/>
        <source>Select Graphs</source>
        <translation>Seleccionar gráficas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Upload</source>
        <translation>Subida total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Download</source>
        <translation>Descarga total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Upload</source>
        <translation>Subida útil </translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Download</source>
        <translation>Descarga útil</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Upload</source>
        <translation>Subida exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Download</source>
        <translation>Descarga exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Upload</source>
        <translation>Subida DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Upload</source>
        <translation>Subida tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Download</source>
        <translation>Descarga tracker</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation type="unfinished">Información del problema</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadísticas del usuario</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadísticas de la caché</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Uso de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Tiempo promedio en cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>Pares conectados:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>Ratio de comparticíon:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>Total bajado:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>Desperdicio de sesión:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>Total subido:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>Tamaño total del buffer:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendimiento</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Trabajos de I/O en cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga de la caché de escritura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamaño total de cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="105"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hay conexiones directas. Esto puede indicar problemas en la configuración de red.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>Es necesario reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fuera de línea. Esto normalmente significa que qBittorrent no puede escuchar el puerto seleccionado para las conexiones entrantes.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Click para cambiar a los límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Click para cambiar a los límites de velocidad normales</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Máxima velocidad global de descarga</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Máxima velocidad global de subida</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="134"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation type="unfinished">Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="137"/>
        <source>Downloading (0)</source>
        <translation type="unfinished">Descargando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="140"/>
        <source>Seeding (0)</source>
        <translation type="unfinished">Sembrando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="143"/>
        <source>Completed (0)</source>
        <translation type="unfinished">Completados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="146"/>
        <source>Resumed (0)</source>
        <translation type="unfinished">Continuados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="149"/>
        <source>Paused (0)</source>
        <translation type="unfinished">Pausados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="152"/>
        <source>Active (0)</source>
        <translation type="unfinished">Activos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="155"/>
        <source>Inactive (0)</source>
        <translation type="unfinished">Inactivos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>Errored (0)</source>
        <translation type="unfinished">Con errores (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="175"/>
        <source>All (%1)</source>
        <translation type="unfinished">Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="176"/>
        <source>Downloading (%1)</source>
        <translation type="unfinished">Descargando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="177"/>
        <source>Seeding (%1)</source>
        <translation type="unfinished">Sembrando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="178"/>
        <source>Completed (%1)</source>
        <translation type="unfinished">Completados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>Paused (%1)</source>
        <translation type="unfinished">Pausados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="180"/>
        <source>Resumed (%1)</source>
        <translation type="unfinished">Continuados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="181"/>
        <source>Active (%1)</source>
        <translation type="unfinished">Activos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Inactive (%1)</source>
        <translation type="unfinished">Inactivos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>Errored (%1)</source>
        <translation type="unfinished">Con errores (%1)</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation type="vanished">Todos (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation type="vanished">Descargando (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation type="vanished">Sembrando (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation type="vanished">Completados (0)</translation>
    </message>
    <message>
        <source>Resumed (0)</source>
        <translation type="vanished">Continuados (0)</translation>
    </message>
    <message>
        <source>Paused (0)</source>
        <translation type="vanished">Pausados (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation type="vanished">Activos (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation type="vanished">Inactivos (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation type="vanished">Con errores (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation type="vanished">Todos (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation type="vanished">Descargando (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation type="vanished">Sembrando (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation type="vanished">Completados (%1)</translation>
    </message>
    <message>
        <source>Paused (%1)</source>
        <translation type="vanished">Pausados (%1)</translation>
    </message>
    <message>
        <source>Resumed (%1)</source>
        <translation type="vanished">Continuados (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation type="vanished">Activos (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation type="vanished">Inactivos (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation type="vanished">Con errores (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="146"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="257"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="259"/>
        <source>Untagged</source>
        <translation>Sin etiquetar</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="112"/>
        <source>Add tag...</source>
        <translation>Añadir etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="119"/>
        <source>Remove tag</source>
        <translation>Eliminar etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Remove unused tags</source>
        <translation>Eliminar etiquetas sin usar</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="132"/>
        <source>Resume torrents</source>
        <translation>Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="138"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="144"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>New Tag</source>
        <translation>Nueva etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>Tag:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="191"/>
        <source>Invalid tag name</source>
        <translation>Nombre de etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>El nombre de la etiqueta &apos;%1&apos; no es válido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag exists</source>
        <translation>La etiqueta existe</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag name already exists.</source>
        <translation>El nombre de la etiqueta ya existe.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Propiedades de las categorías de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation>Elegir ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>Nueva categoría</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>Nombre de la categoría no válido</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>El nombre de la categoría no debe contener &apos;\&apos;
El nombre de la categoría no debe contener &apos;//&apos;
El nombre de la categoría no debe comenzar o terminar con &apos;/&apos;.
</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation>Error al crear la categoría</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Ya existe una categoría con este nombre.
Por favor, elija otro nombre.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Download Priority</source>
        <translation>Prioridad de descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Remaining</source>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Availability</source>
        <translation>Disponibilidad</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation type="unfinished">Crear torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation type="unfinished">Seleccionar archivo/carpeta a compartir</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="31"/>
        <source>Path:</source>
        <translation type="unfinished">Ruta:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation type="unfinished">[Área para arrastrar y soltar]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="68"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="111"/>
        <source>Select file</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="75"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="104"/>
        <source>Select folder</source>
        <translation type="unfinished">Seleccionar carpeta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="87"/>
        <source>Settings</source>
        <translation type="unfinished">Ajustes</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="95"/>
        <source>Piece size:</source>
        <translation type="unfinished">Tamaño de la pieza:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="109"/>
        <source>Auto</source>
        <translation type="unfinished">Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="114"/>
        <source>16 KiB</source>
        <translation type="unfinished">16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="119"/>
        <source>32 KiB</source>
        <translation type="unfinished">32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="124"/>
        <source>64 KiB</source>
        <translation type="unfinished">64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="129"/>
        <source>128 KiB</source>
        <translation type="unfinished">128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="134"/>
        <source>256 KiB</source>
        <translation type="unfinished">256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="139"/>
        <source>512 KiB</source>
        <translation type="unfinished">512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="144"/>
        <source>1 MiB</source>
        <translation type="unfinished">1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="149"/>
        <source>2 MiB</source>
        <translation type="unfinished">2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>4 MiB</source>
        <translation type="unfinished">4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="159"/>
        <source>8 MiB</source>
        <translation type="unfinished">8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="164"/>
        <source>16 MiB</source>
        <translation type="unfinished">16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="169"/>
        <source>32 MiB</source>
        <translation type="unfinished">32 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="177"/>
        <source>Calculate number of pieces:</source>
        <translation type="unfinished">Calcular el número de piezas:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="206"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation type="unfinished">Privado (no se distribuirá por la red DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="213"/>
        <source>Start seeding immediately</source>
        <translation type="unfinished"> Comenzar la siembra inmediatamente</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="223"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation type="unfinished">Ignorar los límites de ratio para este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="230"/>
        <source>Optimize alignment</source>
        <translation type="unfinished">Optimizar alineación</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="243"/>
        <source>Fields</source>
        <translation type="unfinished">Campos</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation type="unfinished">Puedes separar los grupos de trackers con una linea vacía.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>Web seed URLs:</source>
        <translation type="unfinished">URLs de las semillas Web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="280"/>
        <source>Tracker URLs:</source>
        <translation type="unfinished">Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="287"/>
        <source>Comments:</source>
        <translation type="unfinished">Comentarios:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="294"/>
        <source>Source:</source>
        <translation type="unfinished">Origen:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="309"/>
        <source>Progress:</source>
        <translation type="unfinished">Progreso:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="70"/>
        <source>Create Torrent</source>
        <translation type="unfinished">Crear Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Torrent creation failed</source>
        <translation type="unfinished">Fallo al crear torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation type="unfinished">Razón: La ruta del archivo/carpeta no es legible.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Select where to save the new torrent</source>
        <translation type="unfinished">Seleccione donde guardar el nuevo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Torrent Files (*.torrent)</source>
        <translation type="unfinished">Archivos Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <source>Reason: %1</source>
        <translation type="unfinished">Razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation type="unfinished">Razón: El torrent creado no es válido. No se agregará a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="205"/>
        <source>Torrent creator</source>
        <translation type="unfinished">Crear &amp;Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="206"/>
        <source>Torrent created:</source>
        <translation type="unfinished">Torrent creado:</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Create Torrent</source>
        <translation type="vanished">Crear Torrent</translation>
    </message>
    <message>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation type="vanished">Razón: La ruta del archivo/carpeta no es legible.</translation>
    </message>
    <message>
        <source>Torrent creation failed</source>
        <translation type="vanished">Fallo al crear torrent</translation>
    </message>
    <message>
        <source>Torrent Files (*.torrent)</source>
        <translation type="vanished">Archivos Torrent (*.torrent)</translation>
    </message>
    <message>
        <source>Select where to save the new torrent</source>
        <translation type="vanished">Seleccione donde guardar el nuevo torrent</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="vanished">Razón: %1</translation>
    </message>
    <message>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation type="vanished">Razón: El torrent creado no es válido. No se agregará a la lista de descargas.</translation>
    </message>
    <message>
        <source>Torrent creator</source>
        <translation type="vanished">Crear &amp;Torrent</translation>
    </message>
    <message>
        <source>Torrent created:</source>
        <translation type="vanished">Torrent creado:</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation type="vanished">Crear torrent</translation>
    </message>
    <message>
        <source>Select file/folder to share</source>
        <translation type="vanished">Seleccionar archivo/carpeta a compartir</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="vanished">Ruta:</translation>
    </message>
    <message>
        <source>[Drag and drop area]</source>
        <translation type="vanished">[Área para arrastrar y soltar]</translation>
    </message>
    <message>
        <source>Select file</source>
        <translation type="vanished">Seleccionar archivo</translation>
    </message>
    <message>
        <source>Select folder</source>
        <translation type="vanished">Seleccionar carpeta</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Ajustes</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation type="vanished">Tamaño de la pieza:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="vanished">Auto</translation>
    </message>
    <message>
        <source>16 KiB</source>
        <translation type="vanished">16 KiB</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation type="vanished">32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation type="vanished">64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation type="vanished">128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation type="vanished">256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation type="vanished">512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation type="vanished">1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation type="vanished">2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation type="vanished">4 MiB</translation>
    </message>
    <message>
        <source>8 MiB</source>
        <translation type="vanished">8 MiB</translation>
    </message>
    <message>
        <source>16 MiB</source>
        <translation type="vanished">16 MiB</translation>
    </message>
    <message>
        <source>32 MiB</source>
        <translation type="vanished">32 MiB</translation>
    </message>
    <message>
        <source>Calculate number of pieces:</source>
        <translation type="vanished">Calcular el número de piezas:</translation>
    </message>
    <message>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation type="vanished">Privado (no se distribuirá por la red DHT)</translation>
    </message>
    <message>
        <source>Start seeding immediately</source>
        <translation type="vanished"> Comenzar la siembra inmediatamente</translation>
    </message>
    <message>
        <source>Ignore share ratio limits for this torrent</source>
        <translation type="vanished">Ignorar los límites de ratio para este torrent</translation>
    </message>
    <message>
        <source>Optimize alignment</source>
        <translation type="vanished">Optimizar alineación</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation type="vanished">Campos</translation>
    </message>
    <message>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation type="vanished">Puedes separar los grupos de trackers con una linea vacía.</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation type="vanished">URLs de las semillas Web:</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation type="vanished">Tracker URLs:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation type="vanished">Comentarios:</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation type="vanished">Origen:</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="vanished">Progreso:</translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="111"/>
        <source>File size exceeds max limit %1</source>
        <translation>El tamaño de archivo excede el límite máximo %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="121"/>
        <source>Torrent file read error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="126"/>
        <source>Torrent file read error: size mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent file read error</source>
        <translation type="vanished">Error de lectura del archivo Torrent</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="vanished">Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="vanished">Tamaño</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="vanished">Progreso</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="vanished">Estado</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="vanished">Semillas</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="vanished">Pares</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="vanished">Vel. descarga</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="vanished">Vel. Subida</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="vanished">Ratio</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="vanished">Tiempo Restante</translation>
    </message>
    <message>
        <source>Category</source>
        <translation type="vanished">Categoría</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation type="vanished">Etiquetas</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="vanished">Agregado</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="vanished">Completado</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="vanished">Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="vanished">Límite descarga</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="vanished">Límite Subida</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="vanished">Descargado</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation type="vanished">Subido</translation>
    </message>
    <message>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation type="vanished">Desc. Sesión</translation>
    </message>
    <message>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation type="vanished">Sub. Sesión</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="vanished">Restante</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="vanished">Tiempo Activo</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation type="vanished">Ruta Destino</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation type="vanished">Completado</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation type="vanished">Límite de ratio</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation type="vanished">Visto Completo</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation type="vanished">Última Actividad</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation type="vanished">Tamaño Total</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="315"/>
        <source>Not contacted yet</source>
        <translation>Aún no contactado</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="317"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="319"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="321"/>
        <source>Not working</source>
        <translation>No Funciona</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="511"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>Error: &apos;%1&apos; no es un archivo torrent valido.
</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="694"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="705"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="716"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="727"/>
        <source>Torrent queueing must be enabled</source>
        <translation>Debe activar la cola de torrents</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="741"/>
        <source>Save path is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="745"/>
        <source>Cannot make save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="749"/>
        <source>Cannot write to directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="753"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Establecer ubicación: moviendo &quot;%1&quot;, de &quot;%2&quot; a &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="767"/>
        <source>Incorrect torrent name</source>
        <translation>Nombre del torrent incorrecto</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="815"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="825"/>
        <source>Incorrect category name</source>
        <translation>Nombre de la categoría incorrecto</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="203"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="206"/>
        <source>Trackerless (0)</source>
        <translation>Sin tracker (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="209"/>
        <source>Error (0)</source>
        <translation>Error (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="212"/>
        <source>Warning (0)</source>
        <translation>Advertencia (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="257"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="312"/>
        <source>Trackerless (%1)</source>
        <translation>Sin tracker (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="354"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="386"/>
        <source>Error (%1)</source>
        <translation>Error (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="367"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="401"/>
        <source>Warning (%1)</source>
        <translation>Advertencia (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="462"/>
        <source>Resume torrents</source>
        <translation>Continuar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="463"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="464"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="498"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="512"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation type="vanished">URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="vanished">Estado</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="vanished">Recibido</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation type="vanished">Semillas</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="vanished">Pares</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <translation type="vanished">Descargado</translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="vanished">Mensaje</translation>
    </message>
    <message>
        <source>Working</source>
        <translation type="vanished">Trabajando</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="vanished">Deshabilitado</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation type="vanished">Este torrent es privado</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation type="vanished">Actualizando...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation type="vanished">No funciona</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation type="vanished">Todavía no contactado</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation type="vanished">URL del tracker:</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation type="vanished">Editando tracker</translation>
    </message>
    <message>
        <source>Tracker editing failed</source>
        <translation type="vanished">Falló la edición del tracker</translation>
    </message>
    <message>
        <source>The tracker URL entered is invalid.</source>
        <translation type="vanished">La URL del tracker es inválida.</translation>
    </message>
    <message>
        <source>The tracker URL already exists.</source>
        <translation type="vanished">La URL del tracker ya existe.</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation type="vanished">Agregar nuevo tracker...</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation type="vanished">Copiar URL del tracker</translation>
    </message>
    <message>
        <source>Edit selected tracker URL</source>
        <translation type="vanished">Editar el tracker seleccionado</translation>
    </message>
    <message>
        <source>Force reannounce to selected trackers</source>
        <translation type="vanished">Forzar recomunicación con los trackers seleccionados</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation type="vanished">Forzar recomunicación con todos los trackers</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation type="vanished">Visibilidad de columnas</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="vanished">Eliminar tracker</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="261"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="351"/>
        <source>Working</source>
        <translation type="unfinished">Trabajando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="262"/>
        <source>Disabled</source>
        <translation type="unfinished">Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="283"/>
        <source>This torrent is private</source>
        <translation type="unfinished">Este torrent es privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="355"/>
        <source>Updating...</source>
        <translation type="unfinished">Actualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="359"/>
        <source>Not working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="363"/>
        <source>Not contacted yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <source>Tracker editing</source>
        <translation type="unfinished">Editando tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <source>Tracker URL:</source>
        <translation type="unfinished">URL del tracker:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="467"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="477"/>
        <source>Tracker editing failed</source>
        <translation type="unfinished">Falló la edición del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="467"/>
        <source>The tracker URL entered is invalid.</source>
        <translation type="unfinished">La URL del tracker es inválida.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="477"/>
        <source>The tracker URL already exists.</source>
        <translation type="unfinished">La URL del tracker ya existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="531"/>
        <source>Add a new tracker...</source>
        <translation type="unfinished">Agregar nuevo tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="536"/>
        <source>Remove tracker</source>
        <translation type="unfinished">Eliminar tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="537"/>
        <source>Copy tracker URL</source>
        <translation type="unfinished">Copiar URL del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="538"/>
        <source>Edit selected tracker URL</source>
        <translation type="unfinished">Editar el tracker seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="543"/>
        <source>Force reannounce to selected trackers</source>
        <translation type="unfinished">Forzar recomunicación con los trackers seleccionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="545"/>
        <source>Force reannounce to all trackers</source>
        <translation type="unfinished">Forzar recomunicación con todos los trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="592"/>
        <source>URL</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="593"/>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="594"/>
        <source>Received</source>
        <translation type="unfinished">Recibido</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="595"/>
        <source>Seeds</source>
        <translation type="unfinished">Semillas</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="596"/>
        <source>Peers</source>
        <translation type="unfinished">Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="597"/>
        <source>Downloaded</source>
        <translation type="unfinished">Descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="598"/>
        <source>Message</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="618"/>
        <source>Column visibility</source>
        <translation type="unfinished">Visibilidad de columnas</translation>
    </message>
</context>
<context>
    <name>TrackerLoginDialog</name>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="14"/>
        <location filename="../gui/trackerlogindialog.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation type="unfinished">Autenticación del tracker</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="64"/>
        <source>Tracker:</source>
        <translation type="unfinished">Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="86"/>
        <source>Login</source>
        <translation type="unfinished">Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="94"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="117"/>
        <source>Password:</source>
        <translation type="unfinished">Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.cpp" line="45"/>
        <source>Log in</source>
        <translation type="unfinished">Conectar</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation type="unfinished">Diálogo para agregar trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation type="unfinished">Lista de trackers a agregar (uno por línea):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation type="unfinished">Lista de URL compatible con μTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="116"/>
        <source>No change</source>
        <translation type="unfinished">Sin cambios</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="116"/>
        <source>No additional trackers were found.</source>
        <translation type="unfinished">No se encontró ningún tracker adicional.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>Download error</source>
        <translation type="unfinished">Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation type="unfinished">La lista de trackers no pudo ser descargada. Razón: %1</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation type="vanished">Diálogo para agregar trackers</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation type="vanished">Lista de trackers a agregar (uno por línea):</translation>
    </message>
    <message>
        <source>µTorrent compatible list URL:</source>
        <translation type="vanished">Lista de URL compatible con μTorrent:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation type="vanished">Error de I/O</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation type="vanished">Error al intentar abrir el archivo descargado.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation type="vanished">Sin cambios</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation type="vanished">No se encontró ningún tracker adicional.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation type="vanished">Error de descarga</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation type="vanished">La lista de trackers no pudo ser descargada. Razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="231"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Descargando metadatos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="243"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Reservando espacio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="269"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="254"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>En cola</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="247"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="234"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="240"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="250"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="258"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="262"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>En cola para verificación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="266"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Comprobando datos de continuación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="272"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="275"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>Moviendo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="278"/>
        <source>Missing Files</source>
        <translation>Faltan archivos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="281"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Con errores</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrado durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="188"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>hace %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="591"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="599"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="618"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="636"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="unfinished">Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="unfinished">Progreso</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="unfinished">Semillas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="unfinished">Pares</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished">Vel. Subida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="unfinished">Ratio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished">Tiempo Restante</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="107"/>
        <source>Category</source>
        <translation type="unfinished">Categoría</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="108"/>
        <source>Tags</source>
        <translation type="unfinished">Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="109"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished">Agregado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="110"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished">Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="111"/>
        <source>Tracker</source>
        <translation type="unfinished">Tracker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="unfinished">Límite descarga</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="unfinished">Límite Subida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished">Descargado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation type="unfinished">Subido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation type="unfinished">Desc. Sesión</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation type="unfinished">Sub. Sesión</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished">Restante</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished">Tiempo Activo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation type="unfinished">Ruta Destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation type="unfinished">Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation type="unfinished">Límite de ratio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation type="unfinished">Visto Completo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation type="unfinished">Última Actividad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation type="unfinished">Tamaño Total</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="703"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="398"/>
        <source>Choose save path</source>
        <translation>Seleccione una ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="616"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límite de velocidad de descarga del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="641"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límite de velocidad de subida del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="685"/>
        <source>Recheck confirmation</source>
        <translation>Confirmación de comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="685"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>¿Esta seguro que desea comprobar los torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forzar continuación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="405"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>Establecer ubicación: moviendo &quot;%1&quot;, de &quot;%2&quot; a &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="774"/>
        <source>Add Tags</source>
        <translation>Añadir etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="782"/>
        <source>Remove All Tags</source>
        <translation>Eliminar todas las etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="782"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>¿Eliminar todas las etiquetas de los torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="796"/>
        <source>Comma-separated tags:</source>
        <translation>Etiquetas separadas por comas:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="803"/>
        <source>Invalid tag</source>
        <translation>Etiqueta no válida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="804"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>El nombre de la etiqueta: &apos;%1&apos; no es válido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="875"/>
        <source>Preview file...</source>
        <translation>Previsualizar archivo...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="877"/>
        <source>Limit share ratio...</source>
        <translation>Límitar ratio de compartición...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="879"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="883"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="885"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="887"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="889"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover al principio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="891"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover al final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="893"/>
        <source>Set location...</source>
        <translation>Establecer destino...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="897"/>
        <source>Force reannounce</source>
        <translation>Forzar recomunicación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="901"/>
        <source>Copy name</source>
        <translation>Copiar nombre</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="903"/>
        <source>Copy hash</source>
        <translation>Copiar hash</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="913"/>
        <source>Download first and last pieces first</source>
        <translation>Descargar antes primeras y últimas partes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="916"/>
        <source>Automatic Torrent Management</source>
        <translation>Administración automática de torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="918"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1025"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1026"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nueva...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1027"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Descategorizar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1044"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1045"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Añadir...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1046"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Eliminar Todo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1108"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="895"/>
        <source>Force recheck</source>
        <translation>Forzar verificación de archivo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="899"/>
        <source>Copy magnet link</source>
        <translation>Copiar enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="905"/>
        <source>Super seeding mode</source>
        <translation>Modo supersiembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="908"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="910"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished">Límites de ratio de subida/descarga</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="20"/>
        <source>Use global share limit</source>
        <translation type="unfinished">Usar límite de ratio global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="23"/>
        <location filename="../gui/updownratiodialog.ui" line="33"/>
        <location filename="../gui/updownratiodialog.ui" line="45"/>
        <source>buttonGroup</source>
        <translation type="unfinished">buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="30"/>
        <source>Set no share limit</source>
        <translation type="unfinished">Sin límites de ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="42"/>
        <source>Set share limit to</source>
        <translation type="unfinished">Establecer límite de ratio en</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="100"/>
        <source>ratio</source>
        <translation type="unfinished">ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="107"/>
        <source>minutes</source>
        <translation type="unfinished">minutos</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="85"/>
        <source>No share limit method selected</source>
        <translation type="unfinished">No ha seleccionado un método para limitar el ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="86"/>
        <source>Please select a limit method first</source>
        <translation type="unfinished">Por favor primero selecione un método para limitar el ratio</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="vanished">Límites de ratio de subida/descarga</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation type="vanished">Usar límite de ratio global</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation type="vanished">Sin límites de ratio</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation type="vanished">Establecer límite de ratio en</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation type="vanished">ratio</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="vanished">minutos</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="vanished">buttonGroup</translation>
    </message>
    <message>
        <source>No share limit method selected</source>
        <translation type="vanished">No ha seleccionado un método para limitar el ratio</translation>
    </message>
    <message>
        <source>Please select a limit method first</source>
        <translation type="vanished">Por favor primero selecione un método para limitar el ratio</translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="72"/>
        <source>Python detected, version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="102"/>
        <source>Python not detected</source>
        <translation type="unfinished">Python no detectado</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="228"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation>Tipo de archivo no aceptable, solo se aceptan de tipo regular.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="235"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="487"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation>Ha excedido el máximo tamaño de archivo permitido (%1)!</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="697"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="706"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="723"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="755"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation> interfaz de Usuario Web: conexión HTTPS exitosa</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation> interfaz de Usuario Web: conexión HTTPS fallida, volviendo a HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>La interfaz Web está escuchando IP: %1, puerto %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Error de la interfaz de Usuario Web - No se puede enlazar la IP %1 Puerto %2 Razón %3</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation type="vanished">Un cliente BitTorrent avanzado programado en C++, basado en el toolkit Qt y en libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Copyright %1 2006-2018 The qBittorrent project</source>
        <translation type="vanished">Copyright %1 2006-2018 El proyecto qBittorrent</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation type="vanished">Página Web:</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation type="vanished">Foro: </translation>
    </message>
    <message>
        <source>Bug Tracker:</source>
        <translation type="vanished">Bug Tracker: </translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <source>Add Peers</source>
        <translation type="vanished">Agregar pares</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation type="vanished">Lista de pares a agregar (una IP por línea):</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation type="vanished">Formato: IPv4:puerto / [IPv6]:puerto</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation type="vanished">Autenticación del tracker</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation type="vanished">Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="vanished">Iniciar sesión</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation type="vanished">Usuario:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="vanished">Contraseña:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation</source>
        <translation type="vanished">Confirmar eliminación</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation type="vanished">Recordar siempre esta elección</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation type="vanished">Eliminar también los archivos del disco duro</translation>
    </message>
</context>
<context>
    <name>confirmShutdownDlg</name>
    <message>
        <source>Don&apos;t show again</source>
        <translation type="vanished">No volver a mostrar</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Add torrent links</source>
        <translation type="vanished">Agregar enlace torrent</translation>
    </message>
    <message>
        <source>Download from URLs</source>
        <translation type="vanished">Descargar de URLs</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="vanished">Un enlace por línea (pueden ser enlaces HTTP, enlaces magnet o info-hashes) </translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="vanished">Descargar</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation type="vanished">No se ha introducido ninguna URL</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation type="vanished">Por favor introduce al menos una URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <source>Crash info</source>
        <translation type="vanished">Información del problema</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="92"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="79"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="80"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="81"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>Python not detected</source>
        <translation type="vanished">Python no detectado</translation>
    </message>
    <message>
        <source>Python version: %1</source>
        <translation type="vanished">Versión de Python: %1</translation>
    </message>
    <message>
        <source>Normalized Python version: %1</source>
        <translation type="vanished"> Versión de Python Normalizada: %1 </translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="279"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="366"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="371"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="272"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="125"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Todas las descargas se han completado. qBittorrent apagará el equipo ahora.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="357"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="361"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Previsualizar selección</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Los siguientes archivos pueden previzualizarse, por favor seleccione uno de ellos:</translation>
    </message>
</context>
<context>
    <name>trackerLogin</name>
    <message>
        <source>Log in</source>
        <translation type="vanished">Conectar</translation>
    </message>
</context>
</TS>
